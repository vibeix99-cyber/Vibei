import json, glob, os
M='/home/user/wt/w2n/kettle/review/product-excellence/contracts/W2/N/captures/AFTER-5d7bb23-5233'
n=0; ok_l=0; ok_h=0; srcs={}; maxcls=0
for f in sorted(glob.glob(M+'/*/meta.json')):
    d=json.load(open(f)); n+=1; st=d['states']
    a=st.get('02-focus-3doff',{}); h=st.get('10-nook-static',{})
    if set((a.get('backdrop') or {}).get('layers') or [])=={'pothos','books','fairyLights','shelf','recordPlayer'}: ok_l+=1
    if h.get('hint')=='A drawing of your room': ok_h+=1
    for s in (a, h):
        for e in (s.get('clsSources') or []):
            for x in e['src']: srcs[x]=srcs.get(x,0)+1
    c=a.get('cls') or 0; maxcls=max(maxcls,c)
    print(os.path.basename(os.path.dirname(f)), 'layers', len((a.get('backdrop') or {}).get('layers') or []), 'hint', repr(h.get('hint')), 'cls3doff', a.get('cls'), 'clsNook', h.get('cls'), 'errors', len(d['errors']))
print('configs', n, 'layers ok', ok_l, 'hint ok', ok_h, 'max 3D-off CLS', maxcls)
print('shift sources', srcs)

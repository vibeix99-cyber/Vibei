import json, os, sys
M = '/home/user/wt/w2n/kettle/review/product-excellence/contracts/W2/N/captures'
B, A = f'{M}/BEFORE-90a11e5-5330', f'{M}/AFTER-4b3ef8c-5233'
ORDER = ['390x844-light-t100', '390x844-dark-t100', '390x844-light-t200', '390x844-dark-t200', '375x667-light-t100', '375x667-dark-t100', '375x667-light-t200', '375x667-dark-t200',
         '844x390-light-t100', '844x390-dark-t100', '844x390-light-t200', '844x390-dark-t200', '1440x900-light-t100', '1440x900-dark-t100', '1440x900-light-t200', '1440x900-dark-t200']
UNLOCKED = {'pothos', 'books', 'fairyLights', 'shelf', 'recordPlayer'}  # veteran, level 12: the window-visible earned items

def load(root, cfg):
    try:
        return json.load(open(f'{root}/{cfg}/meta.json'))
    except Exception:
        return None

def lay(m, st):
    s = (m or {}).get('states', {}).get(st)
    if not s:
        return 'n/a'
    bd = s.get('backdrop') or {}
    L = bd.get('layers') or []
    still = 'still' if bd.get('still') else ('live' if bd.get('static') == 'live' else '?')
    return f"{still}, {len(L)} layers" if L else f"{still}, 0 layers"

def hint(m, st):
    s = (m or {}).get('states', {}).get(st)
    if not s:
        return 'n/a'
    h = s.get('hint') or '(none)'
    return 'drag' if 'Drag' in h else ('drawing' if 'drawing' in h else h[:20])

def cls(m):
    v = [s.get('cls') for k, s in (m or {}).get('states', {}).items() if s.get('cls') is not None and k in ('02-focus-3doff', '02-focus-loading')]
    return max(v) if v else None

rows = ['| Config | 3D off: BEFORE → AFTER | Loading 0.5 s: BEFORE → AFTER | 3D on 4 s (AFTER) | Static Nook hint B → A | 3D Nook hint B → A | CLS (3D off, loading) B / A | errors B / A |', '|---|---|---|---|---|---|---|---|']
ok = True
for cfg in ORDER:
    b, a = load(B, cfg), load(A, cfg)
    if not a or not b:
        rows.append(f'| {cfg} | missing | | | | | | |'); ok = False; continue
    a3 = (a['states'].get('02-focus-3doff') or {}).get('backdrop') or {}
    if set(a3.get('layers') or []) != UNLOCKED:
        ok = False
    if hint(a, '10-nook-static') != 'drawing' or hint(a, '10-nook-3d') != 'drag':
        ok = False
    rows.append(f"| {cfg} | {lay(b, '02-focus-3doff')} → **{lay(a, '02-focus-3doff')}** | {lay(b, '02-focus-loading')} → **{lay(a, '02-focus-loading')}** | {lay(a, '02-focus')} | {hint(b, '10-nook-static')} → **{hint(a, '10-nook-static')}** | {hint(b, '10-nook-3d')} → {hint(a, '10-nook-3d')} | {cls(b)} / {cls(a)} | {len(b['errors'])} / {len(a['errors'])} |")
print('\n'.join(rows))
print('\nALL_OK' if ok else '\nCHECK')

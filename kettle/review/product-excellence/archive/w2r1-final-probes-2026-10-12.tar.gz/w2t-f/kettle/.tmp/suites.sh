#!/bin/bash
# Orchestrator: browser suite + timer/PWA once on the candidate merged tree (c99611a, src e0aebbf), one browser.
cd /home/user/wt/w2t-f/kettle
G="python3 -I /home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review/tools/slots.py run --lane LRF --n 1 --"
O=/home/user/Vibei/kettle/review/product-excellence/contracts/W2/review/LR/final
echo "[$(date -u +%T)] chromium start (tree $(git rev-parse --short HEAD), src $(git rev-parse --short HEAD:kettle/src))" >> $O/run.log
$G env KETTLE_PORT=5347 npx playwright test --project=chromium --workers=1 --reporter=list --output=/tmp/claude-0/lrf-out > $O/chromium.log 2>&1; echo "[$(date -u +%T)] chromium exit $?" >> $O/run.log
$G env KETTLE_PORT=5347 npx playwright test --project=timer-harness --project=timer-app --project=pwa --workers=1 --reporter=list --output=/tmp/claude-0/lrf-out2 > $O/timer-pwa.log 2>&1; echo "[$(date -u +%T)] timer/pwa exit $?" >> $O/run.log
echo "[$(date -u +%T)] SUITES DONE" >> $O/run.log

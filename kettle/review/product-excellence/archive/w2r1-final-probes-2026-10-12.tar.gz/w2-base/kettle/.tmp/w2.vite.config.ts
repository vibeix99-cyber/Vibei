// Wave-2 server for this worktree (private dep cache; symlinked node_modules allowed).
import { mergeConfig, type UserConfig } from 'vite';
import base from '../vite.config';
export default mergeConfig(base as unknown as UserConfig, {
  cacheDir: '/home/user/wt/w2-base/kettle/.tmp/vite-cache',
  server: { watch: null, hmr: false, fs: { allow: ['/home/user/wt/w2-base/kettle', '/home/user/Vibei/kettle/node_modules'] } },
} satisfies UserConfig);

#!/bin/bash
# Orchestrator (economy resume): first-visit split — spec control-first, then AFTER first-visit captures matching BEFORE-90a11e5.
G="python3 -I /home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review/tools/slots.py run --lane FV --n 1 --"
O=/home/user/Vibei/kettle/review/product-excellence/contracts/W2/review/FV; mkdir -p $O/AFTER-1b38509-5353 $O/spec; L=$O/run.log
cd /home/user/wt/w2fv/kettle && echo "[$(date -u +%T)] spec on control 90a11e5 :5310 (spec from the split worktree, server = control)" >> $L && $G env KETTLE_PORT=5310 npx playwright test tests/w2-firstvisit.spec.ts --project=chromium --workers=1 --reporter=list > $O/spec/control-90a11e5.log 2>&1; echo "exit $?" >> $L
cd /home/user/wt/w2fv/kettle && echo "[$(date -u +%T)] spec on split 1b38509 :5343" >> $L && $G env KETTLE_PORT=5343 npx playwright test tests/w2-firstvisit.spec.ts --project=chromium --workers=1 --reporter=list > $O/spec/split-1b38509.log 2>&1; echo "exit $?" >> $L
cd /home/user/wt/w2fv/kettle/.tmp/fv
for c in 390x844@2:light:100 390x844@2:dark:100 390x844@2:light:200 390x844@2:dark:200 375x667@2:light:100 375x667@2:dark:100 375x667@2:light:200 375x667@2:dark:200 844x390@2:light:100 844x390@2:dark:100 844x390@2:light:200 844x390@2:dark:200 1440x900@1:light:100 1440x900@1:dark:100 1440x900@1:light:200 1440x900@1:dark:200; do
  $G timeout 300 node fv.mjs --base http://127.0.0.1:5353 --out $O/AFTER-1b38509-5353 --cfg $c >> $L 2>&1
done
echo "[$(date -u +%T)] FV DONE" >> $L

// Wave 2 round 1 — BEFORE captures on 90a11e5 (orchestrator). One browser per invocation (run under the slot gate).
// Frozen start clock (page.clock.install + resume), animations:'disabled' screenshots, fresh profile per state group.
// node before.mjs --base http://127.0.0.1:5330 --out <dir> --cfg 390x844@2:light:100
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const FIXED = Date.parse('2026-10-11T07:40:00.000Z');
const m = args.cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
const [W, H, DPR, theme, text] = [+m[1], +m[2], +m[3], m[4], +m[5]];
const dir = `${args.out}/${W}x${H}-${theme}-t${text}`;
mkdirSync(dir, { recursive: true });
const mobile = W < 900;
const meta = { base: args.base, rev: '1b38509 (pe/w2-firstvisit, kettle/src 58aac00), production preview', viewport: { w: W, h: H }, dpr: DPR, theme, text: `${text}%`, fixedTime: '2026-10-11T07:40:00Z', states: {}, errors: [] };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });

async function context() {
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  const p = await ctx.newPage();
  await p.clock.install({ time: FIXED });
  await p.clock.resume();
  p.on('pageerror', (e) => meta.errors.push(e.message.slice(0, 200)));
  return { ctx, p };
}
const q = (seed, extra = '') => `${args.base}/?debug&seed=${seed}&theme=${theme}${extra}`;
const ready = (p) => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 }).catch(() => {});
const measure = (p) => p.evaluate(() => {
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 1 && r.height > 1 && r.bottom > 0 && r.top < innerHeight; };
  const rect = (e) => { const r = e.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]; };
  const buttons = [...document.querySelectorAll('button,[role=button],[role=radio],a[href]')].filter(vis).map((e) => ({ name: (e.getAttribute('aria-label') || e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 50), box: rect(e) }));
  const imgs = [...document.querySelectorAll('img')].filter(vis).map((i) => ({ src: (i.currentSrc || i.src).split('/').pop().slice(0, 40), box: rect(i) }));
  const canvases = [...document.querySelectorAll('canvas')].filter(vis).map((c) => ({ box: rect(c) }));
  const pills = [...document.querySelectorAll('[aria-label="Rewards"] li')].map((li) => ({ text: li.innerText.replace(/\s+/g, ' ').slice(0, 60), box: rect(li) }));
  const hint = [...document.querySelectorAll('p,span,div')].find((e) => e.childElementCount <= 2 && /look around/i.test(e.textContent || ''));
  return { hash: location.hash, scroll: Math.round(document.scrollingElement.scrollTop), buttons, imgs, canvases, pills, hint: hint ? hint.textContent.trim() : null };
});
const shot = async (p, name, desc, full = false) => {
  try {
    await p.screenshot({ path: `${dir}/${name}.png`, animations: 'disabled', fullPage: full, timeout: 120_000 });
    meta.states[name] = { desc, ...(await measure(p)) };
  } catch (e) { meta.errors.push(`${name}: ${e.message.slice(0, 120)}`); }
};
const click = async (p, name) => { const l = p.getByRole('button', { name }).first(); await l.scrollIntoViewIfNeeded().catch(() => {}); await l.click({ timeout: 30_000 }); };
const settings = (p, s) => p.evaluate((x) => window.__kettle.settings.getState().set(x), s);

async function group(label, fn) {
  const { ctx, p } = await context();
  try { await fn(p); } catch (e) { meta.errors.push(`${label}: ${e.message.slice(0, 160)}`); }
  await ctx.close();
}

try {
  // First visit (fresh profile, not onboarded)
  await group('first-visit', async (p) => {
    await p.goto(q('fresh', '&onboarded=0') + '#/welcome'); await ready(p); await p.evaluate(() => document.fonts.ready); await sleep(1500);
    await shot(p, '00-first-visit', 'First visit (fresh profile)');
    await shot(p, '00-first-visit-full', 'First visit, full page', true);
  });
} finally {
  writeFileSync(`${dir}/meta.json`, JSON.stringify(meta, null, 1));
  await b.close();
  console.log(`${W}x${H}-${theme}-t${text}`, 'states', Object.keys(meta.states).length, 'errors', meta.errors.length);
}

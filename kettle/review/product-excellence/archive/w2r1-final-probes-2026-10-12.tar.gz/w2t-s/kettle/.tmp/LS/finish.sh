#!/bin/bash
# Orchestrator (economy resume): finish Lane S's missing same-session captures with Lane S's own cap.mjs, one browser, BEFORE then AFTER per config.
cd /home/user/wt/w2t-s/kettle/.tmp/LS
G="python3 -I /home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review/tools/slots.py run --lane LS --n 1 --"
C=/home/user/Vibei/kettle/review/product-excellence/contracts/W2/review/LS/captures
L=/home/user/Vibei/kettle/review/product-excellence/contracts/W2/review/LS/logs/finish.log
for cfg in 390x844@2:light:100 390x844@2:dark:100 390x844@2:light:200 390x844@2:dark:200 844x390@2:light:200 844x390@2:dark:200 1440x900@1:light:100 1440x900@1:light:200 1440x900@1:dark:200 1440x900@1:dark:100; do
  if [ $cfg != 1440x900@1:dark:100 ]; then echo "[$(date -u +%T)] BEFORE $cfg" >> $L; $G timeout 900 node cap.mjs --base http://127.0.0.1:5330 --rev "90a11e5 (kettle/src 42e106d), production preview 5330" --out $C/BEFORE-90a11e5-5330 --cfgs $cfg >> $L 2>&1; fi
  if [ $cfg = 1440x900@1:dark:100 ]; then rm -rf $C/BEFORE-90a11e5-5330/1440x900-dark-t100; echo "[$(date -u +%T)] BEFORE $cfg (rerun: prior run 7 states, 1 error)" >> $L; $G timeout 900 node cap.mjs --base http://127.0.0.1:5330 --rev "90a11e5 (kettle/src 42e106d), production preview 5330" --out $C/BEFORE-90a11e5-5330 --cfgs $cfg >> $L 2>&1; continue; fi
  echo "[$(date -u +%T)] AFTER $cfg" >> $L; $G timeout 900 node cap.mjs --base http://127.0.0.1:5351 --rev "e0f511a (trial 3726a71, kettle/src 6750571), production preview 5351" --out $C/AFTER-e0f511a-5351 --cfgs $cfg >> $L 2>&1
done
echo "[$(date -u +%T)] FINISH DONE" >> $L

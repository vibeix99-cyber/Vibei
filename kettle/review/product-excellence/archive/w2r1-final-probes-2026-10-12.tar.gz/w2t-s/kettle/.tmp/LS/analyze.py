#!/usr/bin/env python3
"""Lane S: build the acceptance table from the BEFORE/AFTER meta.json files (independent `ls` measurement + the maker's)."""
import json, os, re, sys
ROOT = '/home/user/Vibei/kettle/review/product-excellence/contracts/W2/review/LS/captures'
SIDES = {'BEFORE': f'{ROOT}/BEFORE-90a11e5-5330', 'AFTER': f'{ROOT}/AFTER-e0f511a-5351'}
CFGS = [f'{v}-{th}-t{t}' for v in ('375x667', '390x844', '844x390', '1440x900') for t in (100, 200) for th in ('light', 'dark')]
CFGS = sorted(CFGS, key=lambda c: (['375x667', '390x844', '844x390', '1440x900'].index(c.split('-')[0]), c))
DAYS = {'routine': ('07-summary-routine', '07-summary-routine-settled', '07-summary-routine-end'),
        'bigday': ('07-summary-bigday', '07-summary-bigday-settled', '07-summary-bigday-end')}
norm = lambda s: re.sub(r'\s+', ' ', s or '').strip()

def load(side, cfg):
    p = f'{SIDES[side]}/{cfg}/meta.json'
    return json.load(open(p)) if os.path.exists(p) else None

def get(meta, name):
    st = (meta or {}).get('states', {}).get(name)
    return st if st and 'ls' in st and st['ls'] and 'error' not in st['ls'] else None

def cutlist(ls, key):
    # a text line cut by the fold = its box/ink straddles the footer's top or sits in the bottom fade (a line scrolled off the TOP is not a cut)
    return [f"{c['box'] if key == 'cutLinesBox' else c['ink']}:{c['text'][:22]}" for c in ls[key] if (c['box'] if key == 'cutLinesBox' else c['ink']) in ('straddle-fold', 'in-fade')]

rows, rewards_rows = [], []
for cfg in CFGS:
    for day, names in DAYS.items():
        info = {}
        for side in ('BEFORE', 'AFTER'):
            meta = load(side, cfg)
            sts = [get(meta, n) for n in names]
            info[side] = sts
            r = {'cfg': cfg, 'day': day, 'side': side}
            if not meta:
                r['missing'] = 'no capture'; rows.append(r); continue
            if not all(sts[:2]):
                r['missing'] = 'states: ' + ','.join(n.split('-', 2)[2] for n, s in zip(names, sts) if not s);
            arr, set_, end = sts
            avail = [s['ls'] for s in sts if s]
            r['rev'] = (meta.get('rev') or '')[:9]
            r['heading'] = [bool(s['ls']['heading'] and s['ls']['heading']['inViewport']) for s in sts[:2] if s]
            r['footer'] = [all(b['hitsOfFive'] == 5 and b['inViewport'] for b in s['ls']['footer']) and len(s['ls']['footer']) >= 2 for s in sts if s]
            r['footer_n'] = [len(s['ls']['footer']) for s in sts if s]
            r['highlights'] = [s['ls']['highlightCount'] + (1 if s['ls']['unlock'] else 0) for s in sts if s]  # [data-highlight] pills + the unlock card (an unlock IS the highlight)
            hl = next((p for p in (set_ or arr or end)['ls']['pills'] if p['highlight']), None) if (set_ or arr or end) else None
            r['highlight_kind'] = hl['milestone'] if hl else None
            r['highlight_text'] = hl['visible'][:50] if hl else None
            r['distinct_groups'] = [len({json.dumps([p['style']['bg'], p['style']['border'], p['style']['fs'], p['style']['pad'], p['style']['rad'], p['style']['shadow']]) for p in s['ls']['pills']}) for s in sts if s]  # style signature without box height
            r['cut_box'] = {n: cutlist(s['ls'], 'cutLinesBox') for n, s in zip(('arrival', 'settled', 'end'), sts) if s}
            r['cut_ink'] = {n: cutlist(s['ls'], 'cutLinesInk') for n, s in zip(('arrival', 'settled', 'end'), sts) if s}
            r['maker_cut'] = {n: [c['kind'] + ('@' + str(c['top']) + '-' + str(c['bottom'])) for c in s.get('cut', [])] for n, s in zip(('arrival', 'settled', 'end'), sts) if s}
            r['maker_cut_text'] = {n: [k for k in v if re.search(r'line\d|^details\d|^task$', k)] for n, v in r['maker_cut'].items()}
            r['maker_cut_box'] = {n: [k for k in v if not re.search(r'line\d|^details\d|^task$', k)] for n, v in r['maker_cut'].items()}
            if end:
                e = end['ls']
                r['end_atEnd'] = e['scroll']['atEnd']; r['end_gap'] = e['lastLine']['gapToFooterTop'] if e['lastLine'] else None
                r['end_last'] = e['lastLine']['text'] if e['lastLine'] else None; r['fade'] = e['fade']; r['end_details_open'] = e['detailsToggle']['open'] if e['detailsToggle'] else None
            r['occluded'] = sum(len(s['ls']['occluded']) for s in sts if s); r['overlaps'] = sum(len(s['ls']['overlaps']) for s in sts if s)
            r['maker_occl'] = sum(len(s.get('occluded', [])) for s in sts if s); r['maker_ovl'] = sum(len(s.get('overlaps', [])) for s in sts if s)
            r['toasts'] = sorted({t['text'] for s in sts if s for t in s['ls']['toasts']})
            r['chai'] = [(s['ls']['chai']['inViewportShare'], s['ls']['chai']['notUnderSheetShare']) if s['ls']['chai'] else None for s in sts[:2] if s]
            if day == 'bigday':
                u = [s['ls']['unlock'] for s in sts if s]
                r['unlock'] = [bool(x) and (x['hasCanvas'] or x['hasStillGlyph']) for x in u]
                r['unlock_status'] = [x['status'] if x else None for x in u]
                r['unlock_label'] = next((x['label'] for x in u if x), None)
            r['pills_n'] = len((set_ or arr or end)['ls']['pills']) if (set_ or arr or end) else None
            r['errors'] = meta.get('errors', [])
            rows.append(r)
        # rewards comparison
        b = next((s for s in info['BEFORE'][1:2] + info['BEFORE'][0:1] if s), None)
        a = next((s for s in info['AFTER'][1:2] + info['AFTER'][0:1] if s), None)
        if b and a:
            bp = [p for p in b['ls']['pills']]; ap = [p for p in a['ls']['pills']]
            bvis = [p['visible'] for p in bp]
            avis = [p['visible'] for p in ap]
            missing, matched = [], []
            used = set()
            for t in bvis:
                j = next((i for i, x in enumerate(avis) if i not in used and (x == t or (ap[i]['highlight'] and x.startswith(t)))), None)
                if j is None: missing.append(t)
                else: used.add(j); matched.append((t, avis[j]))
            extra = [avis[i] for i in range(len(avis)) if i not in used]
            # numbers: the pill title numbers
            nums = lambda xs: sorted(re.findall(r'\d+', ' '.join(xs)))
            btitle = bvis
            atitle = []
            for i, p in enumerate(ap):
                t = p['visible']
                if p['highlight']:
                    # title = the matched BEFORE text (title is a prefix of title+note)
                    m = next((bt for bt in bvis if t.startswith(bt)), t)
                    t = m
                atitle.append(t)
            # arithmetic = facts after the rewards
            bend, aend = info['BEFORE'][2], info['AFTER'][2]
            bfacts = set(bend['facts']) if bend else None; afacts = set(aend['facts']) if aend else None
            arith = None
            if bfacts is not None and afacts is not None:
                pillfacts_b = {p['full'] for p in bp} | set(bvis); pillfacts_a = {p['full'] for p in ap} | set(avis)
                bset = {f for f in bfacts if f not in pillfacts_b and f not in bvis}
                aset = {f for f in afacts if f not in pillfacts_a and f not in avis}
                # facts include pill text via visibleText(li): drop those that equal any pill visible text
                arith = {'only_before': sorted(bset - aset), 'only_after': sorted(aset - bset), 'n_before': len(bset), 'n_after': len(aset)}
            rewards_rows.append({'cfg': cfg, 'day': day, 'before_n': len(bp), 'after_n': len(ap), 'missing_in_after': missing, 'extra_in_after': extra,
                                 'numbers_equal': nums(btitle) == nums(atitle), 'before_nums': nums(btitle), 'after_nums': nums(atitle),
                                 'announce_equal': norm(b['ls']['announce']) == norm(a['ls']['announce']), 'announce_before': norm(b['ls']['announce'])[:200], 'announce_after': norm(a['ls']['announce'])[:200],
                                 'before_pills': bvis, 'after_pills': avis, 'arith': arith,
                                 'sr_missing': [p['full'] for p in bp if not any(q['full'] == p['full'] or p['full'] in q['full'] for q in ap)]})
        else:
            rewards_rows.append({'cfg': cfg, 'day': day, 'missing': 'BEFORE' if not b else 'AFTER'})

json.dump({'rows': rows, 'rewards': rewards_rows}, open(f'{ROOT}/../analysis.json', 'w'), indent=1)

def verdict(r):
    if 'cut_box' not in r: return 'NO-DATA'
    f = []
    if not r.get('heading') or not all(r['heading']): f.append('heading')
    if not r.get('footer') or not all(r['footer']): f.append('footer')
    if any(h > 1 for h in r['highlights']): f.append('highlights>1')
    if any(v for v in r['cut_ink'].values()) or any(v for v in r['maker_cut_text'].values()): f.append('cut-text-line')
    if any(v for v in r['maker_cut_box'].values()): f.append('cut-box')
    if r.get('end_gap') is None or r['end_gap'] < 0 or not r.get('end_atEnd'): f.append('end-gap')
    if r['occluded'] or r['overlaps']: f.append('overlap/occl')
    if r['chai'] and any(c is None or c[0] < 0.5 or c[1] < 0.5 for c in r['chai']): f.append('chai')
    if r['day'] == 'bigday' and not (r.get('unlock') and all(r['unlock'])): f.append('unlock-missing')
    return 'PASS' if not f else 'FAIL(' + ','.join(f) + ')'

if __name__ == '__main__':
    out = []
    out.append('| cfg | day | side | heading in view (arr,set) | footer ok (arr,set,end) | highlights (arr,set,end) / kind | cut text lines, ink rule (arr/set/end) | cut text lines, full box (arr/set/end) + maker-rule cut units | end: atEnd, gap to footer top (px; fade) | occl/ovl (LS; maker) | Chai in-view/not-under-sheet (arr,set) | unlock (bigday) | result |')
    out.append('|---|---|---|---|---|---|---|---|---|---|---|---|---|')
    for r in rows:
        if 'cut_box' not in r:
            out.append(f"| {r['cfg']} | {r['day']} | {r['side']} | {r.get('missing')} |||||||||| ")
            continue
        cb = r['cut_box']; ci = r['cut_ink']
        fmt = lambda d: '/'.join(str(len(d.get(k, []))) if k in d else '-' for k in ('arrival', 'settled', 'end'))
        cut_detail = ''
        for k in ('arrival', 'settled', 'end'):
            if ci.get(k): cut_detail += f' [{k}: ' + '; '.join(ci[k]) + ']'
        out.append(f"| {r['cfg']} | {r['day']} | {r['side']}{' (' + r['missing'] + ')' if r.get('missing') else ''} | {r['heading']} | {r['footer']} | {r['highlights']} {r.get('highlight_kind') or ('unlock' if r.get('unlock') and r['unlock'][0] else '')} groups={r.get('distinct_groups')} | {fmt(ci)}{cut_detail} | {fmt(cb)} ; maker: {r['maker_cut']} | {r.get('end_atEnd')}, {r.get('end_gap')} ; {r.get('fade')} | {r['occluded']}+{r['overlaps']} ; {r['maker_occl']}+{r['maker_ovl']} | {r['chai']} | {r.get('unlock', '-')} {r.get('unlock_status', '')} | {verdict(r)} |")
    out.append('')
    out.append('## Rewards comparison BEFORE vs AFTER')
    out.append('| cfg | day | pills B/A | missing in AFTER | extra in AFTER | numbers equal | announce equal | arithmetic differs |')
    out.append('|---|---|---|---|---|---|---|---|')
    for r in rewards_rows:
        if 'missing' in r:
            out.append(f"| {r['cfg']} | {r['day']} | no {r['missing']} data |||||| "); continue
        ar = r['arith']
        out.append(f"| {r['cfg']} | {r['day']} | {r['before_n']}/{r['after_n']} | {r['missing_in_after']} | {r['extra_in_after']} | {r['numbers_equal']} | {r['announce_equal']} | {('only_before=' + str(ar['only_before']) + ' only_after=' + str(ar['only_after'])) if ar else 'n/a'} |")
    open(f'{ROOT}/../acceptance-table.md', 'w').write('\n'.join(out))
    print('\n'.join(out))

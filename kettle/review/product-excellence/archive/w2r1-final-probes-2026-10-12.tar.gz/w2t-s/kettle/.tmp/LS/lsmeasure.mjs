// Lane S (reviewer) independent in-page measurement. Does NOT use data-fold or the maker's unit model:
// every visible text line (TreeWalker over the sheet's text nodes) is compared with the footer's top (the fold).
export function lsInPage({ phase }) {
  const norm = (t) => (t || '').replace(/\s+/g, ' ').trim();
  const R = (r) => [r.left, r.top, r.width, r.height].map((v) => Math.round(v * 10) / 10);
  const region = document.querySelector('[data-focus-view] [role=region]');
  if (!region) return { phase, error: 'no summary region' };
  const sc = region.firstElementChild;
  const sheet = sc.firstElementChild;
  const footer = region.querySelector('footer');
  const scR = sc.getBoundingClientRect();
  const fR = footer.getBoundingClientRect();
  const F = Math.min(fR.top, scR.bottom);
  const cs = getComputedStyle(sc);
  const mask = cs.maskImage || cs.webkitMaskImage || '';
  const fade = +((/100% - (\d+(?:\.\d+)?)px/.exec(mask) || [])[1] ?? 0);

  // ---- every visible text line ----
  const walker = document.createTreeWalker(sheet, NodeFilter.SHOW_TEXT);
  const lines = [];
  let n;
  while ((n = walker.nextNode())) {
    const t = norm(n.nodeValue);
    if (!t) continue;
    const p = n.parentElement;
    if (!p || p.closest('.sr-only, [hidden], svg, script, style')) continue;
    const cst = getComputedStyle(p);
    if (cst.visibility === 'hidden' || cst.display === 'none') continue;
    const range = document.createRange();
    range.selectNodeContents(n);
    const rects = [...range.getClientRects()].filter((x) => x.width > 0.5 && x.height > 0.5).sort((a, b) => a.top - b.top);
    // merge rects of one node that share a visual line
    const rows = [];
    for (const x of rects) {
      const l = rows.at(-1);
      if (l && x.top < l.bottom - Math.min(x.height, l.bottom - l.top) / 2) { l.top = Math.min(l.top, x.top); l.bottom = Math.max(l.bottom, x.bottom); l.left = Math.min(l.left, x.left); l.right = Math.max(l.right, x.right); }
      else rows.push({ top: x.top, bottom: x.bottom, left: x.left, right: x.right });
    }
    for (const r of rows) lines.push({ text: t.slice(0, 48), top: r.top, bottom: r.bottom, left: r.left, right: r.right, el: p });
  }
  // classify against the fold F (footer top), the scroll area top, and the fade
  const classify = (u, shrink) => {
    const h = u.bottom - u.top;
    const top = u.top + h * shrink, bottom = u.bottom - h * shrink;
    if (bottom <= scR.top + 0.5) return 'above';
    if (top < scR.top - 0.5) return 'cut-top';
    if (top >= F - 0.5) return 'below';
    if (bottom > F + 0.5) return 'straddle-fold';      // crosses the footer's top edge
    if (bottom > F - fade + 0.5) return 'in-fade';     // wholly above the fold but inside the bottom fade
    return 'clear';
  };
  const lineOut = lines.map((u) => ({ text: u.text, top: Math.round(u.top), bottom: Math.round(u.bottom), box: classify(u, 0), ink: classify(u, 0.18) }));
  const tally = (k) => lineOut.reduce((a, u) => ((a[u[k]] = (a[u[k]] || 0) + 1), a), {});
  const cutLines = lineOut.filter((u) => u.box === 'straddle-fold' || u.box === 'in-fade' || u.box === 'cut-top');
  const cutInk = lineOut.filter((u) => u.ink === 'straddle-fold' || u.ink === 'in-fade' || u.ink === 'cut-top');

  // occlusion at the middle of each line that is on screen above the fold
  const occl = [];
  for (const u of lines) {
    const y = (u.top + u.bottom) / 2;
    if (y < scR.top + 1 || y > F - 1 || u.bottom > F) continue;
    const x = Math.min(u.right - 1, Math.max(u.left + 1, (u.left + u.right) / 2));
    const hit = document.elementFromPoint(x, y);
    if (!hit || !(hit === u.el || u.el.contains(hit) || hit.contains(u.el))) occl.push({ text: u.text, at: [Math.round(x), Math.round(y)], hit: hit ? `${hit.tagName}.${String(hit.className?.baseVal ?? hit.className ?? '').slice(0, 40)}` : null });
  }

  // ---- blocks: rewards, highlight, unlock, details toggle, task, setup ----
  const rewards = region.querySelector('[aria-label="Rewards"]');
  const lis = rewards ? [...rewards.children] : [];
  const sty = (el) => { const c = getComputedStyle(el); return { bg: c.backgroundColor, border: c.borderTopWidth + ' ' + c.borderTopColor, fs: c.fontSize, fw: c.fontWeight, pad: c.paddingTop + ' ' + c.paddingLeft, rad: c.borderRadius, shadow: c.boxShadow === 'none' ? '' : c.boxShadow.slice(0, 40) }; };
  const strip = (el) => { const c = el.cloneNode(true); c.querySelectorAll('.sr-only, svg').forEach((x) => x.remove()); return norm(c.textContent); };
  const pills = lis.map((li) => { const r = li.getBoundingClientRect(); return { visible: strip(li), full: norm(li.textContent), kind: li.dataset.kind ?? null, highlight: li.hasAttribute('data-highlight'), milestone: li.dataset.milestone ?? null, box: R(r), style: sty(li) }; });
  // independent "distinctness": group pills by computed style signature; the minority groups are "highlighted"
  const sig = (p) => JSON.stringify([p.style.bg, p.style.border, p.style.fs, p.style.pad, p.style.rad, p.style.shadow]);
  const groups = {};
  for (const p of pills) (groups[sig(p)] ||= []).push(p.visible);
  const distinct = Object.entries(groups).map(([k, v]) => ({ sig: k, n: v.length, sample: v.slice(0, 3) }));

  const unlockSec = [...region.querySelectorAll('section')].find((x) => /in your nook/.test(x.getAttribute('aria-label') || ''));
  const unlock = unlockSec ? { label: unlockSec.getAttribute('aria-label'), box: R(unlockSec.getBoundingClientRect()), hasCanvas: !!unlockSec.querySelector('canvas'), hasStillGlyph: !!unlockSec.querySelector('svg, img'), status: classify({ top: unlockSec.getBoundingClientRect().top, bottom: unlockSec.getBoundingClientRect().bottom }, 0) } : null;
  const toggle = [...region.querySelectorAll('button')].find((x) => /How your leaves added up/.test(x.textContent || ''));
  const tgR = toggle?.getBoundingClientRect();
  const detailsBody = toggle && document.getElementById(toggle.getAttribute('aria-controls'));
  const detailsOpen = !!(detailsBody && !detailsBody.hidden);

  // pairwise overlap between sibling blocks of the sheet and between the reward li's
  const blocks = [...[...sheet.children].map((el) => ({ k: el.tagName.toLowerCase() + '.' + String(el.className).slice(0, 18), el })), ...lis.map((el, i) => ({ k: 'li' + i, el }))];
  const overlaps = [];
  for (let i = 0; i < blocks.length; i++) for (let j = i + 1; j < blocks.length; j++) {
    const a = blocks[i].el, b = blocks[j].el;
    if (a.contains(b) || b.contains(a)) continue;
    const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
    if (ra.height < 1 || rb.height < 1) continue;
    const ix = Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left), iy = Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top);
    if (ix > 0.5 && iy > 0.5) overlaps.push([blocks[i].k, blocks[j].k, Math.round(ix), Math.round(iy)]);
  }

  // ---- heading ----
  const h1 = region.querySelector('h1');
  const hR = h1?.getBoundingClientRect();
  const heading = h1 ? { text: norm(h1.textContent), box: R(hR), inViewport: hR.top >= 0 && hR.bottom <= innerHeight && hR.bottom <= F, inScrollArea: hR.top >= scR.top - 0.5 && hR.bottom <= F } : null;

  // ---- footer buttons: five probe points each ----
  const fb = [...footer.querySelectorAll('button')].map((b) => {
    const r = b.getBoundingClientRect();
    const pts = [[0.5, 0.5], [0.15, 0.2], [0.85, 0.2], [0.15, 0.8], [0.85, 0.8]].map(([a, c]) => [r.left + r.width * a, r.top + r.height * c]);
    const hits = pts.map(([x, y]) => { const e = document.elementFromPoint(x, y); return !!e && b.contains(e); });
    return { name: norm(b.textContent), box: R(r), hitsOfFive: hits.filter(Boolean).length, inViewport: r.top >= 0 && r.bottom <= innerHeight + 0.5 && r.left >= 0 && r.right <= innerWidth + 0.5 };
  });

  // ---- Chai ----
  const chai = document.querySelector('[data-focus-view] [data-pose]');
  const cR = chai?.getBoundingClientRect();
  const sR = sheet.getBoundingClientRect();
  let chaiInfo = null;
  if (cR) {
    const vis = Math.max(0, Math.min(cR.right, innerWidth) - Math.max(cR.left, 0)) * Math.max(0, Math.min(cR.bottom, innerHeight) - Math.max(cR.top, 0)) / (cR.width * cR.height);
    // share of Chai's box not covered by the sheet's top edge (stacked) or the sheet's left edge (side by side)
    const sideBySide = sR.left > cR.right || sR.right < cR.left;
    const bottomVisible = sideBySide ? cR.bottom : Math.min(cR.bottom, sR.top);
    const above = Math.max(0, bottomVisible - Math.max(cR.top, 0)) / cR.height;
    const img = chai.querySelector('img, svg, canvas') || chai;
    chaiInfo = { box: R(cR), inViewportShare: Math.round(vis * 100) / 100, notUnderSheetShare: Math.round(above * 100) / 100, sideBySide, tag: img.tagName };
  }

  // ---- toasts / other fixed layers over the region ----
  const toasts = [...document.querySelectorAll('[role=status], [role=alert], [data-toast], [class*=toast i]')].filter((x) => { const r = x.getBoundingClientRect(); return r.width > 4 && r.height > 4 && norm(x.textContent) && !region.contains(x); }).map((x) => ({ text: norm(x.textContent).slice(0, 60), box: R(x.getBoundingClientRect()) }));

  // ---- the last text line of the sheet vs the footer ----
  const vis = lines.slice().sort((a, b) => a.bottom - b.bottom);
  const lastLine = vis.at(-1);
  const maxScroll = sc.scrollHeight - sc.clientHeight;
  return {
    phase, vw: innerWidth, vh: innerHeight, dpr: devicePixelRatio, htmlFont: getComputedStyle(document.documentElement).fontSize,
    scroll: { top: Math.round(sc.scrollTop), max: Math.round(maxScroll), atEnd: sc.scrollTop >= maxScroll - 1, rect: R(scR) },
    F: Math.round(F * 10) / 10, footerTop: Math.round(fR.top * 10) / 10, fade,
    heading, footer: fb,
    lineCount: lines.length, tallyBox: tally('box'), tallyInk: tally('ink'),
    cutLinesBox: cutLines, cutLinesInk: cutInk, occluded: occl, overlaps,
    lastLine: lastLine ? { text: lastLine.text, bottom: Math.round(lastLine.bottom * 10) / 10, gapToFooterTop: Math.round((F - lastLine.bottom) * 10) / 10 } : null,
    detailsToggle: tgR ? { box: R(tgR), status: classify({ top: tgR.top, bottom: tgR.bottom }, 0), open: detailsOpen } : null,
    rewardsListLabel: rewards?.getAttribute('aria-label') ?? null, pills, distinct, highlightCount: pills.filter((p) => p.highlight).length,
    unlock, chai: chaiInfo, toasts,
    announce: norm(region.querySelector('[role=status]')?.textContent),
    lines: lineOut,
  };
}

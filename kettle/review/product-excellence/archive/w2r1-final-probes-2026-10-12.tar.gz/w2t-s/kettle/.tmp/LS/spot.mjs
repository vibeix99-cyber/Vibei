// Lane S: real-input spot checks on the summary. node spot.mjs --base URL --cfg 375x667@2:light:200 --day celebrate --mode main|skip --tap touch|mouse --out DIR
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import { lsInPage } from './lsmeasure.mjs';
const require = createRequire('/home/user/wt/w2s/kettle/package.json');
const { chromium } = require('playwright');
const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const FIXED = Date.parse('2026-10-11T07:40:00.000Z');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const m = args.cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
const [W, H, DPR, theme, text] = [+m[1], +m[2], +m[3], m[4], +m[5]];
const mode = args.mode, day = args.day ?? 'celebrate', tap = args.tap ?? 'touch';
const dir = `${args.out}/${W}x${H}-${theme}-t${text}-${day}-${mode}`;
mkdirSync(dir, { recursive: true });
const log = { cfg: args.cfg, day, mode, tap, base: args.base, steps: [], errors: [] };
const step = (name, data) => { log.steps.push({ name, ...data }); console.log(name, JSON.stringify(data).slice(0, 400)); };

const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
try {
  const mobile = W < 900;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  const p = await ctx.newPage();
  await p.clock.install({ time: FIXED });
  await p.clock.resume();
  p.on('pageerror', (e) => log.errors.push(e.message.slice(0, 200)));
  const cdp = await ctx.newCDPSession(p);
  const seed = day === 'celebrate' ? 'celebrate' : 'veteran';
  await p.goto(`${args.base}/?debug&seed=${seed}&theme=${theme}#/`);
  await p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 }).catch(() => {});
  await p.evaluate(() => document.fonts.ready);
  await p.evaluate((x) => window.__kettle.settings.getState().set(x), { muted: true, autoStartBreaks: false, autoStartFocus: false });
  await sleep(1200);
  await p.getByRole('button', { name: /put the kettle on/i }).first().click({ timeout: 30_000 });
  await sleep(2500);
  await p.evaluate(() => window.__kettle.finish());
  await p.waitForFunction(() => location.hash.includes('done'), null, { timeout: 30_000 }).catch(() => {});
  await sleep(day === 'celebrate' ? 9000 : 4500);
  const M = () => p.evaluate(lsInPage, { phase: 'x' });
  const shot = (name) => p.screenshot({ path: `${dir}/${name}.png`, animations: 'disabled', timeout: 120_000 }).catch((e) => log.errors.push(name + ': ' + e.message.slice(0, 100)));
  const brief = (s) => ({ scrollTop: s.scroll.top, max: s.scroll.max, atEnd: s.scroll.atEnd, F: s.F, cutBox: s.cutLinesBox.map((c) => `${c.box}:${c.text}`), occluded: s.occluded.length, last: s.lastLine, highlights: s.highlightCount });
  let s0 = await M();
  step('arrival', { ...brief(s0), heading: s0.heading, footer: s0.footer.map((f) => `${f.name} hit${f.hitsOfFive}/5 inView=${f.inViewport}`), pills: s0.pills.length });
  await shot('01-arrival');
  const scR = s0.scroll.rect; // x,y,w,h

  const tapAt = async (x, y) => (tap === 'touch' ? p.touchscreen.tap(x, y) : p.mouse.click(x, y));
  const scrollTop = () => p.evaluate(() => document.querySelector('[data-focus-view] [role=region]').firstElementChild.scrollTop);

  if (mode === 'kbd' || mode === 'skip') {
    // Keyboard: Tab through the summary
    await p.evaluate(() => document.activeElement?.blur?.());
    const stops = [];
    for (let i = 0; i < 14; i++) {
      await p.keyboard.press('Tab');
      await sleep(250);
      const info = await p.evaluate(() => {
        const e = document.activeElement;
        if (!e || e === document.body) return { none: true };
        const r = e.getBoundingClientRect();
        const region = document.querySelector('[data-focus-view] [role=region]');
        const footer = region?.querySelector('footer');
        const sc = region?.firstElementChild;
        const scR = sc.getBoundingClientRect(), fR = footer.getBoundingClientRect();
        const F = Math.min(fR.top, scR.bottom);
        const inFooter = !!footer?.contains(e);
        const c = getComputedStyle(e);
        const hit = document.elementFromPoint((r.left + r.right) / 2, (r.top + r.bottom) / 2);
        const fv = (() => { try { return e.matches(':focus-visible'); } catch { return null; } })();
        return { tag: e.tagName, name: (e.getAttribute('aria-label') || e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 40), box: [r.left, r.top, r.width, r.height].map(Math.round), inFooter, bottomVsF: Math.round(r.bottom - F), inRegionRect: r.top >= scR.top - 0.5 && r.bottom <= scR.bottom + 0.5, hitOK: !!hit && (e.contains(hit) || hit.contains(e)), outline: `${c.outlineStyle} ${c.outlineWidth} ${c.outlineColor} off ${c.outlineOffset}`, boxShadow: c.boxShadow === 'none' ? 'none' : c.boxShadow.slice(0, 70), focusVisible: fv, scrollTop: Math.round(sc.scrollTop), inViewport: r.top >= 0 && r.bottom <= innerHeight && r.left >= 0 && r.right <= innerWidth };
      });
      stops.push(info);
      const clip = info.box ? { x: Math.max(0, info.box[0] - 16), y: Math.max(0, info.box[1] - 16), width: Math.min(W - Math.max(0, info.box[0] - 16), info.box[2] + 32), height: Math.min(H - Math.max(0, info.box[1] - 16), info.box[3] + 32) } : null;
      if (clip && clip.width > 4 && clip.height > 4 && i < 8) await p.screenshot({ path: `${dir}/tab${String(i + 1).padStart(2, '0')}.png`, clip, animations: 'disabled' }).catch(() => {});
      if (info.none) break;
    }
    step('tab-stops', { n: stops.length, stops });
    await shot('02-after-tab');
    if (mode === 'skip') {
      const sk = p.getByRole('button', { name: /skip break/i });
      const bx = await sk.boundingBox();
      step('skip-box', { bx });
      await tapAt(bx.x + bx.width / 2, bx.y + bx.height / 2);
      await sleep(1500);
      step('after-skip-tap', { hash: await p.evaluate(() => location.hash), summaryGone: await p.evaluate(() => !document.querySelector('[data-focus-view] [role=region] h1')) });
      await shot('03-after-skip');
    }
  }

  if (mode === 'main') {
    // 1) real wheel. Try several pointer positions; record the scroll delta each gives.
    const pts = [[scR[0] + scR[2] / 2, scR[1] + scR[3] / 2], [scR[0] + scR[2] - 14, scR[1] + scR[3] / 2], [scR[0] + 14, scR[1] + scR[3] * 0.8], [scR[0] + scR[2] / 2, scR[1] + scR[3] * 0.85]];
    const wheelTries = [];
    for (const [x, y] of pts) {
      const before = await scrollTop();
      await p.mouse.move(x, y);
      await p.mouse.wheel(0, 150);
      await sleep(400);
      const after = await scrollTop();
      const over = await p.evaluate(([x, y]) => { const e = document.elementFromPoint(x, y); return e ? `${e.tagName}.${String(e.className?.baseVal ?? e.className).slice(0, 30)}` : null; }, [x, y]);
      wheelTries.push({ at: [Math.round(x), Math.round(y)], over, before, after, delta: after - before });
    }
    step('wheel-tries', { wheelTries });
    await shot('02-after-wheel');
    // 2) real touch drag (CDP touch gesture) - scroll back up then down
    const cx = scR[0] + scR[2] / 2, cy = scR[1] + scR[3] * 0.55;
    const t0 = await scrollTop();
    await cdp.send('Input.synthesizeScrollGesture', { x: cx, y: cy, yDistance: 160, gestureSourceType: 'touch', speed: 600 }).catch((e) => log.errors.push('gesture-up ' + e.message.slice(0, 80)));
    await sleep(500);
    const t1 = await scrollTop();
    await cdp.send('Input.synthesizeScrollGesture', { x: cx, y: cy, yDistance: -160, gestureSourceType: 'touch', speed: 600 }).catch((e) => log.errors.push('gesture-down ' + e.message.slice(0, 80)));
    await sleep(500);
    const t2 = await scrollTop();
    step('touch-gesture', { start: t0, afterSwipeDown160: t1, afterSwipeUp160: t2 });
    await shot('03-after-touch');
    // 3) reach everything: go to the top, then walk down in wheel steps; union of the lines that were 'clear'
    await p.mouse.move(scR[0] + scR[2] - 14, scR[1] + scR[3] / 2);
    for (let i = 0; i < 20; i++) { await p.mouse.wheel(0, -300); await sleep(40); }
    await sleep(400);
    const seen = new Map(); let allLines = []; const ctl = new Map();
    for (let i = 0; i < 40; i++) {
      const s = await M();
      if (i === 0) step('top', brief(s));
      s.lines.forEach((l, idx) => { const k = idx + ':' + l.text; if (!seen.has(k)) seen.set(k, false); if (l.box === 'clear') seen.set(k, true); });
      allLines = s.lines.map((l, idx) => idx + ':' + l.text);
      if (s.scroll.atEnd) break;
      await p.mouse.wheel(0, 90); await sleep(120);
    }
    const never = allLines.filter((k) => !seen.get(k));
    step('reachability-walk', { total: allLines.length, neverClear: never });
    // 4) tap the details toggle (it is below the pills; bring it into the clear zone first)
    const tg = p.getByRole('button', { name: /How your leaves added up/ });
    let sTop = await M();
    step('before-toggle', { ...brief(sTop), toggle: sTop.detailsToggle });
    await shot('04-before-toggle');
    let guard = 0;
    while (guard++ < 30) {
      const s = await M();
      if (s.detailsToggle && s.detailsToggle.status === 'clear') break;
      await p.mouse.move(scR[0] + scR[2] - 14, scR[1] + scR[3] / 2);
      await p.mouse.wheel(0, 60); await sleep(150);
    }
    const sB = await M();
    const tb = await tg.boundingBox();
    const hitTg = await p.evaluate(([x, y]) => { const e = document.elementFromPoint(x, y); return e ? e.closest('button')?.textContent?.trim().slice(0, 30) ?? e.tagName : null; }, [tb.x + tb.width / 2, tb.y + tb.height / 2]);
    step('toggle-ready', { status: sB.detailsToggle?.status, box: tb, hitTarget: hitTg });
    await tapAt(tb.x + tb.width / 2, tb.y + tb.height / 2);
    await sleep(600);
    const expanded = await tg.getAttribute('aria-expanded');
    step('toggle-tapped', { ariaExpanded: expanded });
    await shot('05-details-open');
    // 5) scroll to the very end with the wheel; the last line must clear the footer
    await p.mouse.move(scR[0] + scR[2] - 14, scR[1] + scR[3] / 2);
    for (let i = 0; i < 25; i++) { await p.mouse.wheel(0, 200); await sleep(50); }
    await sleep(700);
    const sE = await M();
    step('end-state', { ...brief(sE), tallyBox: sE.tallyBox, cutInk: sE.cutLinesInk.length, lastGapToFooter: sE.lastLine?.gapToFooterTop, footer: sE.footer.map((f) => `${f.name} hit${f.hitsOfFive}/5`) });
    await shot('06-end');
    // 6) tap Tea time
    const tea = p.getByRole('button', { name: /tea (time|break)/i }).first();
    const bx = await tea.boundingBox();
    await tapAt(bx.x + bx.width / 2, bx.y + bx.height / 2);
    await sleep(1800);
    step('after-tea-tap', { hash: await p.evaluate(() => location.hash), summaryGone: await p.evaluate(() => !document.querySelector('[data-focus-view] [role=region] h1')), body: (await p.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 160))) });
    await shot('07-after-tea');
  }
  await ctx.close();
} catch (e) {
  log.errors.push('FATAL ' + e.message.slice(0, 300));
  console.log('FATAL', e.message);
} finally {
  writeFileSync(`${dir}/spot.json`, JSON.stringify(log, null, 1));
  await b.close();
}

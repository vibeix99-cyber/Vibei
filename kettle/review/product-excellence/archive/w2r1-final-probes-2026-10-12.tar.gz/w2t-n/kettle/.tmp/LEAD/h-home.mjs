// LEAD checker, W2 maker H: Brew length at rest + real taps + keyboard reach; first visit. One browser, many configs.
// node h-home.mjs --base http://127.0.0.1:5352 --label trial --out <dir> --cfgs 390x844@3:light:100,...
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const FIXED = Date.parse('2026-10-11T07:40:00.000Z');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const all = {};

async function ctxFor(W, H, DPR, theme, text) {
  const mobile = W < 900;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  const p = await ctx.newPage();
  await p.clock.install({ time: FIXED });
  await p.clock.resume();
  return { ctx, p, mobile };
}
const ready = (p) => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 }).catch(() => {});

const measureOptions = (p) => p.evaluate(() => {
  const opts = [...document.querySelectorAll('#home-brew-length [role=radio]')];
  const dock = document.querySelector('main [data-toast-above]') || document.querySelector('[data-toast-above]');
  const d = dock?.getBoundingClientRect();
  const tab = document.querySelector('nav[aria-label] a, nav a')?.closest('nav')?.getBoundingClientRect();
  return {
    scrollY: Math.round(scrollY),
    dock: d ? [Math.round(d.top), Math.round(d.bottom)] : null,
    options: opts.map((o) => {
      const r = o.getBoundingClientRect();
      const inDock = !!dock && dock.contains(o);
      let on = 0;
      for (const fx of [0.2, 0.5, 0.8]) for (const fy of [0.2, 0.5, 0.8]) {
        const x = r.left + r.width * fx, y = r.top + r.height * fy;
        const el = x >= 0 && y >= 0 && x < innerWidth && y < innerHeight ? document.elementFromPoint(x, y) : null;
        if (el && (el === o || o.contains(el))) on++;
      }
      return { name: (o.getAttribute('aria-label') || o.textContent || '').replace(/\s+/g, ' ').trim(), box: [r.left, r.top, r.width, r.height].map((v) => Math.round(v * 10) / 10), wholly: r.top >= 0 && r.bottom <= innerHeight && r.left >= 0 && r.right <= innerWidth, inDock, on, checked: o.getAttribute('aria-checked') };
    }),
    start: document.querySelector('main button[class*="cta"]')?.textContent?.trim() ?? [...document.querySelectorAll('button')].find((x) => /^Put the kettle on/.test(x.textContent?.trim() || ''))?.textContent?.trim(),
  };
});

for (const cfg of args.cfgs.split(',')) {
  const m = cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
  const [W, H, DPR, theme, text] = [+m[1], +m[2], +m[3], m[4], +m[5]];
  const tag = `${W}x${H}-${theme}-t${text}`;
  const dir = `${args.out}/${args.label}/${tag}`;
  mkdirSync(dir, { recursive: true });
  const res = { errors: [] };
  // --- Home at rest, then real taps, then keyboard
  {
    const { ctx, p, mobile } = await ctxFor(W, H, DPR, theme, text);
    p.on('pageerror', (e) => res.errors.push(e.message.slice(0, 160)));
    try {
      await p.goto(`${args.base}/?debug&seed=veteran&theme=${theme}#/`); await ready(p); await p.evaluate(() => document.fonts.ready);
      await p.evaluate(() => window.__kettle.settings.getState().set({ muted: true, autoStartBreaks: false, autoStartFocus: false }));
      await sleep(1500);
      res.rest = await measureOptions(p);
      await p.screenshot({ path: `${dir}/01-home.png`, animations: 'disabled' });
      res.taps = [];
      for (const want of ['15 min', '50 min', '25 min']) {
        const o = res.rest.options.find((x) => x.name.startsWith(want));
        if (!o || !o.wholly || o.on < 5) { res.taps.push({ want, skipped: 'not on screen at rest' }); continue; }
        const [x, y, w, h] = o.box;
        if (mobile) await p.touchscreen.tap(x + w / 2, y + h / 2); else await p.mouse.click(x + w / 2, y + h / 2);
        await sleep(450);
        const after = await measureOptions(p);
        res.taps.push({ want, start: after.start, checked: after.options.find((z) => z.name.startsWith(want))?.checked, scrollY: after.scrollY, hash: await p.evaluate(() => location.hash) });
      }
      const cu = res.rest.options.find((x) => /Custom|^\d+ min$/.test(x.name) && !/^(15|25|50) min/.test(x.name));
      if (cu && cu.wholly) {
        const [x, y, w, h] = cu.box;
        if (mobile) await p.touchscreen.tap(x + w / 2, y + h / 2); else await p.mouse.click(x + w / 2, y + h / 2);
        await sleep(700);
        res.custom = await p.evaluate(() => ({ dialog: !!document.querySelector('[role=dialog]'), title: document.querySelector('[role=dialog] h2')?.textContent?.trim() }));
        await p.screenshot({ path: `${dir}/01-home-custom.png`, animations: 'disabled' });
        await p.keyboard.press('Escape'); await sleep(500);
      }
      // keyboard: from the top of the page, Tab until a Brew length radio has focus
      await p.goto(`${args.base}/?debug&seed=veteran&theme=${theme}#/`); await ready(p); await sleep(1200);
      await p.evaluate(() => { document.activeElement?.blur(); window.scrollTo(0, 0); });
      let stops = 0, reached = null;
      for (; stops < 40; stops++) {
        await p.keyboard.press('Tab');
        reached = await p.evaluate(() => { const a = document.activeElement; if (!a?.closest('#home-brew-length')) return null; const r = a.getBoundingClientRect(); const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return { name: a.textContent?.trim(), box: [r.left, r.top, r.width, r.height].map(Math.round), onTop: !!el && (el === a || a.contains(el)), outline: getComputedStyle(a).outlineStyle + ' ' + getComputedStyle(a).outlineWidth }; });
        if (reached) break;
      }
      res.keyboard = { stops: stops + 1, reached };
      if (reached) { await p.keyboard.press('ArrowLeft'); await sleep(300); res.keyboard.left = await p.evaluate(() => document.activeElement?.textContent?.trim()); res.keyboard.start = await p.evaluate(() => [...document.querySelectorAll('button')].find((x) => /^Put the kettle on/.test(x.textContent?.trim() || ''))?.textContent?.trim()); }
      await p.screenshot({ path: `${dir}/01-home-keyboard.png`, animations: 'disabled' });
    } catch (e) { res.errors.push('home: ' + e.message.slice(0, 200)); }
    await ctx.close();
  }
  // --- First visit
  {
    const { ctx, p, mobile } = await ctxFor(W, H, DPR, theme, text);
    try {
      await p.goto(`${args.base}/?debug&seed=fresh&onboarded=0&theme=${theme}#/welcome`); await ready(p); await p.evaluate(() => document.fonts.ready); await sleep(1500);
      res.first = await p.evaluate(() => {
        const bubble = document.querySelector('h1')?.closest('div');
        const btns = [...document.querySelectorAll('main button, button')].filter((x) => x.getBoundingClientRect().height > 0).map((x) => { const r = x.getBoundingClientRect(); return { name: x.textContent.trim().slice(0, 40), box: [r.left, r.top, r.width, r.height].map(Math.round), cls: x.className.toString().slice(0, 40) }; });
        return { h1: document.querySelector('h1')?.textContent?.trim(), line: document.querySelector('h1')?.nextElementSibling?.textContent?.trim(), docH: document.documentElement.scrollHeight, vh: innerHeight, btns };
      });
      await p.screenshot({ path: `${dir}/00-first-visit.png`, animations: 'disabled' });
      const go = p.getByRole('button', { name: /^Start a 15-min brew/ });
      await go.scrollIntoViewIfNeeded();
      const bb = await go.boundingBox();
      if (mobile) await p.touchscreen.tap(bb.x + bb.width / 2, bb.y + bb.height / 2); else await p.mouse.click(bb.x + bb.width / 2, bb.y + bb.height / 2);
      await p.waitForFunction(() => location.hash === '#/focus', null, { timeout: 15_000 }).catch(() => {});
      await sleep(800);
      res.firstBrew = await p.evaluate(() => { const s = window.__kettle.timer.getState(); return { hash: location.hash, status: s.status, plannedMs: s.plannedMs, intention: s.intention, name: window.__kettle.settings.getState().name }; });
    } catch (e) { res.errors.push('first: ' + e.message.slice(0, 200)); }
    await ctx.close();
  }
  all[tag] = res;
  const o = res.rest?.options || [];
  console.log(args.label, tag, 'dock', JSON.stringify(res.rest?.dock), 'opts', o.map((x) => `${x.name.split(' ')[0]}:${x.box[1]}-${Math.round(x.box[1] + x.box[3])} ${x.box[2]}x${x.box[3]} w${x.wholly ? 1 : 0} on${x.on}`).join(' | '), '| taps', JSON.stringify(res.taps?.map((t) => t.skipped ? 'skip' : `${t.want}->${t.start?.match(/\d+ min/)?.[0]}`)), '| custom', JSON.stringify(res.custom), '| kb', res.keyboard?.stops, JSON.stringify(res.keyboard?.reached?.onTop), '| first', JSON.stringify(res.first?.line)?.slice(0, 70), res.first?.docH, '/', res.first?.vh, JSON.stringify(res.firstBrew), '| err', res.errors.length);
}
writeFileSync(`${args.out}/${args.label}/home-${Date.now()}.json`, JSON.stringify(all, null, 1));
await b.close();

// LEAD checker, W2 maker H: after a real End, what covers Today's "Mark done" while End's toasts are up?
// node h-toast.mjs --base http://127.0.0.1:5342 --label trial --cfg 390x844@3:light:100 --out <dir> [--scroll 1]
// Real input: typing the task, Put the kettle on, End session → End session (sheet), and the tap on Mark done.
// Debug API for setup only: ff (fast-forward 3 min) and muting.
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const m = args.cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
const [W, H, DPR, theme, text] = [+m[1], +m[2], +m[3], m[4], +m[5]];
const mobile = W < 900;
const scrollFirst = args.scroll === '1';
const dir = `${args.out}/${args.label}`;
mkdirSync(dir, { recursive: true });
const tag = `${W}x${H}-${theme}-t${text}${scrollFirst ? '-scrolled' : ''}${args.prime === '1' ? '-prime' : ''}`;
const out = { base: args.base, label: args.label, cfg: args.cfg, scrollFirst, samples: [], tap: null, errors: [] };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });

async function run(mode) {
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  if (args.prime === '1') await ctx.addInitScript(() => { try { if (localStorage.getItem('kettle:settings')) return; localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => out.errors.push(e.message.slice(0, 160)));
  await p.goto(args.prime === '1' ? `${args.base}/?debug&theme=${theme}#/` : `${args.base}/?debug&seed=newbie&theme=${theme}#/`);
  await p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
  await p.evaluate(() => window.__kettle.settings.getState().set({ muted: true, autoStartBreaks: false, autoStartFocus: false }));
  const field = p.getByRole('textbox', { name: /What are you brewing/ });
  await field.click();
  await p.keyboard.type('Chapter 3 notes');
  await p.keyboard.press('Escape').catch(() => {});
  const start = p.getByRole('button', { name: /^Put the kettle on · / });
  await start.scrollIntoViewIfNeeded();
  await start.click();
  await p.waitForFunction(() => location.hash === '#/focus', null, { timeout: 15_000 });
  await sleep(1500);
  await p.evaluate(() => window.__kettle.ff(3 * 60_000));
  await sleep(500);
  await p.getByRole('button', { name: 'End session' }).first().click();
  const dlg = p.getByRole('dialog', { name: 'Leave the kettle early?' });
  await dlg.getByRole('button', { name: 'End session' }).click();
  const t0 = Date.now();
  await p.waitForFunction(() => location.hash === '#/', null, { timeout: 15_000 });
  const markDone = p.getByRole('button', { name: /^Mark “Chapter 3 notes” done/ });
  await markDone.waitFor({ state: 'visible', timeout: 10_000 }).catch(() => out.errors.push(`${mode}: mark done never visible`));
  if (scrollFirst) await markDone.scrollIntoViewIfNeeded().catch(() => {});
  if (mode === 'sample') {
    for (let i = 0; i < 70; i++) {
      const s = await p.evaluate(() => {
        const r = (e) => { if (!e) return null; const b = e.getBoundingClientRect(); return [Math.round(b.left), Math.round(b.top), Math.round(b.width), Math.round(b.height)]; };
        const md = [...document.querySelectorAll('button')].find((x) => /^Mark “Chapter 3 notes” done/.test(x.getAttribute('aria-label') || ''));
        const toasts = [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => ({ text: li.innerText.replace(/\s+/g, ' ').slice(0, 50), box: r(li), op: getComputedStyle(li).opacity }));
        let hit = null, onTop = null;
        if (md) {
          const b = md.getBoundingClientRect();
          const el = document.elementFromPoint(b.left + b.width / 2, b.top + b.height / 2);
          onTop = !!el && (el === md || md.contains(el));
          hit = el ? (el.closest('[aria-label="Notifications"] li')?.innerText.replace(/\s+/g, ' ').slice(0, 40) ?? `${el.tagName}.${(el.className?.baseVal ?? el.className ?? '').toString().slice(0, 30)}`) : null;
        }
        const dock = document.querySelector('[data-toast-above]');
        return { md: r(md), onTop, hit, toasts, dockTop: dock ? Math.round(dock.getBoundingClientRect().top) : null, scrollY: Math.round(scrollY) };
      });
      out.samples.push({ t: Date.now() - t0, ...s });
      if (i === 6) await p.screenshot({ path: `${dir}/${tag}-toasts.png`, animations: 'disabled' }).catch(() => {});
      await sleep(100);
    }
  } else {
    // a person's tap on Mark done ~0.6 s after Today appears (as the frozen test does)
    await sleep(600);
    const box = await markDone.boundingBox();
    if (!box) { out.tap = { error: 'no box' }; } else {
      const x = box.x + box.width / 2, y = box.y + box.height / 2;
      const under = await p.evaluate(([x, y]) => { const el = document.elementFromPoint(x, y); return el ? (el.closest('[aria-label="Notifications"] li')?.innerText.replace(/\s+/g, ' ').slice(0, 40) ?? el.tagName + (el.getAttribute('aria-label') ? `[${el.getAttribute('aria-label').slice(0, 30)}]` : '')) : null; }, [x, y]);
      if (mobile) await p.touchscreen.tap(x, y); else await p.mouse.click(x, y);
      const crossed = await p.getByText('Crossed off. Nice work.').waitFor({ state: 'visible', timeout: 4000 }).then(() => true, () => false);
      out.tap = { t: Date.now() - t0, at: [Math.round(x), Math.round(y)], under, crossed };
      await p.screenshot({ path: `${dir}/${tag}-after-tap.png`, animations: 'disabled' }).catch(() => {});
    }
  }
  await ctx.close();
}

try {
  await run('sample');
  await run('tap');
} catch (e) { out.errors.push(e.message.slice(0, 200)); }
finally {
  writeFileSync(`${dir}/${tag}.json`, JSON.stringify(out, null, 1));
  await b.close();
  const covered = out.samples.filter((s) => s.onTop === false);
  const first = covered[0]?.t, last = covered.at(-1)?.t;
  const s0 = out.samples[0] || {};
  console.log(args.label, tag, 'MarkDone', JSON.stringify(s0.md), 'dockTop', s0.dockTop, 'covered', covered.length, '/', out.samples.length, first != null ? `from ${first} to ${last} ms by "${covered[0].hit}"` : '', '| tap:', JSON.stringify(out.tap), '| errors', out.errors.length, JSON.stringify(out.errors).slice(0, 200));
}

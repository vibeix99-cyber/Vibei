// LEAD checker, W2 maker N: same-session captures on one server for one configuration.
// node n-cap.mjs --base http://127.0.0.1:5350 --label trial --cfg 390x844@3:light:100 --out <dir>
// Real clicks for user steps; the debug API only seeds the profile, sets preferences, finish() and navigate() for setup.
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const FIXED = Date.parse('2026-10-11T07:40:00.000Z');
const m = args.cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
const [W, H, DPR, theme, text] = [+m[1], +m[2], +m[3], m[4], +m[5]];
const dir = `${args.out}/${args.label}/${W}x${H}-${theme}-t${text}`;
mkdirSync(dir, { recursive: true });
const mobile = W < 900;
const only = (args.groups || 'off,on,loading,bigday').split(',');
const meta = { base: args.base, label: args.label, cfg: args.cfg, states: {}, errors: [], console: [] };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });

async function context() {
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  await ctx.addInitScript(() => {
    window.__cls = { v: 0, src: [] };
    try {
      new PerformanceObserver((l) => {
        for (const e of l.getEntries()) {
          if (e.hadRecentInput) continue;
          window.__cls.v += e.value;
          window.__cls.src.push({ v: +e.value.toFixed(4), t: Math.round(e.startTime), s: (e.sources || []).map((s) => (s.node && (s.node.className?.baseVal ?? s.node.className ?? s.node.nodeName)) + '').slice(0, 4) });
        }
      }).observe({ type: 'layout-shift', buffered: true });
    } catch {}
  });
  const p = await ctx.newPage();
  await p.clock.install({ time: FIXED });
  await p.clock.resume();
  p.on('pageerror', (e) => meta.errors.push(e.message.slice(0, 200)));
  p.on('console', (msg) => { if (msg.type() === 'error') meta.console.push(msg.text().slice(0, 200)); });
  return { ctx, p };
}
const q = (seed, extra = '') => `${args.base}/?debug&seed=${seed}&theme=${theme}${extra}`;
const ready = (p) => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 }).catch(() => {});
const measure = (p) => p.evaluate(() => {
  const rect = (e) => { if (!e) return null; const r = e.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]; };
  const win = document.querySelector('[data-scene-mode="window"]');
  const svg = win?.querySelector('svg[data-window-items]');
  const layers = svg ? [...svg.querySelectorAll('image[data-item]')].map((i) => ({ id: i.getAttribute('data-item'), box: rect(i), href: (i.href?.baseVal || '').split('/').pop().slice(0, 48) })) : [];
  const still = win ? [...win.querySelectorAll('img')].map((i) => ({ src: (i.currentSrc || i.src).split('/').pop().slice(0, 40), complete: i.complete, box: rect(i) })) : [];
  const canvas = win?.querySelector('canvas');
  const hintEl = document.querySelector('section[aria-label="The room"] p');
  const stage = hintEl?.parentElement;
  const ctrls = stage ? [...stage.querySelectorAll('button')].map((x) => ({ name: x.getAttribute('aria-label')?.slice(0, 40), box: rect(x) })) : [];
  let hintLines = null;
  if (hintEl) { const cs = getComputedStyle(hintEl); const lh = parseFloat(cs.lineHeight) || parseFloat(cs.fontSize) * 1.3; hintLines = Math.round((hintEl.getBoundingClientRect().height - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom)) / lh); }
  const nookHost = document.querySelector('section[aria-label="The room"] [data-scene-mode]');
  return {
    hash: location.hash,
    window: win ? { static: win.getAttribute('data-scene-static'), ready: win.getAttribute('data-scene-ready'), box: rect(win), still, canvas: canvas ? { box: rect(canvas), w: canvas.width, h: canvas.height, opacity: getComputedStyle(canvas.parentElement).opacity } : null, layerIds: svg?.getAttribute('data-window-items') ?? null, layers } : null,
    nook: nookHost ? { static: nookHost.getAttribute('data-scene-static'), ready: nookHost.getAttribute('data-scene-ready'), box: rect(nookHost) } : null,
    hint: hintEl ? { text: hintEl.textContent.trim(), box: rect(hintEl), lines: hintLines, stage: rect(stage), ctrls, static: hintEl.hasAttribute('data-static') } : null,
    ls: { live: localStorage.getItem('kettle:nook-hint-seen'), drawn: localStorage.getItem('kettle:nook-static-hint-seen') },
    cls: window.__cls,
    scroll: { y: Math.round(scrollY), sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth },
  };
});
const shot = async (p, name, desc) => {
  try {
    await p.screenshot({ path: `${dir}/${name}.png`, animations: 'disabled', timeout: 120_000 });
    meta.states[name] = { desc, at: new Date().toISOString(), ...(await measure(p)) };
  } catch (e) { meta.errors.push(`${name}: ${e.message.slice(0, 160)}`); }
};
const click = async (p, name) => { const l = p.getByRole('button', { name }).first(); await l.scrollIntoViewIfNeeded().catch(() => {}); await l.click({ timeout: 30_000 }); };
const settings = (p, s) => p.evaluate((x) => window.__kettle.settings.getState().set(x), s);
const toNook = async (p) => {
  const link = p.getByRole('link', { name: /nook/i }).first();
  if (await link.isVisible().catch(() => false)) { await link.click(); } else { meta.errors.push('nook link not visible; navigate()'); await p.evaluate(() => window.__kettle.navigate('/nook')); }
  await p.waitForFunction(() => location.hash.includes('nook'), null, { timeout: 15_000 }).catch(() => {});
};

async function group(label, fn) {
  if (!only.includes(label)) return;
  const { ctx, p } = await context();
  try { await fn(p); } catch (e) { meta.errors.push(`${label}: ${e.message.slice(0, 200)}`); }
  await ctx.close();
}

try {
  await group('off', async (p) => {
    await p.goto(q('veteran') + '#/'); await ready(p);
    await settings(p, { scene: 'off', muted: true, autoStartBreaks: false, autoStartFocus: false }); await p.reload(); await ready(p); await p.evaluate(() => document.fonts.ready); await sleep(1200);
    await p.evaluate(() => { window.__cls = { v: 0, src: [] }; });
    await click(p, /put the kettle on/i); await sleep(4000);
    await shot(p, '02-focus-3doff', 'Focus, 3D off, 4 s');
    await p.evaluate(() => window.__kettle.finish()); await sleep(2500);
    await click(p, /^skip break$/i).catch((e) => meta.errors.push('skip: ' + e.message.slice(0, 80))); await sleep(1500);
    await toNook(p); await sleep(3000);
    await shot(p, '10-nook-static', 'Nook, 3D off (static room), hint visible');
    // real tap on the drawing (centre-left of the stage, away from the controls) dismisses the hint
    const st = meta.states['10-nook-static']?.hint?.stage;
    if (st) {
      if (mobile) await p.touchscreen.tap(st[0] + st[2] * 0.3, st[1] + st[3] * 0.5); else await p.mouse.click(st[0] + st[2] * 0.3, st[1] + st[3] * 0.5);
      await sleep(900);
      await shot(p, '10-nook-static-tapped', 'Nook static after a real tap on the drawing');
      await p.reload(); await ready(p); await sleep(2500);
      await shot(p, '10-nook-static-reload', 'Nook static after reload (hint stays dismissed)');
      await settings(p, { scene: 'auto' }); await p.reload(); await ready(p); await sleep(5000);
      await shot(p, '10-nook-3d-after-static', 'Nook with 3D switched on after the static hint was dismissed');
    }
  });
  await group('on', async (p) => {
    await p.goto(q('veteran') + '#/'); await ready(p); await p.evaluate(() => document.fonts.ready);
    await settings(p, { muted: true, autoStartBreaks: false, autoStartFocus: false }); await sleep(1500);
    await click(p, /put the kettle on/i);
    await p.waitForFunction(() => document.querySelector('[data-scene-mode="window"]')?.getAttribute('data-scene-ready') === 'true', null, { timeout: 45_000 }).catch(() => meta.errors.push('3d never ready'));
    await sleep(2500);
    await shot(p, '02-focus-3don', 'Focus, 3D on, live (ready + 2.5 s)');
    await p.evaluate(() => window.__kettle.finish()); await sleep(2500);
    await click(p, /^skip break$/i).catch(() => {}); await sleep(1500);
    await toNook(p); await sleep(7000);
    await shot(p, '10-nook-3d', 'Nook, 3D on, 7 s');
  });
  await group('loading', async (p) => {
    // Hold the 3D scene chunk so the backdrop stays in its loading state.
    await p.route(/NookScene[-.]/, async (route) => { await sleep(25_000); await route.continue().catch(() => {}); });
    await p.goto(q('veteran') + '#/'); await ready(p); await p.evaluate(() => document.fonts.ready);
    await settings(p, { muted: true, autoStartBreaks: false }); await sleep(1200);
    await click(p, /put the kettle on/i); await sleep(2500);
    await shot(p, '02-focus-loading-held', 'Focus, 3D chunk held back (loading state), 2.5 s');
  });
  await group('bigday', async (p) => {
    await p.goto(q('celebrate') + '#/'); await ready(p); await p.evaluate(() => document.fonts.ready);
    await settings(p, { muted: true, autoStartBreaks: false, autoStartFocus: false }); await sleep(1200);
    await click(p, /put the kettle on/i); await sleep(2500);
    await p.evaluate(() => window.__kettle.finish());
    await p.waitForFunction(() => location.hash.includes('done'), null, { timeout: 30_000 }).catch(() => {});
    await sleep(1000); await shot(p, '07-bigday-1s', 'Summary, big day, 1 s');
    await sleep(3000); await shot(p, '07-bigday-4s', 'Summary, big day, 4 s');
    await sleep(6000); await shot(p, '07-bigday-10s', 'Summary, big day, 10 s');
  });
} finally {
  writeFileSync(`${dir}/meta.json`, JSON.stringify(meta, null, 1));
  await b.close();
  console.log(args.label, `${W}x${H}-${theme}-t${text}`, 'states', Object.keys(meta.states).length, 'errors', meta.errors.length, JSON.stringify(meta.errors).slice(0, 300));
}

// LEAD checker, W2 maker N: in the first seconds of a brew (cold profile, still not cached), do item layers paint
// before the base window still? Samples the backdrop host every ~120 ms: DOM state + a clipped screenshot.
// node n-float.mjs --base http://127.0.0.1:5350 --label trial --cfg 390x844@3:light:100 --out <dir> [--scene off]
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const m = args.cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
const [W, H, DPR, theme, text] = [+m[1], +m[2], +m[3], m[4], +m[5]];
const mobile = W < 900;
const scene = args.scene || 'auto';
const tag = `${W}x${H}-${theme}-t${text}-${scene}`;
const dir = `${args.out}/${args.label}/${tag}`;
mkdirSync(dir, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
const p = await ctx.newPage();
const out = { base: args.base, label: args.label, cfg: args.cfg, scene, samples: [], errors: [] };
p.on('pageerror', (e) => out.errors.push(e.message.slice(0, 160)));
await p.goto(`${args.base}/?debug&seed=veteran&theme=${theme}#/`);
await p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
await p.evaluate((scene) => window.__kettle.settings.getState().set({ scene, muted: true, autoStartBreaks: false, autoStartFocus: false }), scene);
if (scene === 'off') { await p.reload(); await p.waitForFunction(() => !!window.__kettle?.timerInfo?.()?.leader, null, { timeout: 60_000 }); }
await sleep(1500);
const start = p.getByRole('button', { name: /put the kettle on/i }).first();
const bb = await start.boundingBox();
const t0 = Date.now();
if (mobile) await p.touchscreen.tap(bb.x + bb.width / 2, bb.y + bb.height / 2); else await p.mouse.click(bb.x + bb.width / 2, bb.y + bb.height / 2);
let i = 0;
while (Date.now() - t0 < 6000) {
  const s = await p.evaluate(() => {
    const host = document.querySelector('[data-scene-mode="window"]');
    if (!host) return { host: false };
    const img = host.querySelector('img');
    const layers = [...host.querySelectorAll('svg[data-window-items] image')].map((x) => x.getAttribute('data-item'));
    const res = performance.getEntriesByType('resource').filter((e) => /window-|stills\/items|\/assets\/[a-zA-Z]+-(morning|day|dusk|night)-/.test(e.name)).map((e) => ({ f: e.name.split('/').pop().slice(0, 32), end: Math.round(e.responseEnd) }));
    const r = host.getBoundingClientRect();
    return { host: true, now: Math.round(performance.now()), still: img ? { complete: img.complete, w: img.naturalWidth } : null, layers, res, ready: host.getAttribute('data-scene-ready'), static: host.getAttribute('data-scene-static'), rect: [r.left, r.top, r.width, r.height].map(Math.round) };
  });
  s.t = Date.now() - t0;
  if (s.host && s.rect[2] > 10) {
    const [x, y, w, h] = s.rect;
    const clip = { x: Math.max(0, x), y: Math.max(0, y), width: Math.min(W, x + w) - Math.max(0, x), height: Math.min(H, y + h) - Math.max(0, y) };
    if (clip.width > 4 && clip.height > 4) {
      const name = `f${String(i).padStart(3, '0')}-${s.t}.jpg`;
      await p.screenshot({ path: `${dir}/${name}`, clip, type: 'jpeg', quality: 55, animations: 'disabled', timeout: 10_000 }).catch(() => {});
      s.frame = name;
    }
  }
  out.samples.push(s);
  i++;
}
writeFileSync(`${dir}/log.json`, JSON.stringify(out, null, 1));
await b.close();
const firstLayers = out.samples.find((s) => s.layers?.length);
const firstStill = out.samples.find((s) => s.still?.complete && s.still.w > 0);
const floating = out.samples.filter((s) => s.layers?.length && !(s.still?.complete && s.still.w > 0));
console.log(args.label, tag, 'samples', out.samples.length, 'layers first at', firstLayers?.t, 'still decoded first at', firstStill?.t, 'samples with layers but still not complete:', floating.length, floating.length ? `${floating[0].t}–${floating.at(-1).t} ms` : '', 'errors', out.errors.length);

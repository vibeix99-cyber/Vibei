// LEAD: from an unzipped Playwright trace, print the actions around the tap/click on "Mark done" and the screencast
// frame nearest to (and just after) it.  node trace-click.mjs <dir>
import { readFileSync, readdirSync } from 'node:fs';
const dir = process.argv[2];
const lines = readFileSync(`${dir}/0-trace.trace`, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
const actions = lines.filter((e) => e.type === 'before' || e.type === 'after' || e.type === 'input');
const frames = lines.filter((e) => e.type === 'screencast-frame');
let clickT = null;
for (const e of lines) {
  if (e.type === 'before' && /tap|click/i.test(e.method || '') && e.params && ('x' in e.params)) {
    console.log('ACTION', e.method, JSON.stringify(e.params), 'startTime', e.startTime);
    clickT = e.startTime;
  }
}
if (clickT != null) {
  const near = frames.map((f) => ({ ...f, d: f.timestamp - clickT })).filter((f) => f.d > -1500 && f.d < 1500).sort((a, b) => a.d - b.d);
  for (const f of near) console.log('FRAME', f.sha1, 'dt', Math.round(f.d), f.width, f.height);
}

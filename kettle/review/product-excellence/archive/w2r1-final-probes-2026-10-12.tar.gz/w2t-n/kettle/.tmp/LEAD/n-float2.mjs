// LEAD checker, W2 maker N: load order of the window still vs the item layers at brew start (cold, then a second brew
// in the same session, cached). Records every <img>/<image> load event (capture listener) and a CDP screencast.
// node n-float2.mjs --base http://127.0.0.1:5350 --label trial --cfg 390x844@3:light:100 --out <dir> [--scene off]
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') && a.push([x.slice(2), all[i + 1]]), a), []));
const m = args.cfg.match(/^(\d+)x(\d+)@(\d+):(light|dark):(\d+)$/);
const [W, H, DPR, theme] = [+m[1], +m[2], +m[3], m[4]];
const mobile = W < 900;
const scene = args.scene || 'auto';
const tag = `${W}x${H}-${theme}-${scene}`;
const dir = `${args.out}/${args.label}/${tag}`;
mkdirSync(dir, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: DPR, isMobile: mobile && W < H, hasTouch: mobile, colorScheme: theme, timezoneId: 'UTC', locale: 'en-GB', serviceWorkers: 'block' });
await ctx.addInitScript(() => {
  window.__loads = [];
  document.addEventListener('load', (e) => {
    const t = e.target;
    if (!t || !t.tagName) return;
    const tn = t.tagName.toLowerCase();
    if (tn !== 'img' && tn !== 'image') return;
    if (!t.closest?.('[data-scene-mode="window"]')) return;
    window.__loads.push({ tag: tn, item: t.getAttribute('data-item'), src: (t.currentSrc || t.href?.baseVal || t.src || '').split('/').pop().slice(0, 34), at: Math.round(performance.now()) });
  }, true);
});
const p = await ctx.newPage();
const out = { base: args.base, label: args.label, cfg: args.cfg, scene, brews: [], errors: [] };
p.on('pageerror', (e) => out.errors.push(e.message.slice(0, 160)));
const cdp = await ctx.newCDPSession(p);
let frames = [];
let rec = null;
cdp.on('Page.screencastFrame', async (f) => {
  cdp.send('Page.screencastFrameAck', { sessionId: f.sessionId }).catch(() => {});
  if (!rec) return;
  const name = `${rec}-${String(frames.length).padStart(3, '0')}.jpg`;
  frames.push({ name, ts: f.metadata.timestamp });
  writeFileSync(`${dir}/${name}`, Buffer.from(f.data, 'base64'));
});
const ready = () => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
await p.goto(`${args.base}/?debug&seed=veteran&theme=${theme}#/`);
await ready();
await p.evaluate((scene) => window.__kettle.settings.getState().set({ scene, muted: true, autoStartBreaks: false, autoStartFocus: false }), scene);
if (scene === 'off') { await p.reload(); await ready(); }
await sleep(1500);

async function brew(label) {
  await p.evaluate(() => { window.__loads = []; });
  frames = [];
  rec = label;
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 45, maxWidth: W, maxHeight: H, everyNthFrame: 1 });
  const start = p.getByRole('button', { name: /put the kettle on/i }).first();
  const bb = await start.boundingBox();
  const tapAt = await p.evaluate(() => Math.round(performance.now()));
  const wall = Date.now() / 1000;
  if (mobile) await p.touchscreen.tap(bb.x + bb.width / 2, bb.y + bb.height / 2); else await p.mouse.click(bb.x + bb.width / 2, bb.y + bb.height / 2);
  await sleep(6000);
  await cdp.send('Page.stopScreencast').catch(() => {});
  rec = null;
  const loads = await p.evaluate(() => window.__loads);
  const still = loads.find((l) => l.tag === 'img');
  const layerLoads = loads.filter((l) => l.tag === 'image');
  const r = { label, tapAt, loads: loads.map((l) => ({ ...l, dt: l.at - tapAt })), stillDt: still ? still.at - tapAt : null, firstLayerDt: layerLoads.length ? Math.min(...layerLoads.map((l) => l.at)) - tapAt : null, frames: frames.map((f) => ({ name: f.name, dt: Math.round((f.ts - wall) * 1000) })) };
  out.brews.push(r);
  return r;
}

try {
  const r1 = await brew('cold');
  // second brew in the same session: end it, back to Today, brew again (files now cached)
  await p.evaluate(() => window.__kettle.finish());
  await sleep(2500);
  await p.getByRole('button', { name: /^skip break$/i }).first().click({ timeout: 20_000 }).catch((e) => out.errors.push('skip: ' + e.message.slice(0, 80)));
  await sleep(2500);
  const r2 = await brew('cached');
  for (const r of [r1, r2]) console.log(args.label, tag, r.label, 'still load at', r.stillDt, 'ms; first layer load at', r.firstLayerDt, 'ms; layers', r.loads.filter((l) => l.tag === 'image').map((l) => `${l.item}@${l.dt}`).join(' '), '| frames', r.frames.length);
} catch (e) { out.errors.push(e.message.slice(0, 200)); console.log('error', e.message.slice(0, 200)); }
writeFileSync(`${dir}/log.json`, JSON.stringify(out, null, 1));
await b.close();

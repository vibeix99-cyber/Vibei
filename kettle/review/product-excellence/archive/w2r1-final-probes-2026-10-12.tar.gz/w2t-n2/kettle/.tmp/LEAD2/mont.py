import sys; sys.path.insert(0,'/tmp/claude-0/lr-pylib')
from PIL import Image, ImageDraw
# usage: mont.py out.png scale label1=img1 label2=img2 ...
out=sys.argv[1]; sc=float(sys.argv[2]); ims=[]
for a in sys.argv[3:]:
    l,p=a.split('=',1); im=Image.open(p).convert('RGB')
    if sc!=1: im=im.resize((int(im.width*sc),int(im.height*sc)))
    ims.append((l,im))
W=sum(i.width for _,i in ims)+10*(len(ims)-1); H=max(i.height for _,i in ims)+20
c=Image.new('RGB',(W,H),(128,128,128)); d=ImageDraw.Draw(c); x=0
for l,i in ims: c.paste(i,(x,20)); d.text((x+4,4),l,fill=(255,255,0)); x+=i.width+10
c.save(out)

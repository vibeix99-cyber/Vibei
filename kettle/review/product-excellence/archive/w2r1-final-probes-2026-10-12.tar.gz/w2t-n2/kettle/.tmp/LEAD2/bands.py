import sys; sys.path.insert(0,'/tmp/claude-0/lr-pylib')
from PIL import Image; import numpy as np
a=np.asarray(Image.open(sys.argv[1]).convert('RGB')).astype(int); b=np.asarray(Image.open(sys.argv[2]).convert('RGB')).astype(int)
h=min(a.shape[0],b.shape[0]); w=min(a.shape[1],b.shape[1]); print('sizes',a.shape,b.shape)
d=(np.abs(a[:h,:w]-b[:h,:w]).max(2)>16); rows=np.where(d.any(1))[0]
if not len(rows): print('none'); sys.exit()
bands=[]; s=rows[0]; p=rows[0]
for r in rows[1:]:
    if r>p+8: bands.append((s,p)); s=r
    p=r
bands.append((s,p))
for s,e in bands:
    cols=np.where(d[s:e+1].any(0))[0]; print(f'y {s}-{e} x {cols.min()}-{cols.max()} px {d[s:e+1].sum()}')

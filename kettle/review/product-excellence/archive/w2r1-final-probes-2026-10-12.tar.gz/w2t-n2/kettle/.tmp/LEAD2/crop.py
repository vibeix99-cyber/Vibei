import sys; sys.path.insert(0,'/tmp/claude-0/lr-pylib')
from PIL import Image, ImageDraw
# usage: crop.py out.png x0,y0,x1,y1 label=img ...
out=sys.argv[1]; box=tuple(int(v) for v in sys.argv[2].split(',')); ims=[]
for a in sys.argv[3:]:
    l,p=a.split('=',1); ims.append((l,Image.open(p).convert('RGB').crop(box)))
W=sum(i.width for _,i in ims)+10*(len(ims)-1); H=max(i.height for _,i in ims)+20
c=Image.new('RGB',(W,H),(128,128,128)); d=ImageDraw.Draw(c); x=0
for l,i in ims: c.paste(i,(x,20)); d.text((x+4,4),l,fill=(255,255,0)); x+=i.width+10
c.save(out)

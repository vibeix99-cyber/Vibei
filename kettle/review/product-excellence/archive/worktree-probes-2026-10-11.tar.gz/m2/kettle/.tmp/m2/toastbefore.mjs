import { chromium } from 'playwright';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h] of [[390,844],[375,667]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:5222/?debug&seed=veteran&theme=light&nooktime=day#/`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready);
  await p.evaluate(()=>window.__kettle.settings.getState().set({muted:true,autoStartBreaks:false}));
  await p.evaluate(()=>window.__kettle.timer.getState().startFocus({intention:'Chapter 3 notes',tag:'work'}));
  await p.waitForTimeout(3000);
  // Emulate the BEFORE revision: no marks, no measured offset (the stylesheet's tab-bar position only).
  const strip = () => p.addStyleTag({content:'[aria-label="Notifications"]{}'}).then(()=>p.evaluate(()=>{ document.querySelectorAll('[data-toast-above]').forEach(e=>{e.dataset.m='1'; e.removeAttribute('data-toast-above');}); const r=document.querySelector('[aria-label="Notifications"]')?.parentElement; if(r) r.style.bottom=''; }));
  const say = (m)=>p.evaluate(async (m)=> (await import('/src/ui/Toast.tsx')).toast(m,{tone:'warning',duration:30000}), m);
  await strip();
  await say('Couldn’t save just now. Your brew is still running.'); await p.waitForTimeout(400); await strip(); await p.waitForTimeout(600);
  const m = await p.evaluate(()=>{ const t=document.querySelector('[aria-label="Notifications"] li').getBoundingClientRect(); const c=document.querySelector('[data-m]').getBoundingClientRect(); return `toast ${Math.round(t.top)}–${Math.round(t.bottom)} controls ${Math.round(c.top)}–${Math.round(c.bottom)} overlap ${Math.max(0,Math.round(Math.min(t.bottom,c.bottom)-Math.max(t.top,c.top)))}px`; });
  console.log(w,h,'BEFORE-emulated focus:',m);
  await p.screenshot({path:`.tmp/m2/shots/toast-before-focus-${w}-light.png`});
  await ctx.close();
}
await b.close();

import { chromium } from 'playwright';
const [,, port, W] = process.argv;
const b = await chromium.launch();
const ctx = await b.newContext({ viewport:{width:+W,height:700}, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`http://127.0.0.1:${port}/?debug&seed=veteran&theme=light#/`, {waitUntil:'networkidle'}); await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(1500);
console.log(port, W, JSON.stringify(await p.evaluate(()=>{ const vw=innerWidth; const out=[]; for (const el of document.querySelectorAll('body *')) { const r=el.getBoundingClientRect(); if (r.right>+document.documentElement.clientWidth-0 && r.width>0 && r.right> 360.5) out.push(el.tagName+'.'+String(el.className).slice(0,30)+' '+Math.round(r.right)); } return {vw, out: out.slice(0,8)}; })));
await b.close();

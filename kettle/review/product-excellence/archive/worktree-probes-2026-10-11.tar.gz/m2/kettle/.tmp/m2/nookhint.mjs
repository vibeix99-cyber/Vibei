import { chromium } from 'playwright';
const out = '/tmp/claude-0/-home-user-Vibei/af90140e-0279-5682-99d5-a47623d3eed0/scratchpad/p';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light','dark']) {
  const ctx = await b.newContext({ viewport:{width:1440,height:900}, colorScheme: theme });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=${theme}#/nook`, {waitUntil:'networkidle'});
  await p.waitForTimeout(6000);
  for (let i=0;i<3;i++){
    const info = await p.evaluate(()=>{const el0=[...document.querySelectorAll('p')].find(e=>/Drag to look/.test(e.textContent)); el0&&el0.scrollIntoView({block:'center'}); const el=[...document.querySelectorAll('p')].find(e=>/Drag to look/.test(e.textContent)); if(!el) return null; const r=el.getBoundingClientRect(); let op=1; for(let n=el;n;n=n.parentElement) op*=+getComputedStyle(n).opacity; const tops=document.elementsFromPoint(r.left+r.width/2,r.top+r.height/2).slice(0,4).map(e=>e.tagName+'.'+(e.className.baseVal??e.className)).join(' > '); const top=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2); return {r:[r.x,r.y,r.width,r.height],op,bg:getComputedStyle(el).backgroundColor,color:getComputedStyle(el).color,top:top&&(top.className+'|'+top.tagName), inside: el.contains(top), tops};});
    console.log(theme, JSON.stringify(info));
    if (info) await p.screenshot({path:`${out}/nookhint-${theme}-${i}.png`, clip:{x:info.r[0]-40,y:info.r[1]-40,width:info.r[2]+80,height:info.r[3]+80}});
    await p.waitForTimeout(1500);
  }
  await ctx.close();
}
await b.close();

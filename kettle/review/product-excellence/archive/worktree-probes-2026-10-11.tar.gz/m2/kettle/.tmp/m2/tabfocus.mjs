import { chromium } from 'playwright';
import { probeFocus } from '../../tests/a11y-probes.mjs';
const [,, base='http://127.0.0.1:5202'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:390,height:844}, deviceScaleFactor:1, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light#/`, {waitUntil:'networkidle'});
await p.evaluate(()=>window.__kettle.settings.getState().set({muted:true}));
await p.waitForTimeout(2000);
await p.getByRole('button',{name:/Put the kettle on/}).focus(); await p.keyboard.press('Enter');
await p.waitForFunction(()=>location.hash==='#/focus'); 
for (const wait of [100, 2500]) {
  await p.waitForTimeout(wait);
  const f = await p.evaluate(probeFocus);
  console.log('after',wait,'active:',f.name,f.tag,'obscured',f.obscured, 'homeMounted', await p.evaluate(()=>!!document.querySelector('[data-toast-above]')));
}
for (let i=0;i<10;i++){ await p.keyboard.press('Tab'); await p.waitForTimeout(150); const f=await p.evaluate(probeFocus); console.log(i,f.route,f.name,f.obscured?'OBSCURED':''); }
await b.close();

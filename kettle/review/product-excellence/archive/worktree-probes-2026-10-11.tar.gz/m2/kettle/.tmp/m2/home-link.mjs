import { chromium } from 'playwright';
const [,, base='http://127.0.0.1:5202'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h] of [[390,844],[375,667],[320,568]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:1, isMobile:true, hasTouch:true });
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(1500);
  await p.screenshot({path:`.tmp/m2/shots/link-${w}-0.png`});
  await p.getByRole('button',{name:'Change brew length'}).tap();
  await p.waitForTimeout(1200);
  const r = await p.evaluate(()=>{ const a=document.activeElement; const r=a.getBoundingClientRect(); const d=document.querySelector('[data-toast-above]').getBoundingClientRect(); return {focus:a.textContent, top:Math.round(r.top), bottom:Math.round(r.bottom), dockTop:Math.round(d.top)}; });
  console.log(w,h,JSON.stringify(r));
  await p.screenshot({path:`.tmp/m2/shots/link-${w}-1.png`});
  await ctx.close();
}
await b.close();

import { chromium } from 'playwright';
const [,, base='http://127.0.0.1:5202', tag='x'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h,kb] of [[390,844,336],[375,667,291]]) for (const [id,seed,route] of [['home','veteran','/'],['welcome','fresh','/welcome']]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=${seed}&theme=light&nooktime=day#${route}`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(1500);
  await p.locator('input').first().focus();
  await p.setViewportSize({width:w,height:h-kb}); await p.waitForTimeout(500);
  await p.evaluate(()=>document.activeElement.scrollIntoView({block:'nearest'})); await p.waitForTimeout(500);
  const r = await p.evaluate(()=>{const el=document.activeElement; const r=el.getBoundingClientRect(); const hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2); return {top:Math.round(r.top),bottom:Math.round(r.bottom),ih:innerHeight, hit: hit?.className||hit?.tagName, ok: !!hit&&(hit===el||el.contains(hit)||hit.contains(el))};});
  console.log(w,h-kb,id,JSON.stringify(r));
  await p.screenshot({path:`review/product-excellence/contracts/I04/fixes/keyboard-open-${id}-${w}x${h-kb}-light-${tag}.png`});
  await ctx.close();
}
await b.close();

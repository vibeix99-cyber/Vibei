#!/bin/sh
for pid in $(ps -eo pid,args | grep "[n]ode .*vite --config .tmp/m2/vite.m2.config.ts --port 5202" | awk '{print $1}'); do kill $pid; done
sleep 1
cd /home/user/wt/m2/kettle && setsid nohup npx vite --config .tmp/m2/vite.m2.config.ts --port 5202 --strictPort --host 127.0.0.1 > /tmp/claude-0/-home-user-Vibei/af90140e-0279-5682-99d5-a47623d3eed0/scratchpad/dev5202.log 2>&1 < /dev/null &
sleep 4

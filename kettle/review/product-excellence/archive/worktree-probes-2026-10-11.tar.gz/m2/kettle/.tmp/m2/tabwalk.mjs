import { chromium } from 'playwright';
import { probeFocus } from '../../tests/a11y-probes.mjs';
const [,, base='http://127.0.0.1:5202', route='/stats', n='80', W='390', H='844'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:+W,height:+H}, deviceScaleFactor:1, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light#${route}`, {waitUntil:'networkidle'});
await p.evaluate(()=>window.__kettle.settings.getState().set({muted:true}));
await p.waitForTimeout(2500);
for (let i=0;i<+n;i++){ await p.keyboard.press('Tab'); await p.waitForTimeout(120); const f = await p.evaluate(probeFocus);
  if (f.obscured) { const cover = await p.evaluate(()=>{ const el=document.activeElement; const r=el.getBoundingClientRect(); const e=document.elementFromPoint(r.left+r.width/2, Math.min(innerHeight-1,Math.max(0,r.top+r.height/2))); return `rect ${Math.round(r.top)}-${Math.round(r.bottom)} under ${e?.tagName}.${e?.className} vis=${getComputedStyle(el).visibility} inert=${!!el.closest('[inert]')} ariaHidden=${!!el.closest('[aria-hidden=true]')}`; }); console.log(i, f.route, JSON.stringify(f.name), cover); } }
await b.close();

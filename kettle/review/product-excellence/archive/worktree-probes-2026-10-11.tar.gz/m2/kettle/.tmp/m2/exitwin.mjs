import { chromium } from 'playwright';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const rm of [false,true]) {
const ctx = await b.newContext({ viewport:{width:390,height:844}, deviceScaleFactor:1, isMobile:true, hasTouch:true, reducedMotion: rm?'reduce':'no-preference' });
const p = await ctx.newPage();
await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=light#/stats`, {waitUntil:'networkidle'});
await p.waitForTimeout(2000);
const t = await p.evaluate(async()=>{ const t0=performance.now(); document.querySelector('a[href="#/nook"]').click(); let last=0; while(performance.now()-t0<4000){ if(document.querySelector('[aria-label="Earlier 7 days"]')) last=performance.now()-t0; await new Promise(r=>setTimeout(r,25)); } return Math.round(last); });
console.log('reduced',rm,'old Stats controls still in page for', t, 'ms after navigation');
await ctx.close(); }
await b.close();

import { chromium } from 'playwright';
import { walkJourney } from '../../tests/a11y-probes.mjs';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:390,height:844}, deviceScaleFactor:2, isMobile:true, hasTouch:true, colorScheme:'light' });
const page = await ctx.newPage();
await walkJourney(page, 'http://127.0.0.1:5242', async (id, p) => {
  const t0 = Date.now(); const out = [];
  for (let i = 0; i < 20; i++) {
    out.push(await p.evaluate(() => { const sub=[...document.querySelectorAll('header span')].find(e=>e.textContent.trim()==='· Work'); let op=1; for (let n=sub; n; n=n.parentElement) op*=+getComputedStyle(n).opacity; return `${!!document.querySelector('[data-zen]')?'zen':'awake'} chipOpacity=${op.toFixed(2)}`; }));
    out[out.length-1] = `${((Date.now()-t0)/1000).toFixed(1)}s ${out[out.length-1]}`;
    await p.waitForTimeout(500);
  }
  console.log(id, out.join(' | '));
}, { theme: 'light', only: ['added'] });
await b.close();

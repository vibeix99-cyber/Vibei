import { chromium } from 'playwright';
const b = await chromium.launch();
const ctx = await b.newContext({ viewport:{width:360,height:700}, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=light#/`, {waitUntil:'networkidle'}); await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(1500);
console.log(JSON.stringify(await p.evaluate(()=>{ const el=document.querySelector('nav[aria-label="Your progress"]'); return {sw:screen.width, iw:innerWidth, dsw:document.documentElement.scrollWidth, dcw: document.documentElement.clientWidth, spill: el.scrollWidth-el.clientWidth, elsw: el.scrollWidth, elcw: el.clientWidth, wrap: el.dataset.wrap}; })));
await b.close();

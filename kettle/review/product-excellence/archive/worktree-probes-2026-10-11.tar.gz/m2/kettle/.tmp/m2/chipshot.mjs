import { chromium } from 'playwright';
const [,, port, tag] = process.argv;
const out = 'review/product-excellence/contracts/I04/fixes';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h,big,theme] of [[375,667,false,'light'],[375,667,false,'dark'],[320,568,false,'light'],[390,844,true,'light']]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true, colorScheme: theme });
  if (big) await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:${port}/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready);
  await p.evaluate(()=>window.__kettle.settings.getState().set({muted:true}));
  await p.evaluate(()=>window.__kettle.timer.getState().startFocus({intention:'Chapter 3 notes',tag:'work'}));
  await p.waitForTimeout(3500);
  const r = await p.evaluate(()=>{const el=[...document.querySelectorAll('header span')].find(e=>/^Chapter 3 notes/.test(e.textContent)&&e.children.length>=1&&!e.querySelector('svg')); return el?{sw:el.scrollWidth,cw:el.clientWidth,sh:el.scrollHeight,ch:el.clientHeight}:null;});
  console.log(tag, w,h,big?'200%':'', theme, JSON.stringify(r));
  await p.screenshot({path:`${out}/focus-task-chip-${w}x${h}${big?'-text200':''}-${theme}-${tag}.png`, clip:{x:0,y:0,width:w,height:Math.min(h, 260)}});
  await ctx.close();
}
await b.close();

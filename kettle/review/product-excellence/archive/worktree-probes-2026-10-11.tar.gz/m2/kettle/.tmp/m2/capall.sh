#!/bin/sh
cd /home/user/wt/m2/kettle
O=review/product-excellence/contracts/I04/after
for c in "390 844 2 light phone-390x844-light" "390 844 2 dark phone-390x844-dark" "375 667 2 light phone-375x667-light" "375 667 2 dark phone-375x667-dark" "1440 900 1 light desktop-1440x900-light" "1440 900 1 dark desktop-1440x900-dark"; do
  set -- $c
  node review/product-excellence/tools/capture.mjs --base http://127.0.0.1:5202 --out $O/$5 --w $1 --h $2 --dpr $3 --theme $4 || echo "FAIL $5"
  echo "done $5"
done
node review/product-excellence/tools/capture.mjs --base http://127.0.0.1:5202 --out $O/phone-390x844-dark-reduced-motion --w 390 --h 844 --dpr 2 --theme dark --rm --only 01,02,04,06,07,08,09,10,11,11b || echo "FAIL rm"
echo "done rm"

import { chromium } from 'playwright';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h] of [[390,844],[375,667]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=light&nooktime=day#/`, {waitUntil:'networkidle'});
  await p.waitForFunction(()=>!!window.__kettle); await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(2500);
  const r = await p.evaluate(()=>{
    const out=[];
    for (const el of document.querySelectorAll('[role=radio], button')) {
      const b=el.getBoundingClientRect(); if(b.bottom<0||b.top>innerHeight||b.width===0) continue;
      let hit=0; for(let y=Math.max(0,Math.ceil(b.top));y<Math.min(innerHeight,b.bottom);y++){ const e=document.elementFromPoint(b.left+b.width/2,y); if(e&&el.contains(e)) hit++; }
      out.push(`${(el.getAttribute('aria-label')||el.textContent).trim().slice(0,30)} top=${b.top.toFixed(0)} h=${b.height.toFixed(0)} hitRows=${hit}`);
    }
    const d=document.querySelector('[data-toast-above]').getBoundingClientRect();
    out.push('dock top='+d.top.toFixed(0)+' bottom='+d.bottom.toFixed(0));
    return out;
  });
  console.log(w,h,'\n'+r.join('\n'));
  await ctx.close();
}
await b.close();

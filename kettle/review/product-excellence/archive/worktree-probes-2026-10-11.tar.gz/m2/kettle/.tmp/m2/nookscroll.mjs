// Nook at 1440×900: scroll the room's hint into view (as a reader would) and capture the viewport.
import { chromium } from 'playwright';
const [,, port, tag] = process.argv;
const out = 'review/product-excellence/contracts/I04/fixes';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light','dark']) {
  const ctx = await b.newContext({ viewport:{width:1440,height:900}, colorScheme: theme });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:${port}/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/nook`, {waitUntil:'networkidle'});
  await p.waitForTimeout(7000);
  const r = await p.evaluate(()=>{const el=[...document.querySelectorAll('p')].find(e=>/Drag to look/.test(e.textContent)); el.scrollIntoView({block:'center'}); const b=el.getBoundingClientRect(); const hit=document.elementFromPoint(b.left+b.width/2, Math.min(b.top+b.height/2, innerHeight-1)); return {top:Math.round(b.top), bottom:Math.round(b.bottom), innerHeight, hintOnTop: el.contains(hit)};});
  await p.waitForTimeout(1500);
  await p.screenshot({path:`${out}/nook-hint-1440x900-${theme}-${tag}.png`});
  console.log(tag, theme, JSON.stringify(r));
  await ctx.close();
}
await b.close();

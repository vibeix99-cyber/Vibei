import { chromium } from 'playwright';
const b = await chromium.launch();
for (const [w, big] of [[375,false],[390,false],[360,false],[320,false],[390,true],[375,true],[320,true]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:700}, isMobile:true, hasTouch:true });
  if (big) await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=light#/`, {waitUntil:'networkidle'}); await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(1500);
  console.log(w, big?'200%':'100%', JSON.stringify(await p.evaluate(()=>{ const bar=document.querySelector('nav[aria-label="Your progress"]'); return {wrap: bar.dataset.wrap!==undefined, rows: new Set([...bar.children].map(k=>Math.round(k.getBoundingClientRect().top))).size, pageScrollW: document.documentElement.scrollWidth, vw: innerWidth}; })));
  await ctx.close();
}
await b.close();

import { chromium } from 'playwright';
const [,, port='5222', tag='after'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light','dark']) for (const [w,h] of [[390,844],[375,667]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true, colorScheme: theme });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:${port}/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready);
  await p.evaluate(()=>window.__kettle.settings.getState().set({muted:true,autoStartBreaks:false}));
  await p.evaluate(()=>window.__kettle.timer.getState().startFocus({intention:'Chapter 3 notes',tag:'work'}));
  await p.waitForTimeout(3000);
  const say = (m)=>p.evaluate(async (m)=> (await import('/src/ui/Toast.tsx')).toast(m,{tone:'warning',duration:30000}), m);
  await say('Couldn’t save just now. Your brew is still running.'); await p.waitForTimeout(1500);
  await p.screenshot({path:`review/product-excellence/contracts/I04/fixes/toast-focus-${w}x${h}-${theme}-${tag}.png`});
  await p.evaluate(()=>window.__kettle.finish());
  await p.getByRole('button',{name:/Tea time|Long tea break/}).waitFor({timeout:60000}); await p.waitForTimeout(2500);
  await say('Couldn’t save just now. Your summary is still here.'); await p.waitForTimeout(1500);
  await p.screenshot({path:`review/product-excellence/contracts/I04/fixes/toast-summary-${w}x${h}-${theme}-${tag}.png`});
  await ctx.close();
}
await b.close();

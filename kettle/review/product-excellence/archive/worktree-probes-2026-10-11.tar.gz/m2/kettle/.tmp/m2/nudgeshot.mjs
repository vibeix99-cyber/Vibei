import { chromium } from 'playwright';
const [,, port, tag] = process.argv;
const out = 'review/product-excellence/contracts/I05/captures';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light','dark']) {
  const ctx = await b.newContext({ viewport:{width:390,height:844}, deviceScaleFactor:2, isMobile:true, hasTouch:true, colorScheme: theme });
  await ctx.addInitScript(() => { delete window.Notification; });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:${port}/?debug&seed=veteran&theme=${theme}#/settings`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(2000);
  const row = p.getByRole('switch', { name: 'Nudges' });
  await row.evaluate((el) => el.scrollIntoView({ block: 'center' })); await p.waitForTimeout(600);
  const text = await p.evaluate(() => [...document.querySelectorAll('p, span, div')].map(e=>e.textContent).find(t=>/can’t show notifications/.test(t) && t.length < 120));
  console.log(tag, theme, JSON.stringify(text));
  await p.screenshot({ path: `${out}/settings-nudges-unsupported-390x844-${theme}-${tag}.png`, clip: { x: 0, y: 222, width: 390, height: 400 } });
  await ctx.close();
}
await b.close();

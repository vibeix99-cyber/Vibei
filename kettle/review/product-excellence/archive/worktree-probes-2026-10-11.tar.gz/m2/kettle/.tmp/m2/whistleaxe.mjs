import { chromium } from 'playwright';
import { AxeBuilder } from '@axe-core/playwright';
import { walkJourney } from '../../tests/a11y-probes.mjs';
const [,, port='5242', theme='light', W='1440', H='900'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (let i=0;i<2;i++){
const ctx = await b.newContext({ viewport:{width:+W,height:+H}, colorScheme: theme });
const page = await ctx.newPage();
await walkJourney(page, `http://127.0.0.1:${port}`, async (id, p) => {
  const r = await new AxeBuilder({ page: p }).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']).analyze();
  for (const v of r.violations) console.log(i, id, v.id, v.impact, v.nodes.map(n=>n.target.join(' ')+' :: '+(n.failureSummary||'').split('\n').slice(1,2).join('')).join(' | '));
  console.log(i, id, 'violations', r.violations.length);
}, { theme, only: ['whistle'] });
await ctx.close();
}
await b.close();

import { chromium } from 'playwright';
const out = 'review/product-excellence/contracts/I04/fixes';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h,theme,rm] of [[390,844,'light',false],[375,667,'dark',false],[375,667,'light',true],[320,568,'light',false]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true, colorScheme: theme, reducedMotion: rm?'reduce':'no-preference' });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/`, {waitUntil:'networkidle'});
  await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(2000);
  const t0 = Date.now();
  await p.getByRole('button',{name:'Change brew length'}).tap();
  await p.waitForTimeout(1400);
  const r = await p.evaluate(()=>{ const a=document.activeElement; const r=a.getBoundingClientRect(); const d=document.querySelector('[class*=ctaDock]').getBoundingClientRect(); const box=document.getElementById('home-brew-length').getBoundingClientRect(); return {focus:a.getAttribute('aria-label')||a.textContent, role:a.getAttribute('role'), lengthBox:[Math.round(box.top),Math.round(box.bottom)], dockTop:Math.round(d.top), clear: box.bottom<=d.top}; });
  console.log(w,h,theme,rm?'reduced':'',JSON.stringify(r));
  await p.screenshot({path:`${out}/change-brew-length-tapped-${w}x${h}-${theme}${rm?'-reduced-motion':''}-after.png`});
  await ctx.close();
}
await b.close();

// BEFORE/AFTER evidence for I04 fixes that the standard capture set does not show.
// node .tmp/m2/fixshots.mjs <port> <before|after>
import { chromium } from 'playwright';
const [, , port, tag] = process.argv;
const out = 'review/product-excellence/contracts/I04/fixes';
const base = `http://127.0.0.1:${port}`;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const phone = (w, h, theme, extra = {}) => b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme, ...extra });
const go = async (p, theme, route, seed = 'veteran') => {
  await p.goto(`${base}/?debug&seed=${seed}&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#${route}`, { waitUntil: 'networkidle' });
  await p.evaluate(() => document.fonts.ready);
  await p.waitForTimeout(2500);
};

if (!process.env.SKIP1) {
// 1. 200 % text on Today, 390×844: sideways scroll
for (const theme of ['light']) {
  const ctx = await phone(390, 844, theme);
  await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
  const p = await ctx.newPage();
  await go(p, theme, '/');
  const m = await p.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth }));
  await p.evaluate(() => scrollTo(10000, 0));
  await p.waitForTimeout(300);
  await p.screenshot({ path: `${out}/text200-home-390x844-${theme}-${tag}.png` });
  console.log(tag, 'text200 home', JSON.stringify(m));
  await ctx.close();
}

}
// 2. Settings → Sound while muted (volume sliders off): label/value contrast
for (const theme of ['light', 'dark']) {
  const ctx = await phone(390, 844, theme);
  const p = await ctx.newPage();
  await go(p, theme, '/settings');
  await p.evaluate(() => window.__kettle.settings.getState().set({ muted: true }));
  await p.waitForTimeout(800);
  const g = p.getByText('Master volume').first();
  await g.scrollIntoViewIfNeeded();
  await p.waitForTimeout(500);
  await g.evaluate((el) => el.scrollIntoView({ block: 'center' }));
  await p.waitForTimeout(500);
  const box = { x: 0, y: 222, width: 390, height: 400 };
  await p.screenshot({ path: `${out}/settings-muted-volumes-390x844-${theme}-${tag}.png`, clip: box });
  await ctx.close();
}

// 3. Summary: "How your leaves added up" focused from the keyboard
for (const theme of ['light', 'dark']) {
  const ctx = await phone(390, 844, theme);
  const p = await ctx.newPage();
  await go(p, theme, '/');
  await p.evaluate(() => window.__kettle.settings.getState().set({ muted: true, autoStartBreaks: false }));
  await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'work' }));
  await p.waitForTimeout(2500);
  await p.evaluate(() => window.__kettle.finish());
  await p.getByRole('button', { name: /Tea time|Long tea break/ }).waitFor({ timeout: 60000 });
  await p.waitForTimeout(3000);
  const t = p.getByRole('button', { name: /How your leaves added up/ });
  await t.focus();
  await p.keyboard.press('Shift+Tab');
  await p.keyboard.press('Tab'); // keyboard modality → :focus-visible
  await p.waitForTimeout(600);
  const r = await t.boundingBox();
  await p.screenshot({ path: `${out}/summary-details-focus-390x844-${theme}-${tag}.png`, clip: { x: 0, y: Math.max(0, r.y - 60), width: 390, height: Math.min(r.height + 120, 844 - Math.max(0, r.y - 60)) } });
  const ring = await t.evaluate((el) => getComputedStyle(el).boxShadow);
  console.log(tag, theme, 'details toggle focus box-shadow:', ring);
  await ctx.close();
}
await b.close();

import { chromium } from 'playwright';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
const B='/home/user/Vibei/kettle/review/product-excellence/baseline', A='review/product-excellence/contracts/I04/after';
const b = await chromium.launch(); const p = await b.newPage();
for (const cfg of readdirSync(A)) {
  const rows=[];
  for (const f of readdirSync(`${A}/${cfg}`).filter(x=>x.endsWith('.png')).sort()) {
    if (!existsSync(`${B}/${cfg}/${f}`)) { rows.push(`${f.slice(0,3)}:n/a`); continue; }
    const r = await p.evaluate(async ([x,y]) => {
      const load = async (s) => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,'+s)).blob()); const c=new OffscreenCanvas(bm.width,bm.height); const g=c.getContext('2d'); g.drawImage(bm,0,0); return {w:bm.width,h:bm.height,d:g.getImageData(0,0,bm.width,bm.height).data}; };
      const a=await load(x), c=await load(y);
      if (a.w!==c.w||a.h!==c.h) return `size ${a.w}x${a.h}→${c.w}x${c.h}`;
      let n=0; for (let i=0;i<a.d.length;i+=4){ if (Math.abs(a.d[i]-c.d[i])+Math.abs(a.d[i+1]-c.d[i+1])+Math.abs(a.d[i+2]-c.d[i+2])>48) n++; }
      return (100*n/(a.w*a.h)).toFixed(2)+'%';
    }, [readFileSync(`${B}/${cfg}/${f}`).toString('base64'), readFileSync(`${A}/${cfg}/${f}`).toString('base64')]);
    rows.push(`${f.replace('.png','')}:${r}`);
  }
  console.log(cfg+'\n  '+rows.join('  '));
}
await b.close();

import { chromium } from 'playwright';
import { AxeBuilder } from '@axe-core/playwright';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light','dark']) {
  const ctx = await b.newContext({ viewport:{width:1440,height:900}, colorScheme:theme });
  const p = await ctx.newPage();
  await p.goto(`http://127.0.0.1:5202/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/`, {waitUntil:'networkidle'});
  await p.evaluate(()=>window.__kettle.settings.getState().set({muted:true,autoStartBreaks:false}));
  await p.evaluate(()=>window.__kettle.timer.getState().startFocus({intention:'Chapter 3 notes',tag:'work'}));
  await p.waitForTimeout(3500);
  await p.evaluate(()=>window.__kettle.timer.getState().pause());
  for (const wait of [300, 3000]) {
    await p.waitForTimeout(wait);
    const r = await new AxeBuilder({ page: p }).withRules(['color-contrast']).analyze();
    const op = await p.evaluate(()=>{ const f=[...document.querySelectorAll('[data-tone=paused]')][0]; return f? getComputedStyle(f.parentElement).opacity : 'none'; });
    console.log(theme, 'after', wait, 'ms: violations', r.violations.map(v=>v.nodes.map(n=>n.failureSummary.split('\n')[1]).join(';')).join('|') || 'none', 'flag wrapper opacity', op);
  }
  await ctx.close();
}
await b.close();

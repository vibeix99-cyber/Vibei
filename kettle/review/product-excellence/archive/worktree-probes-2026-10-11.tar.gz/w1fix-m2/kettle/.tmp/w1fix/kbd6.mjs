// r6 packet item (d): does Tab reach "Save backup" in the storage-full warning on Today at 375×667, 100 % and 200 %?
//   node .tmp/w1fix/kbd6.mjs <base> <tag> <outDir> [pcts=100,200] [themes=light,dark] [gapMs=500] [maxTabs=80] [key=Tab|Shift+Tab]
// Setup: storage really full; a brew started and ended within its first minute → Today with "Kettle's off" and the
// warning. Then real key presses only (`page.keyboard.press('Tab')`, one every gapMs) from the top of the document. Every
// Tab is logged (the focused element, whether it is inside a `data-toast-above` group, the warning present / its box,
// the toast region's bottom, the docked start's top, the page's scroll), and every warning removal / re-add is timed.
// When "Save backup" has focus: `:focus-visible`, its outline, a screenshot, and Enter (does the backup download?).
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, tag, out, pctArg = '100,200', themeArg = 'light,dark', gapArg = '500', maxArg = '80', KEY = 'Tab'] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const WARN = 'toast-kettle:save-failed';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
for (const pct of pctArg.split(',').map(Number)) for (const theme of themeArg.split(',')) {
  const label = `${tag} 375x667@${pct} ${theme} ${KEY}`;
  const ctx = await b.newContext({ viewport: { width: 375, height: 667 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme, acceptDownloads: true });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage();
  const ready = () => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
  await p.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`); await ready();
  await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
  await p.evaluate(() => document.fonts.ready);
  await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } });
  await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
  await p.waitForFunction(() => location.hash === '#/focus'); await sleep(2500);
  await p.evaluate(() => window.__kettle.timer.getState().end('user'));
  await p.waitForFunction(() => location.hash === '#/' || location.hash === '');
  await p.waitForSelector(`[id="${WARN}"]`, { timeout: 8000 });
  await sleep(800);
  await p.evaluate(() => {
    const R = (window.__kb = { ev: [], t0: performance.now() });
    new MutationObserver((ms) => { for (const m of ms) { for (const x of m.addedNodes) if (x.tagName === 'LI') R.ev.push([Math.round(performance.now() - R.t0), '+', x.id]); for (const x of m.removedNodes) if (x.tagName === 'LI') R.ev.push([Math.round(performance.now() - R.t0), '-', x.id]); } }).observe(document.body, { childList: true, subtree: true });
  });
  const snap = () => p.evaluate((W) => {
    const a = document.activeElement;
    const desc = a && a !== document.body ? `${a.tagName.toLowerCase()}${a.id ? '#' + a.id : ''} "${(a.getAttribute('aria-label') || a.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 34)}"` : 'body';
    const ar = a?.getBoundingClientRect();
    const w = document.getElementById(W);
    const wr = w?.getBoundingClientRect();
    const region = document.querySelector('[aria-label="Notifications"]')?.parentElement;
    const dock = [...document.querySelectorAll('[data-toast-above]')].map((d) => d.getBoundingClientRect()).filter((r) => r.height > 0);
    return { t: Math.round(performance.now() - window.__kb.t0), focus: desc, focusBox: ar ? [Math.round(ar.top), Math.round(ar.bottom)] : null, inDock: !!a?.closest?.('[data-toast-above]'), inToast: !!a?.closest?.('[aria-label="Notifications"]'), warning: wr ? [Math.round(wr.top), Math.round(wr.bottom)] : null, regionBottom: region ? Math.round(region.getBoundingClientRect().bottom) : null, regionStyleBottom: region?.style.bottom || '', dockTop: dock.length ? Math.round(Math.min(...dock.map((r) => r.top))) : null, scrollY: Math.round(scrollY) };
  }, WARN);
  const log = [await snap()];
  let reached = null;
  for (let i = 1; i <= +maxArg; i++) {
    await p.keyboard.press(KEY);
    await sleep(+gapArg);
    const s = await snap();
    s.tab = i;
    log.push(s);
    if (s.inToast && /Save backup/.test(s.focus)) { reached = i; break; }
  }
  const ev = await p.evaluate(() => window.__kb.ev);
  let result = { label, reached, tabs: log.length - 1, warningEvents: ev };
  if (reached) {
    result.focusVisible = await p.evaluate(() => { const a = document.activeElement; const cs = getComputedStyle(a); return { matches: a.matches(':focus-visible'), outline: `${cs.outlineStyle} ${cs.outlineWidth} ${cs.outlineColor}`, offset: cs.outlineOffset, boxShadow: cs.boxShadow.slice(0, 80) }; });
    await p.screenshot({ path: `${out}/kbd-${tag}-375x667-${pct}-${theme}-${KEY.replace('+', '')}-save-backup-focused.png` });
    const dl = p.waitForEvent('download', { timeout: 8000 }).catch(() => null);
    await p.keyboard.press('Enter');
    const d = await dl;
    result.enterDownloads = d ? d.suggestedFilename() : null;
  } else {
    await p.screenshot({ path: `${out}/kbd-${tag}-375x667-${pct}-${theme}-${KEY.replace('+', '')}-not-reached.png` });
  }
  console.log(`${label}: ${reached ? `REACHED after ${reached} Tabs; focus-visible ${JSON.stringify(result.focusVisible)}; Enter → ${result.enterDownloads}` : `NOT reached in ${maxArg} Tabs`} | warning removals/adds ${JSON.stringify(ev.filter((e) => e[2] === WARN))}`);
  for (const s of log) console.log(`  ${String(s.tab ?? 0).padStart(2)} t=${s.t} ${s.focus}${s.inDock ? ' [dock]' : ''}${s.inToast ? ' [toast]' : ''} box ${JSON.stringify(s.focusBox)} | warning ${JSON.stringify(s.warning)} region bottom ${s.regionBottom} (${s.regionStyleBottom}) dock top ${s.dockTop} scrollY ${s.scrollY}`);
  appendFileSync(`${out}/kbd-${tag}.jsonl`, JSON.stringify({ ...result, log }) + '\n');
  await ctx.close();
}
await b.close();

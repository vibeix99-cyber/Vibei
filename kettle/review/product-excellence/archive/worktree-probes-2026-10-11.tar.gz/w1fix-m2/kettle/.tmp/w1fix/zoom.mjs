// R4-D2 retest: live mobile resizes at large text must not leave the page zoomed in.
// node .tmp/w1fix/zoom.mjs <base> <tag> [reps=3] [filter]
import { chromium } from 'playwright';
const [,, base, tag, repsArg = '3', filter = ''] = process.argv;
const reps = +repsArg;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SEQ = {
  bounce: { start: [414, 667], run: async (p) => { for (const w of [414, 375, 390, 375, 400, 375, 384, 375, 414, 375]) await p.setViewportSize({ width: w, height: 667 }); } },
  wiggle: { start: [414, 667], run: async (p) => { for (let k = 0; k < 3; k++) { for (let w = 412; w >= 376; w -= 2) { await p.setViewportSize({ width: w, height: 667 }); await sleep(16); } for (let w = 376; w <= 412; w += 2) { await p.setViewportSize({ width: w, height: 667 }); await sleep(16); } } await p.setViewportSize({ width: 375, height: 667 }); } },
  drag2: { start: [414, 667], run: async (p) => { for (let w = 412; w >= 376; w -= 2) { await p.setViewportSize({ width: w, height: 667 }); await sleep(16); } await p.setViewportSize({ width: 375, height: 667 }); } },
  drag1: { start: [414, 667], run: async (p) => { for (let w = 413; w >= 375; w--) await p.setViewportSize({ width: w, height: 667 }); } },
  rotate4: { start: [375, 667], run: async (p) => { for (const [w, h] of [[667, 375], [375, 667], [667, 375], [375, 667]]) await p.setViewportSize({ width: w, height: h }); } },
};
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
let fails = 0, n = 0;
for (const pct of [200, 150]) for (const theme of ['light', 'dark']) for (const [name, seq] of Object.entries(SEQ)) for (let r = 0; r < reps; r++) {
  if (filter && !`${name} t${pct} ${theme}`.match(new RegExp(filter))) continue;
  const ctx = await b.newContext({ viewport: { width: seq.start[0], height: seq.start[1] }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.waitForFunction(() => !!window.__kettle); await p.evaluate(() => document.fonts.ready); await sleep(1200);
  await seq.run(p);
  await sleep(2000);
  const r = await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); const d = document.documentElement; return { scale: +visualViewport.scale.toFixed(3), vvw: Math.round(visualViewport.width), iw: innerWidth, sw: d.scrollWidth, cw: d.clientWidth, mode: el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal', barRight: Math.round(Math.max(el.getBoundingClientRect().right, ...[...el.children].map((c) => c.getBoundingClientRect().right))) }; });
  n++;
  const ok = r.scale === 1 && r.vvw === r.iw && r.sw <= r.cw && r.barRight <= r.iw;
  if (!ok) fails++;
  console.log(`${tag} ${name} t${pct} ${theme} #${n}: ${ok ? 'OK' : 'FAIL'} ${JSON.stringify(r)}`);
  await ctx.close();
}
console.log(`failures: ${fails} of ${n}`);
await b.close();

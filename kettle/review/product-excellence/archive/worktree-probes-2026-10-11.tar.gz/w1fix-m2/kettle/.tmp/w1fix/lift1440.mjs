// Why the Home toast stack sits at a different height at 1440×900 in the BEFORE / AFTER captures: the same setup as
// capture6.mjs home-warning, then every [data-toast-above] element, toastLiftBottom(), the region's inline bottom and
// the toasts, sampled at 0, 0.5, 1, 2 and 4 s after the warning appears. node .tmp/w1fix/lift1440.mjs <base> <tag>
import { chromium } from 'playwright';
const [,, base, tag] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, colorScheme: 'light' });
await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
const p = await ctx.newPage();
const ready = () => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
await p.goto(`${base}/?debug&theme=light&nooktime=day#/`); await ready();
await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
await p.evaluate(() => document.fonts.ready); await sleep(600);
await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } });
await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
await p.waitForFunction(() => location.hash === '#/focus'); await sleep(2500);
await p.evaluate(() => window.__kettle.timer.getState().end('user'));
await p.waitForFunction(() => location.hash === '#/' || location.hash === '');
await p.waitForSelector('[id="toast-kettle:save-failed"]', { timeout: 8000 });
const t0 = Date.now();
for (const at of [0, 500, 1000, 2000, 4000]) {
  await sleep(Math.max(0, at - (Date.now() - t0)));
  const s = await p.evaluate(() => {
    const els = [...document.querySelectorAll('[data-toast-above]')].map((el) => { const r = el.getBoundingClientRect(); return { cls: String(el.className).slice(0, 28), top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height), hidden: !!el.closest('[aria-hidden="true"], [inert]'), counted: r.height > 0 && r.top < innerHeight && r.bottom > innerHeight * 0.6 && !el.closest('[aria-hidden="true"], [inert]') }; });
    const region = document.querySelector('[aria-label="Notifications"]').parentElement;
    const lis = [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => { const r = li.getBoundingClientRect(); return [li.textContent.trim().slice(0, 12), Math.round(r.top), Math.round(r.bottom)]; });
    return { scrollY: Math.round(scrollY), docH: document.documentElement.scrollHeight, els, regionStyleBottom: region.style.bottom, regionBottom: Math.round(region.getBoundingClientRect().bottom), lis };
  });
  console.log(`${tag} +${at} ms: scrollY ${s.scrollY} (doc ${s.docH}) region bottom ${s.regionBottom} (style ${s.regionStyleBottom}) toasts ${JSON.stringify(s.lis)} data-toast-above ${JSON.stringify(s.els)}`);
}
await b.close();

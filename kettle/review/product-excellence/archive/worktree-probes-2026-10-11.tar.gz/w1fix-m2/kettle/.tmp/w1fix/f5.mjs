// Finding 5: which ordinary toasts can appear on the session screen (/focus) on a phone, and where they sit.
import { chromium } from 'playwright';
const [,, base, out = ''] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const seed of ['newbie', 'veteran']) for (const [w, h] of [[390, 844], [375, 667]]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const p = await ctx.newPage();
  await p.addInitScript(() => { window.__toasts = []; const mo = new MutationObserver(() => { for (const li of document.querySelectorAll('[aria-label="Notifications"] li')) { if (li.__seen) continue; li.__seen = 1; window.__toasts.push({ t: Math.round(performance.now()), route: location.hash, text: li.textContent.trim().slice(0, 60), timer: window.__kettle && window.__kettle.timer.getState().status }); } }); addEventListener('DOMContentLoaded', () => mo.observe(document.body, { subtree: true, childList: true })); });
  await p.goto(`${base}/?debug&seed=${seed}&theme=light&nooktime=day#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
  await p.evaluate(() => window.__kettle.settings.getState().set({ autoStartBreaks: false, autoStartFocus: false, muted: true }));
  const log = [];
  const where = async (label) => { const r = await p.evaluate(() => { const li = document.querySelector('[aria-label="Notifications"] li'); const tm = document.querySelector('[role=timer]'); const tr = li && li.getBoundingClientRect(); const rr = tm && tm.getBoundingClientRect(); return { route: location.hash, status: window.__kettle.timer.getState().status, phase: window.__kettle.timer.getState().phase, toast: li ? li.textContent.trim().slice(0, 50) : null, toastY: tr ? [Math.round(tr.top), Math.round(tr.bottom)] : null, readoutY: rr ? [Math.round(rr.top), Math.round(rr.bottom)] : null, overReadout: !!(tr && rr && tr.bottom > rr.top && tr.top < rr.bottom) }; }); log.push(`${label}: ${JSON.stringify(r)}`); return r; };
  await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Probe', tag: 'work' }));
  await p.waitForTimeout(3000); await where('running brew');
  await p.evaluate(() => window.__kettle.finish());
  await p.getByRole('button', { name: /Tea time|Long tea break/ }).waitFor({ timeout: 60000 }); await p.waitForTimeout(2500); await where('summary');
  await p.getByRole('button', { name: /Tea time|Long tea break/ }).click(); await p.waitForTimeout(2500); await where('break running');
  await p.evaluate(() => window.__kettle.finish()); await p.waitForTimeout(2500);
  const r = await where('break over');
  if (out && r.toast) await p.screenshot({ path: `${out}/f5-${seed}-${w}x${h}-break-over.png` });
  const all = await p.evaluate(() => window.__toasts);
  console.log(`${seed} ${w}x${h}\n  ` + log.join('\n  ') + `\n  every toast seen: ${JSON.stringify(all)}`);
  await ctx.close();
}
await b.close();

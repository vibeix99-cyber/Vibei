// Compare two capture-storage-full runs state by state (route + toasts on screen). node metacmp.mjs <dirA> <dirB>
import { readFileSync } from 'node:fs';
const [,, A, B] = process.argv;
let diff = 0;
for (const cfg of ['phone-390x844-light', 'phone-390x844-dark', 'phone-375x667-light', 'phone-375x667-dark', 'desktop-1440x900-light', 'desktop-1440x900-dark']) {
  const a = JSON.parse(readFileSync(`${A}/${cfg}/capture-meta.json`, 'utf8'));
  const b = JSON.parse(readFileSync(`${B}/${cfg}/capture-meta.json`, 'utf8'));
  const rows = [];
  for (const s of Object.keys(a.states)) {
    const x = a.states[s], y = b.states[s];
    const same = y && x.hash === y.hash && JSON.stringify(x.toast) === JSON.stringify(y.toast);
    if (!same) diff++;
    rows.push(`${s}:${same ? 'same' : `DIFF ${JSON.stringify(x)} vs ${JSON.stringify(y)}`}`);
  }
  console.log(`${cfg} (${b.revision}; errors ${b.errors.length}): ${rows.join(' ')}`);
}
console.log(`states differing: ${diff}`);

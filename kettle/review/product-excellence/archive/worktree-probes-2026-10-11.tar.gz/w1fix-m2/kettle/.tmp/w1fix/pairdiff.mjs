import { chromium } from 'playwright';
import { readFileSync, readdirSync } from 'node:fs';
const [,, dir] = process.argv;
const b = await chromium.launch(); const p = await b.newPage();
for (const f of readdirSync(dir).filter((x) => x.endsWith('-before.png')).sort()) {
  const g = f.replace('-before.png', '-after.png');
  const r = await p.evaluate(async ([x, y]) => {
    const load = async (s) => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + s)).blob()); const c = new OffscreenCanvas(bm.width, bm.height); const g = c.getContext('2d'); g.drawImage(bm, 0, 0); return { w: bm.width, h: bm.height, d: g.getImageData(0, 0, bm.width, bm.height).data }; };
    const a = await load(x), c = await load(y); if (a.w !== c.w || a.h !== c.h) return 'size differs';
    let n = 0, minY = 1e9, maxY = -1; for (let i = 0; i < a.d.length; i += 4) { if (Math.abs(a.d[i] - c.d[i]) + Math.abs(a.d[i + 1] - c.d[i + 1]) + Math.abs(a.d[i + 2] - c.d[i + 2]) > 48) { n++; const yy = Math.floor(i / 4 / a.w); minY = Math.min(minY, yy); maxY = Math.max(maxY, yy); } }
    return `${(100 * n / (a.w * a.h)).toFixed(2)}% changed${n ? ` (rows ${minY}-${maxY} of ${a.h})` : ''}`;
  }, [readFileSync(`${dir}/${f}`).toString('base64'), readFileSync(`${dir}/${g}`).toString('base64')]);
  console.log(f.replace('-before.png', ''), r);
}
await b.close();

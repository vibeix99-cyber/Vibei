import { chromium } from 'playwright';
const [,, base] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:375,height:667}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
const cdp = await ctx.newCDPSession(p);
const drag = async (x, y0, y1) => {
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y: y0 }] });
  for (let i = 1; i <= 12; i++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: y0 + ((y1 - y0) * i) / 12 }] }); await p.waitForTimeout(16); }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await p.waitForTimeout(800);
};
await drag(180, 500, 300);
console.log('control: page scrollY after a touch drag on the page', await p.evaluate(() => Math.round(scrollY)));
await p.evaluate(() => scrollTo(0, 0)); await p.waitForTimeout(300);
await p.evaluate(async () => (await import('/src/ui/Toast.tsx')).toast('Kettle couldn’t save your latest changes: this browser’s storage is full. Save a backup to keep them.', { tone: 'warning', duration: 60000, action: { label: 'Save backup', onClick() {} } }));
await p.waitForTimeout(1500);
const box = await p.locator('[aria-label="Notifications"] li').boundingBox();
await drag(Math.round(box.x + 80), Math.round(box.y + 200), Math.round(box.y + 60));
console.log('toast list scrollTop after a touch drag on the toast', await p.evaluate(() => { const l = document.querySelector('[aria-label="Notifications"] ol'); return [Math.round(l.scrollTop), l.scrollHeight - l.clientHeight]; }), 'page scrollY', await p.evaluate(() => Math.round(scrollY)));
await b.close();

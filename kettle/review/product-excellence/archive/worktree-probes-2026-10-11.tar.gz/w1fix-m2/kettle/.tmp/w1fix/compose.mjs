// Side-by-side: REFERENCE (K01) | ORIGINAL BASELINE (8f1044a) | INTEGRATED BEFORE FIX (1bec1a8) | CURRENT AFTER.
import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const [,, out, ...pairs] = process.argv; // label=path ...
const items = pairs.map((p) => { const i = p.indexOf('='); return { label: p.slice(0, i), b64: readFileSync(p.slice(i + 1)).toString('base64') }; });
const b = await chromium.launch();
const page = await b.newPage();
const png = await page.evaluate(async (items) => {
  const bms = await Promise.all(items.map(async (it) => createImageBitmap(await (await fetch('data:image/png;base64,' + it.b64)).blob())));
  const H = 1100, gap = 24, head = 70;
  const ws = bms.map((bm) => Math.round(bm.width * Math.min(1, H / bm.height)));
  const c = new OffscreenCanvas(ws.reduce((a, w) => a + w + gap, gap), H + head + gap);
  const g = c.getContext('2d'); g.fillStyle = '#ffffff'; g.fillRect(0, 0, c.width, c.height);
  let x = gap;
  bms.forEach((bm, i) => { const s = Math.min(1, H / bm.height); const h = Math.round(bm.height * s);
    g.fillStyle = '#222'; g.font = 'bold 26px sans-serif'; g.fillText(items[i].label, x, 44);
    g.drawImage(bm, 0, 0, bm.width, Math.min(bm.height, H / s), x, head, ws[i], Math.min(h, H)); x += ws[i] + gap; });
  const blob = await c.convertToBlob({ type: 'image/png' });
  const buf = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (const v of buf) s += String.fromCharCode(v); return btoa(s);
}, items);
(await import('node:fs')).writeFileSync(out, Buffer.from(png, 'base64'));
await b.close();
console.log(out);

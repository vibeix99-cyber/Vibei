// R2-D3 real flow: storage full, brew ended early (within 1 min / after 12 min), back on Today with the warning stacked.
// node .tmp/w1fix/earlyend.mjs <base> <tag> <outDir>
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, out] = process.argv; mkdirSync(out, { recursive: true });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
let fails = 0;
for (const theme of ['light', 'dark']) for (const [w, h, mobile] of [[375, 667, true], [390, 844, true], [1440, 900, false]]) for (const pct of [100, 150, 200]) for (const [flow, ms] of [['within1min', 20_000], ['after12min', 12 * 60_000]]) {
  if (process.env.ONLY && !`${theme} ${w}x${h}@${pct}`.match(new RegExp(process.env.ONLY))) continue;
  if (process.env.FLOW && flow !== process.env.FLOW) continue;
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: mobile ? 2 : 1, isMobile: mobile, hasTouch: mobile, colorScheme: theme, acceptDownloads: true });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=newbie&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.waitForFunction(() => !!window.__kettle); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1200);
  await p.evaluate(() => window.__kettle.settings.getState().set({ autoStartBreaks: false, autoStartFocus: false, muted: true }));
  await p.evaluate(() => window.__kettle.timer.setState({}));
  const err = await p.evaluate(() => { let c = 'x'.repeat(1024 * 1024), i = 0; while (c.length >= 8) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(4096)); return 'no error'; } catch (e) { return e.name; } });
  // LEVELUP=1: park the profile one leaf below its next cozy level, so the brew's leaves bring a level-up toast too.
  if (process.env.LEVELUP) await p.evaluate(async () => { const { leavesForLevel, levelFromLeaves } = await import('/src/progress/levels.ts'); const L = levelFromLeaves(window.__kettle.progress.getState().leaves).level; window.__kettle.progress.setState({ leaves: leavesForLevel(L + 1) - 1 }); });
  await p.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25, intention: 'Storage full' }));
  await p.waitForTimeout(1500);
  await p.evaluate((m) => window.__kettle.ff(m), ms); await p.waitForTimeout(600);
  await p.evaluate(() => window.__kettle.timer.getState().end('user'));
  await p.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 30000 });
  // Hold every toast while it is examined (a reader's pointer over the stack pauses them the same way).
  await p.waitForFunction(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].some((li) => /storage is full/.test(li.textContent)), null, { timeout: 25000 }).catch(() => {});
  await p.waitForTimeout(700);
  await p.evaluate(() => { for (const li of document.querySelectorAll('[aria-label="Notifications"] li')) li.dispatchEvent(new PointerEvent('pointerenter')); });
  await p.waitForTimeout(1200);
  await p.waitForFunction(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].every((li) => getComputedStyle(li).transform === 'none'), null, { timeout: 5000 }).catch(() => {});
  const r = await p.evaluate(() => {
    const list = document.querySelector('[aria-label="Notifications"] ol');
    const lis = [...list.querySelectorAll(':scope > li')];
    const cs = getComputedStyle(list); const scroller = /(auto|scroll)/.test(cs.overflowY);
    const lr = list.getBoundingClientRect();
    const texts = lis.map((li) => li.textContent.trim().slice(0, 28));
    const innerScroll = lis.map((li) => /(auto|scroll)/.test(getComputedStyle(li).overflowY) ? Math.round(li.scrollHeight - li.clientHeight) : 0);
    const spill = lis.map((li) => { if (/(auto|scroll)/.test(getComputedStyle(li).overflowY)) return 0; const r = li.getBoundingClientRect(); const kids = [...li.querySelectorAll('*')].filter((n) => n.getClientRects().length); return Math.round(Math.max(0, ...kids.map((k) => k.getBoundingClientRect().bottom - r.bottom), ...kids.map((k) => r.top - k.getBoundingClientRect().top))); });
    const top = Math.min(...lis.map((li) => li.getBoundingClientRect().top));
    const visBottom = scroller ? lr.bottom : Math.max(...lis.map((li) => li.getBoundingClientRect().bottom));
    const dock = document.querySelector('[data-toast-above]'); const dt = dock ? dock.getBoundingClientRect().top : innerHeight;
    const warn = lis.find((li) => /storage is full/.test(li.textContent));
    const rectsDbg = lis.map((li) => { const r = li.getBoundingClientRect(); return [Math.round(r.top), Math.round(r.bottom), getComputedStyle(li).opacity, getComputedStyle(li).transform]; }); const regionR = list.closest('[aria-label="Notifications"]').parentElement.getBoundingClientRect();
    const noneBelowRoom = lis.every((li) => li.getBoundingClientRect().bottom <= dt + 0.5);
    const visTop = Math.max(0, scroller ? lr.top : 0); const nr = lis[lis.length - 1].getBoundingClientRect(); const vb = Math.min(innerHeight, visBottom); const newestInView = nr.bottom <= vb + 1 && nr.bottom >= visTop && (nr.top >= visTop - 1 || nr.height > vb - visTop);
    const seenT = lis.map(() => false), seenB = lis.map(() => false); const st0 = list.scrollTop; const rng = Math.ceil(list.scrollHeight);
    for (let y = -rng; y <= rng; y += 8) { list.scrollTop = y; lis.forEach((li, i) => { const q = li.getBoundingClientRect(); if (q.top >= visTop - 1 && q.top <= visBottom + 1) seenT[i] = true; if (q.bottom <= visBottom + 1 && q.bottom >= visTop - 1) seenB[i] = true; }); }
    list.scrollTop = st0; const allReachable = seenT.every(Boolean) && seenB.every(Boolean);
    return { innerScroll, newestInView, noneBelowRoom, allReachable, rectsDbg, list: [Math.round(lr.top), Math.round(lr.bottom)], region: [Math.round(regionR.top), Math.round(regionR.bottom)], texts, spill, scroller, scrollRange: Math.round(list.scrollHeight - list.clientHeight), dockClear: visBottom <= dt + 0.5, hasWarning: !!warn };
  });
  if (process.env.TRACE) { const tr = []; for (let i = 0; i < 15; i++) { tr.push(await p.evaluate(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => getComputedStyle(li).transform.replace('matrix(1, 0, 0, 1, ', '').replace(')', '')).join(';'))); await p.waitForTimeout(200); } console.log('TRACE transforms every 200 ms:', tr.join(' | ')); }
  const btnHitEarly = await p.evaluate(() => { const b = [...document.querySelectorAll('[aria-label="Notifications"] button')].find((x) => /Save backup/.test(x.textContent)); if (!b) return false; const br = b.getBoundingClientRect(); return b.contains(document.elementFromPoint(br.left + br.width / 2, br.top + br.height / 2)); });
  // Read the whole warning by scrolling: every line of its message passes through the visible box.
  const seen = await p.evaluate(async () => {
    const list = document.querySelector('[aria-label="Notifications"] ol');
    const warn = [...list.querySelectorAll(':scope > li')].find((li) => /storage is full/.test(li.textContent)); if (!warn) return null;
    const msg = warn.querySelector('span:nth-of-type(2)'); const range = document.createRange(); range.selectNodeContents(msg);
    const lines = [...range.getClientRects()].map((r) => Math.round(r.top - msg.getBoundingClientRect().top));
    const box = () => { const lr = list.getBoundingClientRect(); const wr = warn.getBoundingClientRect(); const s = /(auto|scroll)/.test(getComputedStyle(list).overflowY); const t = Math.max(0, s ? lr.top : 0, wr.top), bt = Math.min(innerHeight, s ? lr.bottom : innerHeight, wr.bottom); return [t, bt]; };
    const act = warn.querySelector('button'); const seenLines = new Set();
    const st0 = list.scrollTop; const rng = Math.ceil(list.scrollHeight);
    for (let y = -rng; y <= rng; y += 10) for (let z = 0; z <= warn.scrollHeight; z += 10) {
      list.scrollTop = y; warn.scrollTop = z;
      const [t, bt] = box(); const ar = act.getBoundingClientRect();
      for (const r of range.getClientRects()) { const covered = r.bottom > ar.top && r.top < ar.bottom && r.right > ar.left; if (r.top >= t - 1 && r.bottom <= bt + 1 && !covered) seenLines.add(Math.round(r.top - msg.getBoundingClientRect().top)); }
      if (warn.scrollTop + warn.clientHeight >= warn.scrollHeight) break;
    }
    list.scrollTop = st0; warn.scrollTop = 0; await new Promise((r) => requestAnimationFrame(r));
    return { lines: new Set(lines).size, readable: seenLines.size };
  });
  let downloaded = false; let btnHit = null;
  if (r.hasWarning) {
    btnHit = await p.evaluate(() => { const b = [...document.querySelectorAll('[aria-label="Notifications"] button')].find((x) => /Save backup/.test(x.textContent)); if (!b) return 'no button: ' + [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.textContent.slice(0, 40)).join(' | '); const br = b.getBoundingClientRect(); return b.contains(document.elementFromPoint(br.left + br.width / 2, br.top + br.height / 2)); });
    await p.screenshot({ path: `${out}/earlyend-${flow}-${w}x${h}-t${pct}-${theme}-${tag}.png` });
    const dl = p.waitForEvent('download', { timeout: 15000 }).then(() => true).catch(() => false);
    // A real tap/click at the button's centre (hit-tested by the browser), without Playwright's stability wait: the
    // flow keeps re-measuring the toast lift while the warning is up.
    const c = await p.evaluate(() => { const b = [...document.querySelectorAll('[aria-label="Notifications"] button')].find((x) => /Save backup/.test(x.textContent)); if (!b) return null; const r = b.getBoundingClientRect(); const x = r.left + r.width / 2, y = r.top + r.height / 2; return [x, y, b.contains(document.elementFromPoint(x, y))]; });
    btnHit = c ? c[2] : false;
    if (c) { if (mobile) await p.touchscreen.tap(c[0], c[1]); else await p.mouse.click(c[0], c[1]); }
    downloaded = await dl;
    if (!downloaded) console.log('after tap toasts:', await p.evaluate(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.textContent.slice(0, 60)).join(' | ')), 'tap at', JSON.stringify(c));
  }
  const ok = err === 'QuotaExceededError' && r.hasWarning && r.spill.every((x) => x === 0) && r.newestInView && r.allReachable && r.dockClear && r.noneBelowRoom && btnHit === true && downloaded && seen && seen.readable >= seen.lines;
  if (!ok) fails++;
  console.log(`${tag} ${theme} ${w}x${h} ${pct}% ${flow}: ${ok ? 'OK' : 'FAIL'} ${JSON.stringify({ quota: err, ...r, readByScrolling: seen, saveBackupHitAtTap: btnHit, saveBackupHitBeforeReading: btnHitEarly, downloaded })}`);
  await ctx.close();
}
console.log(`failures: ${fails}`);
await b.close();

// r6 packet item (f): full-size BEFORE / AFTER captures of the states the combined fix touches.
//   node .tmp/w1fix/capture6.mjs <base> <rev label> <outDir> [configFilter] [stateFilter]
// Viewports 390×844, 375×667, 1440×900, 844×390 (phones at DPR 2 with touch; 1440 at DPR 1), light and dark, 100 % text.
// Each state in a fresh context (a disposable profile), newbie seed, 3D scene off (stills), sound muted:
//   home-warning          storage really full; a brew started and ended within its first minute → Today with
//                         "Kettle's off" and the storage-full warning (warning + 1.0 s)
//   focus-warning-toasts  storage really full; a brew started → the session screen; 3 s later two ordinary toasts
//                         ("Recipe done …", "New badge: Tea Time") are raised; + 1.5 s. (Where the warning may show is
//                         M1's rule: on phones it waits for the brew to end, on wide layouts it shows over the stage.)
//   breakover-toasts      a brew completed → summary → Tea time → the break ends → "Break's over" with the carried task;
//                         the natural toasts put away, two toasts raised (as tests/a11y.spec.ts and the D4 probe do); + 1.5 s
//   summary-levelup       one leaf below the next cozy level; a brew completed → whistle → summary (+ 2.5 s)
// Writes <out>/<config>/<state>.png and <out>/<config>/meta.json (route, toasts on screen, warning box, page errors).
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';
const [,, base, rev, out, cfgFilter = '', stateFilter = ''] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const WARN = 'toast-kettle:save-failed';
const MSGS = [['Recipe done: Take 2 full tea breaks · +15 leaves', 'success'], ['New badge: Tea Time', 'success']];
const CONFIGS = [];
for (const theme of ['light', 'dark']) for (const [name, w, h, phone] of [['phone-390x844', 390, 844, true], ['phone-375x667', 375, 667, true], ['desktop-1440x900', 1440, 900, false], ['landscape-844x390', 844, 390, true]]) CONFIGS.push({ id: `${name}-${theme}`, w, h, phone, theme });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const fill = (p) => p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; } });
const raise = (p, items) => p.evaluate(async (items) => { const { toast } = await import('/src/ui/Toast.tsx'); for (const [m, tone] of items) toast(m, { tone, duration: 60_000 }); }, items);
const STATES = {
  async 'home-warning'(p) {
    const q = await fill(p);
    await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await p.waitForFunction(() => location.hash === '#/focus'); await sleep(2500);
    await p.evaluate(() => window.__kettle.timer.getState().end('user'));
    await p.waitForFunction(() => location.hash === '#/' || location.hash === '');
    const shown = await p.waitForSelector(`[id="${WARN}"]`, { timeout: 8000 }).then(() => true, () => false);
    await sleep(1000);
    return { quota: q, warningAppeared: shown };
  },
  async 'focus-warning-toasts'(p) {
    const q = await fill(p);
    await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await p.waitForFunction(() => location.hash === '#/focus'); await sleep(3000);
    await raise(p, MSGS); await sleep(1500);
    return { quota: q };
  },
  async 'breakover-toasts'(p) {
    await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await sleep(2500);
    await p.evaluate(() => window.__kettle.nearEnd()); await sleep(400);
    await p.evaluate(() => window.__kettle.finish());
    await p.getByRole('button', { name: /Tea time|Long tea break/ }).waitFor({ state: 'visible', timeout: 60_000 });
    await sleep(1500);
    await p.evaluate(() => [...document.querySelectorAll('button')].find((x) => /Tea time|Long tea break/.test(x.textContent)).click());
    await sleep(2000);
    await p.evaluate(() => window.__kettle.finish());
    await p.getByRole('button', { name: /Mark it done, start fresh/ }).waitFor({ state: 'visible', timeout: 30_000 });
    await sleep(1500);
    await p.evaluate(async () => (await import('/src/ui/Toast.tsx')).toast.dismiss()); await sleep(700);
    await raise(p, MSGS); await sleep(1500);
    return {};
  },
  async 'summary-levelup'(p) {
    await p.evaluate(async () => { const { leavesForLevel, levelFromLeaves } = await import('/src/progress/levels.ts'); const L = levelFromLeaves(window.__kettle.progress.getState().leaves).level; window.__kettle.progress.setState({ leaves: leavesForLevel(L + 1) - 1 }); });
    await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await sleep(2500);
    await p.evaluate(() => window.__kettle.nearEnd()); await sleep(400);
    await p.evaluate(() => window.__kettle.finish());
    await p.getByRole('button', { name: /Tea time|Long tea break/ }).waitFor({ state: 'visible', timeout: 60_000 });
    await sleep(2500);
    return {};
  },
};
let errorsTotal = 0;
for (const c of CONFIGS) {
  if (cfgFilter && !c.id.match(new RegExp(cfgFilter))) continue;
  mkdirSync(`${out}/${c.id}`, { recursive: true });
  const meta = { revision: rev, base, config: c, states: {} };
  for (const [name, run] of Object.entries(STATES)) {
    if (stateFilter && !name.match(new RegExp(stateFilter))) continue;
    const ctx = await b.newContext({ viewport: { width: c.w, height: c.h }, deviceScaleFactor: c.phone ? 2 : 1, isMobile: c.phone, hasTouch: c.phone, colorScheme: c.theme, acceptDownloads: true });
    await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
    const p = await ctx.newPage();
    const errors = []; p.on('pageerror', (e) => errors.push(e.message));
    let info = {};
    try {
      const ready = () => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
      await p.goto(`${base}/?debug&theme=${c.theme}${c.theme === 'light' ? '&nooktime=day' : ''}#/`); await ready();
      await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
      await p.evaluate(() => document.fonts.ready); await sleep(600);
      info = await run(p);
      info.route = await p.evaluate(() => location.hash);
      info.toasts = await p.evaluate(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => { const r = li.getBoundingClientRect(); return [li.textContent.trim().slice(0, 48), Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom), +getComputedStyle(li).opacity]; }));
      info.warning = await p.evaluate((W) => { const w = document.getElementById(W); if (!w) return null; const r = w.getBoundingClientRect(); return [Math.round(r.top), Math.round(r.bottom), w.scrollTop]; }, WARN);
      await p.screenshot({ path: `${out}/${c.id}/${name}.png` });
    } catch (e) { info.error = String(e.message).split('\n')[0]; }
    info.pageErrors = errors; errorsTotal += errors.length;
    meta.states[name] = info;
    console.log(`${rev} ${c.id} ${name}: ${info.error ? 'ERROR ' + info.error : 'ok'} route ${info.route} toasts ${JSON.stringify((info.toasts ?? []).map((t) => t[0].slice(0, 22)))} warning ${JSON.stringify(info.warning)}${errors.length ? ' errors ' + errors.length : ''}`);
    await ctx.close();
  }
  writeFileSync(`${out}/${c.id}/meta.json`, JSON.stringify(meta, null, 1));
}
console.log(`${rev}: page errors ${errorsTotal}`);
await b.close();

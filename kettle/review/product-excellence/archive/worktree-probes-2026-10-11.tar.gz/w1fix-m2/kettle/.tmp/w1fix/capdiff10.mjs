// Pixel diff of two capture folders, same file names. node .tmp/w1fix/capdiff.mjs <dirA> <dirB>
import { chromium } from 'playwright';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
const [,, A, B] = process.argv;
const b = await chromium.launch(); const p = await b.newPage();
for (const cfg of readdirSync(B).sort()) for (const f of ['01-home.png', '01b-home-scrolled.png', '10-break-over.png']) {
  if (!existsSync(`${A}/${cfg}/${f}`)) continue;
  const r = await p.evaluate(async ([x, y]) => {
    const load = async (s) => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + s)).blob()); const c = new OffscreenCanvas(bm.width, bm.height); const g = c.getContext('2d'); g.drawImage(bm, 0, 0); return { w: bm.width, h: bm.height, d: g.getImageData(0, 0, bm.width, bm.height).data }; };
    const a = await load(x), c = await load(y); if (a.w !== c.w || a.h !== c.h) return 'size differs';
    let n = 0, minY = 1e9, maxY = -1; for (let i = 0; i < a.d.length; i += 4) { if (Math.abs(a.d[i] - c.d[i]) + Math.abs(a.d[i + 1] - c.d[i + 1]) + Math.abs(a.d[i + 2] - c.d[i + 2]) > 48) { n++; const yy = Math.floor(i / 4 / a.w); minY = Math.min(minY, yy); maxY = Math.max(maxY, yy); } }
    return `${(100 * n / (a.w * a.h)).toFixed(3)} % differ${n ? ` (rows ${minY}-${maxY} of ${a.h})` : ''}`;
  }, [readFileSync(`${A}/${cfg}/${f}`).toString('base64'), readFileSync(`${B}/${cfg}/${f}`).toString('base64')]);
  console.log(`${cfg}/${f}: ${r}`);
}
await b.close();

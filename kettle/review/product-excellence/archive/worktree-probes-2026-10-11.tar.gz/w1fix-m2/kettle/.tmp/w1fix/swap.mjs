import { chromium } from 'playwright';
const [,, base, W, H] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:+W,height:+H}, deviceScaleFactor:2, isMobile:true, hasTouch:true, serviceWorkers:'block' });
await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
const p = await ctx.newPage();
await p.route('**/*.woff2', async (r) => { await new Promise((ok) => setTimeout(ok, 2500)); await r.continue(); });
p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`).catch(() => {});
const snap = () => p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); if (!el) return null; const kids=[...el.children]; return { t: Math.round(performance.now()), fonts: document.fonts.status, mode: el.hasAttribute('data-wrap')?'wrap':el.hasAttribute('data-tight')?'tight':'normal', rows: new Set(kids.map(k=>Math.round(k.getBoundingClientRect().top))).size, h: Math.round(el.getBoundingClientRect().height), widths: kids.map(k=>Math.round(k.getBoundingClientRect().width)), greet: Math.round(document.getElementById('home-greeting').getBoundingClientRect().top) }; }).catch(() => null);
for (let i = 0; i < 14; i++) { await p.waitForTimeout(400); console.log(JSON.stringify(await snap())); }
await b.close();

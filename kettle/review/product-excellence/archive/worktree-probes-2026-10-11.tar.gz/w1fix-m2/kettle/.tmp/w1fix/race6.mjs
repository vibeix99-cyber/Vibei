// R5-D1 retest with REAL input and REAL toast timers (no per-frame hold): does the storage-full warning's box ever leave
// its room (over the docked start), or the warning get taken away, while older toasts time out around a scrolled list?
//   node .tmp/w1fix/race6.mjs <base> <tag> <outDir> <mode=natural|targeted> [filter] [reps=3]
//   natural:  pointer on the stack; scroll up as far as the stack goes; wait W (0.6/1.2/1.8 s, real timers run); scroll
//             down in 20 px notches (or finger drags) as far as it goes and keep going; wait W; back up in 20 px notches
//             and keep going. (Whichever end the oldest toast is at, it is reached, waited at, and scrolled back from.)
//             Input lands on a toast (the lowest / highest point on one in view): the list between toasts lets it through.
//   targeted: every toast held once at the start (as a pointer resting on them); read the warning to its end; scroll the
//             list through its whole range both ways and back to rest; release the middle older toast's timer; once it
//             has gone, wait POST ms (80 / 250) and make one more 20 px step. Also with the release while scrolled away
//             from rest (released at the far end, then one more step).
// Every animation frame is recorded; judged from 1.2 s after the warning first appears (its own entry is not R5-D1) to
// >= 2 s after the last input. FAIL: any frame with the warning missing or below 0.98 opacity, or its box below its room
// (the toast region's bottom edge) or over the docked start.
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, tag, out, mode = 'natural', filter = '', repsArg = '3'] = process.argv; mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const WARN = 'toast-kettle:save-failed';
const CFG = mode === 'natural' ? [[375, 667, 200], [844, 390, 200], [667, 375, 150], [667, 375, 200]] : [[375, 667, 200], [844, 390, 200], [667, 375, 150], [667, 375, 200], [568, 320, 100]];
const VARIANTS = mode === 'natural' ? [600, 1200, 1800].map((w) => ({ w })) : [{ post: 80, at: 'rest' }, { post: 250, at: 'rest' }, { post: 80, at: 'far' }];
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
let fails = 0, n = 0;
for (const [W, H, pct] of CFG) for (const theme of ['light', 'dark']) for (const flow of mode === 'natural' ? ['end1', 'end12lv'] : ['end12lv']) for (const how of ['wheel', 'touch']) for (const v of VARIANTS) for (let rep = 0; rep < +repsArg; rep++) {
  const label = `${W}x${H}@${pct} ${theme} ${flow} ${how} ${JSON.stringify(v)} #${rep}`;
  if (filter && !label.match(new RegExp(filter))) continue;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage();
  let line;
  try {
    const ready = () => p.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60_000 });
    await p.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`); await ready();
    await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
    await p.evaluate(() => document.fonts.ready);
    if (flow === 'end12lv') await p.evaluate(async () => { const { leavesForLevel, levelFromLeaves } = await import('/src/progress/levels.ts'); const L = levelFromLeaves(window.__kettle.progress.getState().leaves).level; window.__kettle.progress.setState({ leaves: leavesForLevel(L + 1) - 1 }); });
    await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } });
    await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await p.waitForFunction(() => location.hash === '#/focus'); await sleep(2500);
    if (flow === 'end12lv') await p.evaluate(() => window.__kettle.ff(12 * 60_000 + 5_000));
    await sleep(500);
    // Recorder (every frame) and toast add/remove log, from before the brew ends.
    await p.evaluate((WARN) => {
      const R = (window.__rec = { frames: [], ev: [], t0: performance.now(), stop: false });
      const t = () => Math.round(performance.now() - R.t0);
      new MutationObserver((ms) => { for (const m of ms) { for (const x of m.addedNodes) if (x.tagName === 'LI') R.ev.push([t(), '+', x.id]); for (const x of m.removedNodes) if (x.tagName === 'LI') R.ev.push([t(), '-', x.id]); } }).observe(document.body, { childList: true, subtree: true });
      const f = () => {
        if (R.stop) return;
        const w = document.getElementById(WARN);
        const scroller = w ? (() => { for (let e = w.parentElement; e; e = e.parentElement) if (/(auto|scroll)/.test(getComputedStyle(e).overflowY)) return e; return null; })() : document.querySelector('[aria-label="Notifications"] ol');
        const d = document.querySelector('[data-toast-above]')?.getBoundingClientRect();
        // The room: the toast region's own box (the list's scroll box may reach past it, for shadows above and one toast
        // gap below; the room is judged without that).
        const lr = document.querySelector('[aria-label="Notifications"]')?.parentElement?.getBoundingClientRect();
        let op = 0; for (let e = w, o = 1; e && e !== document.documentElement; e = e.parentElement) op = o *= +getComputedStyle(e).opacity;
        const r = w?.getBoundingClientRect();
        R.frames.push([t(), document.querySelectorAll('[aria-label="Notifications"] li').length, w ? +op.toFixed(2) : 0, r ? Math.round(r.top) : null, r ? Math.round(r.bottom) : null, d ? Math.round(d.top) : null, lr ? Math.round(lr.bottom) : null, scroller ? Math.round(scroller.scrollTop) : null]);
        requestAnimationFrame(f);
      };
      requestAnimationFrame(f);
    }, WARN);
    await p.evaluate(() => window.__kettle.timer.getState().end('user'));
    await p.waitForFunction(() => location.hash === '#/' || location.hash === '');
    await p.waitForSelector(`[id="${WARN}"]`, { timeout: 8000 });
    await sleep(500);
    const st = () => p.evaluate((WARN) => {
      const w = document.getElementById(WARN); const list = document.querySelector('[aria-label="Notifications"] ol');
      const r = w?.getBoundingClientRect(); const lr = list.getBoundingClientRect();
      const x = r ? (r.left + r.right) / 2 : (lr.left + lr.right) / 2;
      // Where a pointer or finger can rest on the stack: on a toast (the list between toasts lets input through to the
      // page), the lowest and the highest such point in view.
      const on = (y) => !!document.elementFromPoint(x, y)?.closest('[aria-label="Notifications"] li');
      let low = Math.min(lr.bottom, innerHeight) - 20; while (low > Math.max(0, lr.top) && !on(low)) low -= 4;
      let high = Math.max(0, lr.top) + 20; while (high < Math.min(lr.bottom, innerHeight) && !on(high)) high += 4;
      return { x, wtop: r ? Math.max(0, r.top) : Math.max(0, lr.top), wbottom: r ? r.bottom : lr.bottom, wst: w ? w.scrollTop : 0, wmax: w ? w.scrollHeight - w.clientHeight : 0, lst: list.scrollTop, lmax: list.scrollHeight - list.clientHeight, ltop: Math.max(0, lr.top), lbottom: lr.bottom, low, high, n: list.children.length };
    }, WARN);
    const cdp = how === 'touch' ? await ctx.newCDPSession(p) : null;
    const step = async (x, y, dy) => {
      x = Math.round(x); y = Math.round(y);
      if (!cdp) { await p.mouse.move(x, y); await p.mouse.wheel(0, dy); }
      else { const dir = dy > 0 ? -1 : 1; const k = Math.max(2, Math.round(Math.abs(dy) / 8)); await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] }); for (let i = 1; i <= k; i++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: y + dir * i * 8 }] }); await sleep(16); } await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); }
      await sleep(how === 'wheel' ? 150 : 120);
    };
    // Points to scroll at: over the warning (its own scroll first) or over the list near its top / bottom edge.
    const atWarn = (s) => [s.x, s.wtop + Math.max(14, 0.4 * (s.wbottom - s.wtop))];
    const nearTop = (s) => [s.x, s.high];
    const nearBottom = (s) => [s.x, s.low];
    const warnVisible = (s) => s.wbottom - s.wtop >= 24;
    const same = (a, b) => Math.abs(a.wst - b.wst) < 0.5 && Math.abs(a.lst - b.lst) < 0.5;
    let s = await st();
    if (mode === 'natural') {
      if (!cdp) await p.mouse.move(Math.round(s.x), Math.round(s.wtop + 30)); // pointer on the stack
      // Up as far as the stack goes (a bottom-up stack: its oldest toast); wait; down in 20 px notches as far as it goes
      // (back to rest, or on to the oldest toast of a top-down stack) and keep going; wait; back up the same way.
      for (let i = 0, still = 0; i < 25 && still < 2; i++) { const a = await st(); await step(...nearTop(a), -40); s = await st(); still = same(a, s) ? still + 1 : 0; }
      await sleep(v.w);
      for (let i = 0, still = 0; i < 60 && still < 4; i++) { const a = await st(); await step(...(a.wst < a.wmax - 1 && warnVisible(a) ? atWarn(a) : nearBottom(a)), 20); s = await st(); still = same(a, s) ? still + 1 : 0; }
      await sleep(v.w);
      for (let i = 0, still = 0; i < 60 && still < 4; i++) { const a = await st(); await step(...nearTop(a), -20); s = await st(); still = same(a, s) ? still + 1 : 0; }
    } else {
      await p.evaluate(() => document.querySelectorAll('[aria-label="Notifications"] li').forEach((li) => li.dispatchEvent(new PointerEvent('pointerenter'))));
      for (let i = 0; i < 40; i++) { s = await st(); if (s.wst >= s.wmax - 1) break; await step(...atWarn(s), 20); }
      for (let i = 0; i < 60; i++) { s = await st(); const before = s.lst; await step(...nearBottom(s), 20); s = await st(); if (s.lst === before) break; }
      for (let i = 0; i < 60; i++) { s = await st(); const before = s.lst; await step(...nearTop(s), -20); s = await st(); if (s.lst === before) break; }
      // back to rest: the list's offset at rest is 0 (top-down list: top; bottom-up list: bottom)
      // back to rest, approached from the scrolled side as a person does (it may settle 1 px past 0)
      for (let i = 0; i < 60; i++) { s = await st(); if (s.lst < 0 ? s.lst >= -1 : s.lst <= 1) break; await step(...(s.lst < 0 ? nearBottom(s) : nearTop(s)), s.lst < 0 ? 20 : -20); }
      if (v.at === 'far') { for (let i = 0; i < 60; i++) { s = await st(); const before = s.lst; await step(...nearBottom(s), 20); s = await st(); if (s.lst === before) break; } if (Math.abs(s.lst) <= 1) for (let i = 0; i < 60; i++) { s = await st(); const before = s.lst; await step(...nearTop(s), -20); s = await st(); if (s.lst === before) break; } }
      const older = await p.evaluate((WARN) => [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.id).filter((id) => id !== WARN), WARN);
      const victim = older[Math.min(1, older.length - 1)];
      await p.evaluate((id) => document.getElementById(id)?.dispatchEvent(new PointerEvent('pointerleave')), victim);
      await p.waitForFunction((id) => !document.getElementById(id), victim, { timeout: 8000 }).catch(() => {});
      await sleep(v.post);
      // One more step each way, as the person goes on scrolling.
      s = await st(); await step(...nearBottom(s), 20);
      s = await st(); await step(...nearTop(s), -20);
      s = await st(); await step(...nearBottom(s), 20);
    }
    const tLast = await p.evaluate(() => Math.round(performance.now() - window.__rec.t0));
    await sleep(2300);
    const R = await p.evaluate(() => { window.__rec.stop = true; return { frames: window.__rec.frames, ev: window.__rec.ev }; });
    const warnIn = R.ev.find((e) => e[2] === WARN && e[1] === '+')?.[0] ?? 0;
    // The warning's own end (its 12 s timer, untouched by a finger) is not a take-away: a removal not followed by the
    // warning coming back within 1 s ends the judged window where its exit began (its last frame at full opacity).
    // A removal followed by a re-show (M1's hold rule) is judged in full.
    let tEnd = Infinity;
    for (const e of R.ev) if (e[1] === '-' && e[2] === WARN && e[0] > warnIn && !R.ev.some((x) => x[1] === '+' && x[2] === WARN && x[0] > e[0] && x[0] - e[0] < 1000)) {
      // Its exit begins when it fades, or when the toast region drops back to its resting place (the list is empty, so
      // the lift is released, the moment it is dismissed): whichever comes first in the last 700 ms before removal.
      const win = R.frames.filter((f) => f[0] >= e[0] - 700 && f[0] < e[0]);
      const roomBefore = win.length ? win[0][6] : null;
      const first = win.find((f) => f[2] < 0.98 || f[6] !== roomBefore);
      tEnd = Math.min(tEnd, first ? first[0] - 1 : e[0]);
    }
    const judged = R.frames.filter((f) => f[0] >= warnIn + 1200 && f[0] <= tEnd);
    const gone = judged.filter((f) => f[2] < 0.98);
    const below = judged.filter((f) => f[4] != null && f[4] > Math.min(f[5] ?? 1e9, f[6] ?? 1e9) + 0.5);
    const entry = R.frames.filter((f) => f[0] >= warnIn && f[0] < warnIn + 1200 && f[4] != null && f[4] > Math.min(f[5] ?? 1e9, f[6] ?? 1e9) + 0.5).length;
    const removedOlder = R.ev.filter((e) => e[1] === '-' && e[2] !== WARN && e[0] > warnIn).length;
    const bad = [];
    if (gone.length) bad.push(`warning missing/faded in ${gone.length} frames`);
    if (below.length) bad.push(`box below the room / over the dock in ${below.length} frames (max +${Math.max(...below.map((f) => f[4] - Math.min(f[5] ?? 1e9, f[6] ?? 1e9)))} px)`);
    const ok = !bad.length && R.frames[R.frames.length - 1][0] - tLast >= 2000;
    n++; if (!ok) fails++;
    line = `${tag} ${label}: ${ok ? 'OK' : 'FAIL ' + bad.join('; ')} | judged ${judged.length} frames${tEnd < Infinity ? ` (to the warning's own timed end at ${tEnd} ms)` : ''}, ${R.frames[R.frames.length - 1][0] - tLast} ms after last input; older toasts left during the run: ${removedOlder}; list offsets ${Math.min(...judged.map((f) => f[7] ?? 0))}..${Math.max(...judged.map((f) => f[7] ?? 0))}; entry frames over the dock: ${entry} | toasts ${JSON.stringify(R.ev)}`;
    appendFileSync(`${out}/race6-${tag}.jsonl`, JSON.stringify({ label, bad, ev: R.ev, frames: R.frames }) + '\n');
  } catch (e) { n++; fails++; line = `${tag} ${label}: ERROR ${String(e.message).split('\n')[0]}`; }
  console.log(line);
  await ctx.close();
}
console.log(`failures: ${fails} of ${n}`);
await b.close();

import { chromium } from 'playwright';
const [,, base, W, H, runs='3'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (let i = 0; i < +runs; i++) {
  const ctx = await b.newContext({ viewport:{width:+W,height:+H}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
  await ctx.addInitScript(() => {
    window.__wrapLog = [];
    const mo = new MutationObserver((ms) => { for (const m of ms) if (m.attributeName === 'data-wrap') { const el = m.target; const r = el.getBoundingClientRect(); window.__wrapLog.push({ t: Math.round(performance.now()), wrap: el.hasAttribute('data-wrap'), barRight: Math.round(r.right), kids: [...el.children].map(c => Math.round(c.getBoundingClientRect().right)), cw: document.documentElement.clientWidth, fonts: document.fonts.status, tf: getComputedStyle(el.closest('main') || document.body).transform }); } });
    addEventListener('DOMContentLoaded', () => mo.observe(document.body, { subtree: true, attributes: true, attributeFilter: ['data-wrap'] }));
  });
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, { waitUntil: 'networkidle' });
  await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(2000);
  const st = await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); return { wrap: el.hasAttribute('data-wrap'), kids: [...el.children].map(c => [Math.round(c.getBoundingClientRect().left), Math.round(c.getBoundingClientRect().right), c.offsetWidth]), bar: [Math.round(el.getBoundingClientRect().left), Math.round(el.getBoundingClientRect().right)], cw: document.documentElement.clientWidth, iw: innerWidth, log: window.__wrapLog }; });
  console.log(W, H, 'run', i, JSON.stringify(st));
  await ctx.close();
}
await b.close();

// Mechanism check for R4-D2: during live resizes at large text, is the document ever wider than the screen, inside the
// status bar's own measurements or in any frame? node .tmp/w1fix/zoomwide.mjs <base> <tag> <pct> <theme> <seq> [reps]
import { chromium } from 'playwright';
const [,, base, tag, pct = '200', theme = 'light', seqName = 'drag2', reps = '5'] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SEQ = {
  bounce: async (p) => { for (const w of [414, 375, 390, 375, 400, 375, 384, 375, 414, 375]) await p.setViewportSize({ width: w, height: 667 }); },
  wiggle: async (p) => { for (let k = 0; k < 3; k++) { for (let w = 412; w >= 376; w -= 2) { await p.setViewportSize({ width: w, height: 667 }); await sleep(16); } for (let w = 376; w <= 412; w += 2) { await p.setViewportSize({ width: w, height: 667 }); await sleep(16); } } await p.setViewportSize({ width: 375, height: 667 }); },
  drag2: async (p) => { for (let w = 412; w >= 376; w -= 2) { await p.setViewportSize({ width: w, height: 667 }); await sleep(16); } await p.setViewportSize({ width: 375, height: 667 }); },
};
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
for (let r = 0; r < +reps; r++) {
  const ctx = await b.newContext({ viewport: { width: 414, height: 667 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), +pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.waitForFunction(() => !!window.__kettle); await p.evaluate(() => document.fonts.ready); await sleep(1200);
  await p.evaluate(() => {
    const W = (window.__w = { inMeasure: [], frames: [], n: 0 });
    const orig = Element.prototype.getBoundingClientRect;
    Element.prototype.getBoundingClientRect = function () { const res = orig.call(this); if (this.matches && this.matches('nav[aria-label="Your progress"]')) { W.n++; const d = document.documentElement; if (d.scrollWidth > d.clientWidth || innerWidth !== d.clientWidth) W.inMeasure.push([Math.round(performance.now()), d.scrollWidth, d.clientWidth, innerWidth]); } return res; };
    const tick = () => { const d = document.documentElement; if (d.scrollWidth > d.clientWidth || visualViewport.scale !== 1) W.frames.push([Math.round(performance.now()), d.scrollWidth, d.clientWidth, innerWidth, +visualViewport.scale.toFixed(3), [...document.querySelectorAll('body *')].filter((e) => e.getBoundingClientRect().right > d.clientWidth + 0.5).slice(0, 3).map((e) => `${e.tagName}.${String(e.className).split(' ')[0]}:${Math.round(e.getBoundingClientRect().right)}`)]); if (!W.stop) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  });
  await SEQ[seqName](p);
  await sleep(2000);
  const res = await p.evaluate(() => { window.__w.stop = true; return { measures: window.__w.n, widerInMeasure: window.__w.inMeasure.length, firstInMeasure: window.__w.inMeasure.slice(0, 3), framesWiderOrZoomed: window.__w.frames.length, frames: window.__w.frames.slice(0, 4), final: [+visualViewport.scale.toFixed(3), Math.round(visualViewport.width), innerWidth] }; });
  console.log(`${tag} t${pct} ${theme} ${seqName} #${r}: ${JSON.stringify(res)}`);
  await ctx.close();
}
await b.close();

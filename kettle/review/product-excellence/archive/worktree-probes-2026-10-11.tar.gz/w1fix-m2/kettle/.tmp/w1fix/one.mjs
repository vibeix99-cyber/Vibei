import { chromium } from 'playwright';
const [,, base, W, H, leaves] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:+W,height:+H}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
await p.evaluate((n) => window.__kettle.progress.setState({ leaves: n }), +leaves); await p.waitForTimeout(1200);
console.log(base, JSON.stringify(await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); const mode = el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal'; const kids=[...el.children].map(k=>{const r=k.getBoundingClientRect(); return [Math.round(r.left),Math.round(r.right),Math.round(r.top)];}); const lab=[...el.querySelectorAll('span')].find(s=>/^Level/.test(s.textContent)); const lr=lab.getBoundingClientRect(); delete el.dataset.wrap; el.dataset.tight=''; const tk=[...el.children].map(k=>Math.round(k.getBoundingClientRect().right)); const lr2 = lab.getBoundingClientRect(); return {mode, kids, label:[Math.round(lr.left), Math.round(lr.right), lab.scrollWidth], tightOneRowRights: tk, tightLabelRight: Math.round(lr2.right), cw: document.documentElement.clientWidth}; })));
await b.close();

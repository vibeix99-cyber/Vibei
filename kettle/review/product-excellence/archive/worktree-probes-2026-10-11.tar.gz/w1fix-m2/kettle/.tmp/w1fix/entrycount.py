# Count runs where the warning was taken away and re-shown within its first 1.5 s (its entry), from race6 *.jsonl records.
# python3 .tmp/w1fix/entrycount.py <jsonl>...
import json, sys, collections
W = 'toast-kettle:save-failed'
c = collections.Counter(); n = collections.Counter()
for f in sys.argv[1:]:
    for l in open(f):
        d = json.loads(l); ev = d['ev']; cfg = ' '.join(d['label'].split()[:2])
        adds = [e for e in ev if e[2] == W and e[1] == '+']
        t0 = adds[0][0] if adds else 0
        ent = any(e[1] == '-' and e[2] == W and e[0] - t0 < 1500 and any(x[1] == '+' and x[2] == W and 0 < x[0] - e[0] < 1000 for x in ev) for e in ev)
        n[cfg] += 1; c[cfg] += ent
for k in n: print(f'{k}: warning taken away and re-shown during its entry (first 1.5 s) in {c[k]} of {n[k]} runs')
print(f'total: {sum(c.values())} of {sum(n.values())}')

// CLS on a cold load of Today (production build), per viewport; layout shifts without recent input, first 6 s.
import { chromium } from 'playwright';
const [,, base, runs = '5'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h,mobile] of [[390,844,true],[375,667,true],[360,740,true],[1440,900,false]]) {
  const vals = []; let top = '';
  for (let i = 0; i < +runs; i++) {
    const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor: mobile?2:1, isMobile:mobile, hasTouch:mobile, serviceWorkers:'block' });
    await ctx.addInitScript(() => { window.__ls = []; new PerformanceObserver((l) => { for (const e of l.getEntries()) if (!e.hadRecentInput) window.__ls.push({ v: e.value, t: Math.round(e.startTime), src: (e.sources||[]).map(s => s.node && s.node.nodeType === 1 ? s.node.className.toString().slice(0,30) : '?').join('|') }); }).observe({ type: 'layout-shift', buffered: true }); });
    if (process.env.LEAVES) { // a returning profile with this many leaves saved (the seed's own total follows the date)
      const p0 = await ctx.newPage();
      await p0.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, { waitUntil: 'load' });
      await p0.waitForFunction(() => !!window.__kettle);
      // Leaves are re-derived from the ledger on load: add a ledger entry that brings the total to LEAVES.
      await p0.evaluate((n) => { const k = window.__kettle, s = k.progress.getState(), led = s.ledger, last = led[led.length - 1]; k.progress.setState({ ledger: [...led, { ...last, id: 'cls-probe-extra', amount: n - s.leaves }], leaves: n }); }, +process.env.LEAVES);
      await p0.waitForTimeout(800); await p0.close();
    }
    const p = await ctx.newPage();
    if (process.env.SLOWFONTS) await p.route('**/*.woff2', async (r) => { await new Promise((ok) => setTimeout(ok, 2500)); await r.continue(); });
    await p.goto(`${base}/?debug${process.env.LEAVES ? '' : '&seed=veteran'}&theme=light&nooktime=day#/`, { waitUntil: 'load' });
    await p.waitForTimeout(process.env.SLOWFONTS ? 8000 : 6000);
    const r = await p.evaluate(() => ({ sum: window.__ls.reduce((a, x) => a + x.v, 0), list: window.__ls, mode: (() => { const el = document.querySelector('nav[aria-label="Your progress"]'); return el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal'; })() }));
    vals.push(+r.sum.toFixed(4) + ':' + r.mode); if (r.list.length) top = JSON.stringify(r.list.slice(0, 3));
    await ctx.close();
  }
  console.log(`${w}x${h}`, 'CLS per run', vals.join(' '), top ? 'shifts ' + top : '');
}
await b.close();

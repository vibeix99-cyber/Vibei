// M2 r6: a copy of the Checker r5 readscroll.mjs (R4-D1 / D3 / R2-D3 retest with REAL input, per-frame recording),
// made independent of which end of the stack the older toasts are at (r5: above a warning held at the bottom; r6:
// below a warning that leads the stack). Recorder and judging unchanged. Changes, marked "r6:" below: input lands on
// a toast (the lowest / highest point on one in view: the list between toasts lets input through to the page); after
// reading the warning to its end the person goes on down as far as the stack goes (and waits there), then back up as
// far as it goes; "rest" is the list's offset before the first input.
// A person reads the storage-full warning to its end, goes on to every older toast and reads each one (scrolling
// inside it when it is taller than the room), waits there, then scrolls back to rest and taps "Save backup". Every
// frame is recorded from before the first input to >= 2.2 s after the last one.
// node readscroll.mjs <base> <label> <outdir> <WxH> <themes> <texts> <flows=alone,end1,end12lv> <hows=wheel20,wheel53,wheel100,touch,flick>
import { mkdirSync, appendFileSync } from 'node:fs';
import { launch, context, sleep } from './chk-r5/lib.mjs';

const [base, label, out, cfg, themeArg, textArg, flowArg, howArg] = process.argv.slice(2);
mkdirSync(out, { recursive: true });
const [W, H] = cfg.split('x').map(Number);
const WARN = 'toast-kettle:save-failed';

const fill = (page) =>
  page.evaluate(() => {
    let c = 'x'.repeat(1 << 20), i = 0;
    while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } }
    try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; }
  });

// In-page recorder: per frame, every toast's lines that are wholly visible and uncovered; warning presence/opacity;
// warning box vs room/dock; list and warning scroll offsets.
const RECORDER = (WARN) => {
  const R = (window.__rec = { frames: [], seen: {}, total: {}, whole: {}, stop: false, t0: performance.now(), ev: [] });
  new MutationObserver((ms) => { for (const m of ms) { for (const n of m.addedNodes) if (n.tagName === 'LI') R.ev.push([Math.round(performance.now() - R.t0), '+', n.id]); for (const n of m.removedNodes) if (n.tagName === 'LI') R.ev.push([Math.round(performance.now() - R.t0), '-', n.id]); } }).observe(document.body, { childList: true, subtree: true });
  const z = (li) => +getComputedStyle(li).zIndex || 0;
  const inter = (a, b) => a.bottom > b.top + 0.5 && a.top < b.bottom - 0.5 && a.right > b.left + 0.5 && a.left < b.right - 0.5;
  const tick = () => {
    if (R.stop) return;
    const list = document.querySelector('[aria-label="Notifications"] ol');
    const lis = list ? [...list.querySelectorAll(':scope > li')] : [];
    const dock = [...document.querySelectorAll('[data-toast-above]')].map((d) => d.getBoundingClientRect()).filter((r) => r.height > 0 && r.top < innerHeight);
    const dockTop = dock.length ? Math.min(...dock.map((r) => r.top)) : innerHeight;
    const lr = list?.getBoundingClientRect();
    // the list's scrollport (padding box) on screen, and never below the docked start
    const visTop = Math.max(0, lr ? lr.top + list.clientTop : 0);
    const visBottom = Math.min(innerHeight, lr ? lr.top + list.clientTop + list.clientHeight : innerHeight, dockTop);
    const w = document.getElementById(WARN);
    let op = 0;
    for (let e = w, o = 1; e && e !== document.documentElement; e = e.parentElement) op = o *= +getComputedStyle(e).opacity;
    const wr = w?.getBoundingClientRect();
    const rects = lis.map((li) => li.getBoundingClientRect());
    const zs = lis.map(z);
    lis.forEach((li, i) => {
      const id = li.id || `li${i}`;
      const r = rects[i];
      let eop = 1;
      for (let e = li; e && e !== document.documentElement; e = e.parentElement) eop *= +getComputedStyle(e).opacity;
      if (eop < 0.98) return;
      // painted above this toast: higher z, or same z and later in the DOM
      const above = rects.filter((_, j) => j !== i && (zs[j] > zs[i] || (zs[j] === zs[i] && j > i)));
      if (r.top >= visTop - 0.5 && r.bottom <= visBottom + 0.5 && !above.some((a) => inter(a, r))) R.whole[id] = true;
      const msg = li.querySelector('span[class*="message"]');
      if (!msg) return;
      const act = li.querySelector('button')?.getBoundingClientRect();
      const rg = document.createRange();
      rg.selectNodeContents(msg);
      const mt = msg.getBoundingClientRect().top + (li.scrollTop || 0) * 0; // line index from the message's own top
      const qs = [...rg.getClientRects()];
      const lh = qs.length ? Math.max(...qs.map((q) => q.height)) : 1;
      const idx = (q) => Math.round((q.top - msg.getBoundingClientRect().top) / lh);
      R.total[id] = Math.max(R.total[id] ?? 0, new Set(qs.map(idx)).size);
      for (const q of qs) {
        const k = idx(q);
        // vertically inside: screen, the list's scrollport, the toast's own box (it clips its scrolling message)
        const inV = q.top >= Math.max(visTop, r.top) - 0.5 && q.bottom <= Math.min(visBottom, r.bottom) + 0.5;
        const inH = q.left >= Math.max(0, r.left) - 0.5 && q.right <= Math.min(innerWidth, r.right) + 0.5;
        if (!inV || !inH) continue;
        if (act && inter(q, act)) continue;
        if (above.some((a) => inter(a, q))) continue;
        // and really drawn there (elementFromPoint at three points along the line's middle)
        const y = (q.top + q.bottom) / 2;
        const pts = [q.left + 2, (q.left + q.right) / 2, q.right - 2];
        if (!pts.every((x) => { const hit = document.elementFromPoint(x, y); return hit && li.contains(hit); })) continue;
        (R.seen[id] ??= {})[k] = 1;
      }
    });
    const act = w?.querySelector('button')?.getBoundingClientRect();
    R.frames.push([
      Math.round(performance.now() - R.t0),
      w ? +op.toFixed(3) : 0,
      wr ? +(wr.bottom - dockTop).toFixed(1) : null,
      wr ? +(wr.bottom - visBottom).toFixed(1) : null,
      list ? Math.round(list.scrollTop) : null,
      w ? Math.round(w.scrollTop) : null,
      wr ? Math.round(wr.top) : null,
      act ? +(act.bottom - Math.min(innerHeight, dockTop)).toFixed(1) : null,
      lis.length,
      // r6: the warning's box against the toast region's own bottom edge (the room proper; the list's scroll box reaches
      // one toast gap below it)
      wr && list ? +(wr.bottom - list.parentElement.parentElement.getBoundingClientRect().bottom).toFixed(1) : null,
    ]);
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
};

const browser = await launch();
let fails = 0, runs = 0;
for (const theme of themeArg.split(','))
  for (const text of textArg.split(',').map(Number))
    for (const flow of flowArg.split(','))
      for (const how of howArg.split(',')) {
        const tag = `${label} ${W}x${H} ${theme} t${text} ${flow} ${how}`;
        const desktop = W >= 900;
        const ctx = await context(browser, { w: W, h: H, theme, text });
        await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
        const page = await ctx.newPage();
        const errors = [];
        page.on('pageerror', (e) => errors.push(e.message));
        const bad = [];
        let info = {};
        try {
          const ready = () => page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60_000 });
          await page.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`);
          await ready();
          await page.evaluate(() => window.__kettle.seed('newbie'));
          await page.reload();
          await ready();
          await page.evaluate(() => document.fonts.ready);
          if (flow === 'end12lv') {
            await page.evaluate(async () => {
              const { leavesForLevel, levelFromLeaves } = await import('/src/progress/levels.ts');
              const L = levelFromLeaves(window.__kettle.progress.getState().leaves).level;
              window.__kettle.progress.setState({ leaves: leavesForLevel(L + 1) - 1 });
            });
          }
          const q = await fill(page);
          if (q !== 'QuotaExceededError') bad.push(`quota ${q}`);
          if (flow === 'alone') {
            await page.evaluate(() => {
              const k = window.__kettle, led = k.progress.getState().ledger;
              k.progress.setState({ ledger: [...led, { ...led[led.length - 1], id: 'probe-'.padEnd(400, 'x'), amount: 0 }] });
              k.progress.setState({ ledger: led });
            });
          } else {
            await page.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
            await page.waitForFunction(() => location.hash === '#/focus');
            await sleep(2500);
            if (flow === 'end12lv') await page.evaluate(() => window.__kettle.ff(12 * 60_000 + 5_000));
            await sleep(500);
            await page.evaluate(() => window.__kettle.timer.getState().end('user'));
            await page.waitForFunction(() => location.hash === '#/' || location.hash === '');
          }
          await page.waitForSelector(`[id="${WARN}"]`, { timeout: 8000 });
          await sleep(1600);
          // Hold every toast's own timer, as a finger or pointer resting on the stack does (older toasts last 3.2 s).
          const hold = () => page.evaluate(() => document.querySelectorAll('[aria-label="Notifications"] li').forEach((li) => li.dispatchEvent(new PointerEvent('pointerenter'))));
          await hold();
          info.before = await page.evaluate((WARN) => {
            const l = document.querySelector('[aria-label="Notifications"] ol');
            const w = document.getElementById(WARN);
            const r = w.getBoundingClientRect();
            const rg = l.getBoundingClientRect();
            const d = document.querySelector('[data-toast-above]')?.getBoundingClientRect();
            return { toasts: [...l.children].map((li) => [li.id, Math.round(li.getBoundingClientRect().top), Math.round(li.getBoundingClientRect().bottom), li.scrollHeight - li.clientHeight]), list: [Math.round(rg.top), Math.round(rg.bottom), l.scrollTop, l.scrollHeight - l.clientHeight], warn: [Math.round(r.top), Math.round(r.bottom), w.scrollTop, w.scrollHeight - w.clientHeight], dock: d && Math.round(d.top) };
          }, WARN);
          await page.evaluate(RECORDER, WARN);
          await sleep(300);
          const cdp = how === 'touch' || how === 'flick' ? await ctx.newCDPSession(page) : null;
          const step = how.startsWith('wheel') ? +how.slice(5) : how === 'flick' ? 120 : 24;
          const state = () =>
            page.evaluate((WARN) => {
              const l = document.querySelector('[aria-label="Notifications"] ol');
              const w = document.getElementById(WARN);
              const lis = [...l.querySelectorAll(':scope > li')];
              const lr = l.getBoundingClientRect();
              const r = w?.getBoundingClientRect();
              // r6: the lowest and highest points on a toast in view (x at the stack's middle)
              const x = r ? (r.left + r.right) / 2 : (lr.left + lr.right) / 2;
              const on = (y) => !!document.elementFromPoint(x, y)?.closest('[aria-label="Notifications"] li');
              const vb = Math.min(lr.bottom, innerHeight), vt = Math.max(0, lr.top);
              let low = vb - Math.min(20, (vb - vt) / 3); while (low > vt && !on(low)) low -= 3;
              let high = vt + Math.min(20, (vb - vt) / 3); while (high < vb && !on(high)) high += 3;
              return {
                x, low, high,
                all: lis.filter((li) => li !== w).map((li) => { const q = li.getBoundingClientRect(); return { id: li.id, top: q.top, bottom: q.bottom, st: li.scrollTop, max: li.scrollHeight - li.clientHeight }; }),
                w: w ? { x: (r.left + r.right) / 2, top: Math.max(0, r.top), bottom: r.bottom, st: w.scrollTop, max: w.scrollHeight - w.clientHeight } : null,
                l: { top: Math.max(0, lr.top), bottom: lr.bottom, st: l.scrollTop, min: -(l.scrollHeight - l.clientHeight) },
                older: lis.slice(0, w ? lis.indexOf(w) : 0).map((li) => { const q = li.getBoundingClientRect(); return { id: li.id, top: q.top, bottom: q.bottom, st: li.scrollTop, max: li.scrollHeight - li.clientHeight }; }),
              };
            }, WARN);
          const input = async (x, y, dy) => {
            x = Math.round(x); y = Math.round(Math.min(Math.max(y, 6), H - 6));
            if (!cdp) { await page.mouse.move(x, y); await page.mouse.wheel(0, dy); await sleep(how === 'wheel100' ? 180 : 120); return; }
            const dir = dy > 0 ? -1 : 1; // finger moves opposite to the content offset change
            const n = how === 'flick' ? 4 : Math.max(1, Math.round(Math.abs(dy) / 8));
            const px = Math.abs(dy) / n;
            await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
            for (let i = 1; i <= n; i++) {
              await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: Math.round(y + dir * i * px) }] });
              await sleep(how === 'flick' ? 8 : 16);
            }
            await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
            await hold();
            await sleep(how === 'flick' ? 700 : 150);
          };
          let s = await state();
          const restAt = s.l.st; // r6: where the list rests
          const same = (a, b) => Math.abs((a.w?.st ?? 0) - (b.w?.st ?? 0)) < 0.5 && Math.abs(a.l.st - b.l.st) < 0.5 && a.all.every((t, i) => Math.abs(t.st - (b.all[i]?.st ?? t.st)) < 0.5);
          // A. read the warning to its end (scroll inside it)
          for (let i = 0; i < 120 && s.w && s.w.st < s.w.max - 1; i++) {
            await input(s.w.x, s.w.top + Math.max(14, 0.4 * (s.w.bottom - s.w.top)), step);
            s = await state();
          }
          info.readEnd = s.w && [Math.round(s.w.st), s.w.max];
          // r6: B0. go on down as far as the stack goes (older toasts below a warning that leads the stack; each read
          // inside its box on the way, as input over it scrolls it first), and wait there.
          for (let i = 0, still = 0; i < 80 && still < 2; i++) {
            const a = await state();
            if (!a.w) { await sleep(100); continue; }
            await input(a.x, a.low, step);
            s = await state();
            still = same(a, s) ? still + 1 : 0;
          }
          info.bottom = [Math.round(s.l.st), Math.round(s.l.st - s.l.min)];
          const tBottom = await page.evaluate(() => performance.now() - window.__rec.t0);
          await sleep(2300);
          // B. scroll back up as far as the stack goes: the warning's opening, and (scroll handed to the list) any older
          // toasts above it (r6: input at the highest point on a toast; stops when nothing moves twice).
          for (let i = 0, still = 0; i < 80 && still < 2; i++) {
            const a = await state();
            if (!a.w) { await sleep(100); continue; }
            await input(a.x, a.high, -step);
            s = await state();
            still = same(a, s) ? still + 1 : 0;
          }
          info.top = s.l && [Math.round(s.l.st), Math.round(s.l.min)];
          // C. read each older toast taller than its box (scroll inside it), then up again
          for (const o of (await state()).all) {
            if (o.max <= 1) continue;
            for (let i = 0; i < 30; i++) {
              const t = (await state()).all.find((x) => x.id === o.id);
              if (!t || t.st >= t.max - 1 || t.bottom <= 0 || t.top >= s.l.bottom) break; // r6: only one in view
              await input(s.w ? s.w.x : W / 2, Math.max(t.top, 0) + Math.max(10, 0.4 * (Math.min(t.bottom, H) - Math.max(t.top, 0))), step);
            }
          }
          // D. stay at the top a while (list must stay; warning must stay)
          await page.screenshot({ path: `${out}/rs6-${label}-${W}x${H}-${theme}-t${text}-${flow}-${how}-top.png` });
          const tTop = await page.evaluate(() => performance.now() - window.__rec.t0);
          await sleep(2300);
          // E. scroll back to rest (r6: wherever it is), approaching it as a person does
          for (let i = 0, still = 0; i < 80 && still < 2; i++) {
            const a = await state();
            if (Math.abs(a.l.st - restAt) <= 1) break;
            await input(a.x, a.l.st < restAt ? a.low : a.high, a.l.st < restAt ? step : -step);
            s = await state();
            still = same(a, s) ? still + 1 : 0;
          }
          const tLast = await page.evaluate(() => performance.now() - window.__rec.t0);
          await sleep(2300);
          const rec = await page.evaluate(() => { window.__rec.stop = true; const R = window.__rec; return { frames: R.frames, seen: R.seen, total: R.total, whole: R.whole, ev: R.ev }; });
          info.frames = rec.frames.length;
          info.ev = rec.ev;
          const ids = Object.keys(rec.total);
          const gone = rec.frames.filter((f) => f[1] < 0.98);
          const overDock = rec.frames.filter((f) => f[2] != null && f[2] > 0.5);
          const belowRoom = rec.frames.filter((f) => (f[3] != null && f[3] > 0.5) || (f[9] != null && f[9] > 0.5));
          const afterLast = rec.frames.filter((f) => f[0] >= tLast + 50);
          const atTop = rec.frames.filter((f) => f[0] >= tTop + 50 && f[0] <= tTop + 2250);
          const atBottom = rec.frames.filter((f) => f[0] >= tBottom + 50 && f[0] <= tBottom + 2250);
          const span = (fs, k) => (fs.length ? Math.max(...fs.map((f) => f[k])) - Math.min(...fs.map((f) => f[k])) : 0);
          if (gone.length) bad.push(`warning gone/faded in ${gone.length}/${rec.frames.length} frames (first t=${gone[0][0]})`);
          if (overDock.length) bad.push(`warning over the dock in ${overDock.length} frames (max ${Math.max(...overDock.map((f) => f[2]))})`);
          if (belowRoom.length) bad.push(`warning below the room in ${belowRoom.length} frames`);
          if (span(afterLast, 4) > 1 || span(afterLast, 5) > 1) bad.push(`list/warning moved after the last input (${span(afterLast, 4)}/${span(afterLast, 5)})`);
          // r6: a resting list's offset may change only in the frame a toast leaves the DOM (real timers: an older toast
          // the pointer is not on times out; at the list's far end the toasts above the one under the pointer slide
          // down by its height). Any other change fails, as before.
          const unexplained = (fs) => fs.filter((f, i) => i > 0 && Math.abs(f[4] - fs[i - 1][4]) > 0.5 && f[8] === fs[i - 1][8]).length;
          const explained = (fs) => fs.filter((f, i) => i > 0 && Math.abs(f[4] - fs[i - 1][4]) > 0.5 && f[8] !== fs[i - 1][8]).map((f) => f[0]);
          if (unexplained(atTop)) bad.push(`list moved while resting at the top (${span(atTop, 4)})`);
          if (unexplained(atBottom)) bad.push(`list moved while resting at the far end below (${span(atBottom, 4)})`);
          const ex = [...explained(atTop), ...explained(atBottom)];
          if (ex.length) info.restMovedByToastLeaving = ex;
          if (afterLast.length && afterLast.at(-1)[0] - afterLast[0][0] < 2000) bad.push('recorded < 2 s after the last input');
          for (const id of ids) {
            const seen = Object.keys(rec.seen[id] ?? {}).length;
            if (seen < rec.total[id]) bad.push(`${id === WARN ? 'warning' : id}: ${seen}/${rec.total[id]} lines read`);
            if (id !== WARN && !rec.whole[id]) info.notWhole = [...(info.notWhole ?? []), id];
          }
          if (info.notWhole?.length) bad.push(`never wholly on screen: ${info.notWhole.join(',')}`);
          if (gone.length || overDock.length) { info.dump = rec.frames.filter((f) => f[0] >= (gone[0] ?? overDock[0])[0] - 600 && f[0] <= (gone[0] ?? overDock[0])[0] + 900); info.phases = { tTop, tLast }; }
          info.lines = Object.fromEntries(ids.map((id) => [id, `${Object.keys(rec.seen[id] ?? {}).length}/${rec.total[id]}`]));
          info.restScroll = afterLast.length ? afterLast.at(-1)[4] : null;
          if (info.restScroll != null && Math.abs(info.restScroll - restAt) > 1) bad.push(`not back at rest (${info.restScroll} vs ${restAt})`);
          // F. at rest: Save backup visible, hit-tests as itself, real tap/click downloads; docked start hit-tests as itself
          const rest = await page.evaluate((WARN) => {
            const w = document.getElementById(WARN);
            const b = w?.querySelector('button');
            if (!b) return { missing: true };
            const r = b.getBoundingClientRect();
            const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
            const d = [...document.querySelectorAll('[data-toast-above] button')].find((x) => /Put the kettle on/.test(x.textContent));
            const dr = d?.getBoundingClientRect();
            const dh = dr && document.elementFromPoint(dr.left + dr.width / 2, dr.top + dr.height / 2);
            return { btn: [Math.round(r.top), Math.round(r.bottom)], inView: r.top >= 0 && r.bottom <= innerHeight, hit: !!hit && b.contains(hit), by: hit && !b.contains(hit) ? `${hit.tagName}.${String(hit.className).slice(0, 30)}` : '', dock: dr && [Math.round(dr.top), Math.round(dr.bottom)], dockHit: !!dh && d.contains(dh) };
          }, WARN);
          info.rest = rest;
          if (rest.missing) bad.push('no Save backup at rest');
          else {
            if (!rest.inView || !rest.hit) bad.push(`Save backup at rest: inView ${rest.inView} hit ${rest.hit} ${rest.by}`);
            if (rest.dock && !rest.dockHit) bad.push('docked start covered at rest');
            await page.screenshot({ path: `${out}/rs6-${label}-${W}x${H}-${theme}-t${text}-${flow}-${how}-rest.png` });
            const btn = page.locator(`[id="${WARN}"] button`);
            const dl = page.waitForEvent('download', { timeout: 10_000 }).catch(() => null);
            if (desktop || how.startsWith('wheel')) await btn.click({ timeout: 8000 }); else await btn.tap({ timeout: 8000 });
            const d = await dl;
            info.download = d ? d.suggestedFilename() : null;
            if (!d) bad.push('Save backup did not download');
          }
          if (errors.length) bad.push(`page errors ${errors.length}`);
        } catch (e) {
          bad.push('ERROR ' + String(e.message).split('\n')[0]);
        }
        runs++;
        if (bad.length) fails++;
        appendFileSync(`${out}/rs6-${label}.jsonl`, JSON.stringify({ tag, W, H, theme, text, flow, how, bad, info, errors }) + '\n');
        console.log(`${tag}: ${bad.length ? 'FAIL ' + bad.join('; ') : 'OK'} | before ${JSON.stringify(info.before?.warn)} list ${JSON.stringify(info.before?.list)} dock ${info.before?.dock} | readEnd ${JSON.stringify(info.readEnd)} bottom ${JSON.stringify(info.bottom)} top ${JSON.stringify(info.top)} lines ${JSON.stringify(info.lines)} frames ${info.frames} rest ${JSON.stringify(info.rest)} dl ${info.download}${info.restMovedByToastLeaving ? ` | note: resting list offset changed as a toast left (t=${info.restMovedByToastLeaving})` : ''} | ev ${JSON.stringify(info.ev)}`);
        await ctx.close();
      }
await browser.close();
console.log(`${label} ${cfg}: ${fails} failures in ${runs} runs`);

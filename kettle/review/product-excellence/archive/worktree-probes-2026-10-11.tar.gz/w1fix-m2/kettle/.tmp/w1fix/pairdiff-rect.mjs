// Pixel diff limited to the toasts' own rectangles (from a toaststack log), for the 100 % "three" stacks.
// node pairdiff-rect.mjs <stackDir> <after.txt>
import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const [,, dir, log] = process.argv;
const rects = {};
for (const line of readFileSync(log, 'utf8').split('\n')) { const m = line.match(/^\S+ (light|dark) (\d+x\d+) 100% three: \w+ (\{.*\})$/); if (m) rects[`${m[2]}-t100-${m[1]}`] = JSON.parse(m[3]).rects; }
const b = await chromium.launch(); const p = await b.newPage();
for (const [k, rs] of Object.entries(rects)) {
  const dpr = k.startsWith('1440') ? 1 : 2;
  const r = await p.evaluate(async ([x, y, rs, dpr]) => {
    const load = async (s) => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + s)).blob()); const c = new OffscreenCanvas(bm.width, bm.height); const g = c.getContext('2d'); g.drawImage(bm, 0, 0); return { w: bm.width, h: bm.height, d: g.getImageData(0, 0, bm.width, bm.height).data }; };
    const a = await load(x), c = await load(y); let n = 0, tot = 0;
    for (const [l, t, rr, bb] of rs) for (let yy = Math.max(0, t * dpr); yy < Math.min(a.h, bb * dpr); yy++) for (let xx = l * dpr; xx < rr * dpr; xx++) { const i = (yy * a.w + xx) * 4; tot++; if (Math.abs(a.d[i] - c.d[i]) + Math.abs(a.d[i + 1] - c.d[i + 1]) + Math.abs(a.d[i + 2] - c.d[i + 2]) > 48) n++; }
    return `${n} of ${tot} toast pixels differ (${(100 * n / Math.max(1, tot)).toFixed(2)} %)`;
  }, [readFileSync(`${dir}/stack-three-${k}-before.png`).toString('base64'), readFileSync(`${dir}/stack-three-${k}-after.png`).toString('base64'), rs, dpr]);
  console.log(`stack-three-${k} inside the toasts: ${r}`);
}
await b.close();

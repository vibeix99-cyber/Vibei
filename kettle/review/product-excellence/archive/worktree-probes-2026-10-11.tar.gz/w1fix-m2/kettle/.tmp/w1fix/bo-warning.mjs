// D4 / M1 interaction: with storage really full, the storage-full warning stays held on break-over (M1's ritual
// rule) and shows once the person leaves it for Today. node .tmp/w1fix/bo-warning.mjs <base> <tag> <outDir>
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, out] = process.argv; mkdirSync(out, { recursive: true });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
let fails = 0;
const W = '#toast-kettle\\:save-failed';
for (const theme of ['light', 'dark']) for (const [w, h, mobile] of [[375, 667, true], [390, 844, true], [1440, 900, false]]) {
  if (process.env.ONLY && !`${theme} ${w}x${h}`.match(new RegExp(process.env.ONLY))) continue;
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: mobile ? 2 : 1, isMobile: mobile, hasTouch: mobile, colorScheme: theme, acceptDownloads: true });
  const p = await ctx.newPage(); const errors = []; p.on('pageerror', (e) => errors.push(e.message));
  await p.goto(`${base}/?debug&seed=newbie&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.waitForFunction(() => !!window.__kettle); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1000);
  await p.evaluate(() => window.__kettle.settings.getState().set({ autoStartBreaks: false, autoStartFocus: false, muted: true }));
  const quota = await p.evaluate(() => { let c = 'x'.repeat(1024 * 1024), i = 0; while (c.length >= 8) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(4096)); return 'no error'; } catch (e) { return e.name; } });
  await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
  await p.waitForTimeout(2000);
  const duringBrew = await p.evaluate((W) => !!document.querySelector(W), W);
  await p.evaluate(() => window.__kettle.nearEnd()); await p.waitForTimeout(400);
  await p.evaluate(() => window.__kettle.finish());
  await p.getByRole('button', { name: /Tea time|Long tea break/ }).waitFor({ state: 'visible', timeout: 60_000 });
  await p.waitForTimeout(1200);
  await p.evaluate(() => [...document.querySelectorAll('button')].find((x) => /Tea time|Long tea break/.test(x.textContent)).click());
  await p.waitForTimeout(1500);
  await p.evaluate(() => window.__kettle.finish());
  await p.getByRole('button', { name: /Mark it done, start fresh/ }).waitFor({ state: 'visible', timeout: 30_000 });
  // On break-over: sample every 100 ms for 4 s.
  const frames = await p.evaluate(async (W) => { let shown = 0, n = 0; const t0 = performance.now(); while (performance.now() - t0 < 4000) { n++; if (document.querySelector(W)) shown++; await new Promise((r) => setTimeout(r, 100)); } return { n, shown, others: [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.textContent.slice(0, 40)) }; }, W);
  await p.screenshot({ path: `${out}/bo-warning-breakover-${w}x${h}-${theme}-${tag}.png` });
  await p.evaluate(() => [...document.querySelectorAll('button')].find((x) => /That’s all for now/.test(x.textContent)).click());
  await p.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 15_000 });
  // On Today, sample every 100 ms for 7 s: the warning's presence, and what the start button's centre hit-tests as.
  const tr = await p.evaluate(async (W) => {
    const out = []; const t0 = performance.now();
    while (performance.now() - t0 < 7000) {
      const el = document.querySelector(W);
      const b = [...document.querySelectorAll('[data-toast-above] button')].find((x) => /Put the kettle on/.test(x.textContent));
      let hit = 'no start';
      if (b) { const r = b.getBoundingClientRect(); const e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); hit = b.contains(e) ? 'ok' : e?.closest('[aria-label="Notifications"]') ? 'TOAST' : `${e?.tagName}.${String(e?.className).split(' ')[0]}`; }
      out.push([Math.round(performance.now() - t0), el ? `${Math.round(el.getBoundingClientRect().top)}-${Math.round(el.getBoundingClientRect().bottom)}/${getComputedStyle(el).opacity.slice(0, 4)}` : '-', hit]);
      await new Promise((res) => setTimeout(res, 100));
    }
    return out;
  }, W);
  if (process.env.TRACE) console.log('TRACE', tr.map((x) => x.join(':')).join(' '));
  const shownOnToday = tr.some((x) => x[1] !== '-');
  const startUnderToast = tr.filter((x) => x[2] === 'TOAST').length;
  const last = tr[tr.length - 1];
  const todayHit = last[2] === 'ok' && last[1] !== '-';
  const otherMisses = [...new Set(tr.filter((x) => x[2] !== 'ok' && x[2] !== 'TOAST').map((x) => `${x[0]}ms:${x[2]}`))].slice(0, 4);
  await p.screenshot({ path: `${out}/bo-warning-today-${w}x${h}-${theme}-${tag}.png` });
  const ok = quota === 'QuotaExceededError' && frames.shown === 0 && shownOnToday && startUnderToast === 0 && todayHit;
  if (!ok) fails++;
  console.log(`${tag} ${theme} ${w}x${h}: ${ok ? 'OK' : 'FAIL'} ${JSON.stringify({ quota, warningDuringBrew: duringBrew, breakOverFramesWithWarning: `${frames.shown}/${frames.n}`, otherToastsOnBreakOver: frames.others, warningShownOnToday: shownOnToday, todaySamplesWithStartUnderAToast: `${startUnderToast}/${tr.length}`, startHitsWithWarningUpAt7s: todayHit, todayOtherMisses: otherMisses, errors })}`);
  await ctx.close();
}
console.log(`failures: ${fails}`);
await b.close();

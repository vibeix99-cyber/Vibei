# Compare toast rects at 100 % between two toaststack logs. python3 geomcmp.py <before.txt> <after.txt>
import json, re, sys
def load(p):
    d = {}
    for line in open(p):
        m = re.match(r'^\S+ (light|dark) (\d+x\d+) (\d+)% (\w+): (OK|FAIL) (\{.*\})$', line.strip())
        if m: d[(m[1], m[2], m[3], m[4])] = json.loads(m[6])['rects']
    return d
a, b = load(sys.argv[1]), load(sys.argv[2])
same = diff = 0
for k in sorted(a):
    if k[2] != '100' or k not in b: continue
    if a[k] == b[k]: same += 1
    else:
        diff += 1; print('differs', k, a[k], '->', b[k])
print(f'100 %: {same} identical, {diff} differ, of {same + diff}')

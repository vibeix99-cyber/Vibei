// Re-judge the Checker's race.mjs / natural.mjs records (their *.jsonl, unedited) against the toast REGION's bottom
// edge rather than the list's box: in r6 a warning-led list's scroll box reaches 8 px below the region (into the 10 px
// the lift keeps above the docked start), so "below the list" is 8 px more lenient than "below the room". With the lift,
// the region's bottom is the docked start's top − 10 px (rounded), so: FAIL when the warning's bottom > dockTop − 10 + 1.
// node .tmp/w1fix/strictjudge.mjs <file.jsonl>...
import { readFileSync } from 'node:fs';
const WARN = 'toast-kettle:save-failed';
let n = 0, bad = 0, maxOver = -Infinity;
for (const file of process.argv.slice(2)) for (const line of readFileSync(file, 'utf8').split('\n').filter(Boolean)) {
  const d = JSON.parse(line);
  const warnIn = d.ev.find((e) => e[2] === WARN && e[1] === '+')?.[0] ?? 0;
  const from = d.tRel ?? warnIn + 1200; // race.mjs: from the release; natural.mjs: as the Checker judged it
  const fs = d.frames.filter((f) => f[0] >= from && f[4] != null && f[5] != null);
  const over = fs.map((f) => f[4] - (f[5] - 10));
  const m = over.length ? Math.max(...over) : null;
  if (m != null) maxOver = Math.max(maxOver, m);
  const fail = over.filter((x) => x > 1).length;
  n++; if (fail) bad++;
  if (fail || process.env.V) console.log(`${d.tag ?? d.label}: ${fail ? `FAIL ${fail} frames below the region (max +${m})` : 'OK'} (max warning bottom − region bottom: ${m})`);
}
console.log(`${process.argv.slice(2).join(' ')}: ${bad} of ${n} runs with the warning below the region; max warning bottom − region bottom over all judged frames: ${maxOver} px`);

// R4-D1 retest with REAL input: read the whole storage-full warning, and reveal every older toast, by mouse wheel or
// touch drag, while M1's 250 ms hold watcher runs; per-frame recording throughout and for 2 s after the last input.
// node .tmp/w1fix/realscroll.mjs <base> <tag> <outDir> [filter]   (filter matches "<WxH>@<pct> <theme> <flow> <how>")
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, out, filter = ''] = process.argv; mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const CASES = [];
for (const [w, h, pct] of [[375, 667, 200], [667, 375, 150], [667, 375, 200], [844, 390, 150], [844, 390, 200]]) for (const flow of ['alone', 'end1', 'end12lv']) for (const how of ['wheel', 'touch']) CASES.push([w, h, pct, flow, how]);
for (const how of ['wheel', 'touch']) CASES.push([568, 320, 100, 'end12lv', how]);
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
let fails = 0, n = 0;
for (const theme of ['light', 'dark']) for (const [w, h, pct, flow, how] of CASES) {
  const label = `${w}x${h}@${pct} ${theme} ${flow} ${how}`;
  if (filter && !label.match(new RegExp(filter))) continue;
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme, acceptDownloads: true });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage(); const errors = []; p.on('pageerror', (e) => errors.push(e.message));
  let res;
  try {
    const ready = () => p.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60_000 });
    await p.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`); await ready();
    await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
    await p.evaluate(() => document.fonts.ready);
    await p.evaluate(() => window.__kettle.timer.setState({}));
    if (flow === 'end12lv') await p.evaluate(async () => { const { leavesForLevel, levelFromLeaves } = await import('/src/progress/levels.ts'); const L = levelFromLeaves(window.__kettle.progress.getState().leaves).level; window.__kettle.progress.setState({ leaves: leavesForLevel(L + 1) - 1 }); });
    const quota = await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; } });
    if (flow === 'alone') {
      await p.evaluate(() => { const k = window.__kettle, led = k.progress.getState().ledger; k.progress.setState({ ledger: [...led, { ...led[led.length - 1], id: 'probe-'.padEnd(400, 'x'), amount: 0 }] }); k.progress.setState({ ledger: led }); });
    } else {
      await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
      await p.waitForFunction(() => location.hash === '#/focus'); await sleep(2500);
      if (flow === 'end12lv') await p.evaluate(() => window.__kettle.ff(12 * 60_000 + 5_000));
      await sleep(500);
      await p.evaluate(() => window.__kettle.timer.getState().end('user'));
      await p.waitForFunction(() => location.hash === '#/' || location.hash === '');
    }
    await p.waitForSelector('[id="toast-kettle:save-failed"]', { timeout: 8000 });
    await sleep(1500);
    // Hold every toast's timer, as a person touching the stack does.
    await p.evaluate(() => document.querySelectorAll('[aria-label="Notifications"] li').forEach((li) => li.dispatchEvent(new PointerEvent('pointerenter'))));
    await p.waitForFunction(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].every((li) => getComputedStyle(li).transform === 'none'), null, { timeout: 5000 }).catch(() => {});
    // Per-frame recorder.
    await p.evaluate(() => {
      const R = (window.__rec = { samples: [], warnSeen: new Set(), warnAll: new Set(), toastWhole: {}, toastLines: {}, toastAll: {}, texts: [] });
      const W = 'toast-kettle:save-failed';
      const inter = (a, c) => a.bottom > c.top && a.top < c.bottom && a.right > c.left && a.left < c.right;
      const tick = () => {
        if (R.stop) return;
        // A person's finger or pointer resting on the stack holds every toast's timer: keep them all held (real input
        // sends pointerleave as it moves between toasts, which would let an older toast time out mid-reading).
        document.querySelectorAll('[aria-label="Notifications"] li').forEach((li) => li.dispatchEvent(new PointerEvent('pointerenter')));
        const list = document.querySelector('[aria-label="Notifications"] ol');
        const lis = list ? [...list.querySelectorAll(':scope > li')] : [];
        const w = document.getElementById(W);
        const dock = document.querySelector('[data-toast-above]'); const dt = dock ? dock.getBoundingClientRect().top : innerHeight;
        const lr = list ? list.getBoundingClientRect() : null;
        const visTop = Math.max(0, lr ? lr.top : 0), visBottom = Math.min(innerHeight, lr ? lr.bottom : innerHeight, dt);
        let op = 0, wr = null;
        if (w) { op = 1; for (let e = w; e && e !== document.documentElement; e = e.parentElement) op *= +getComputedStyle(e).opacity; wr = w.getBoundingClientRect(); }
        R.samples.push([Math.round(performance.now()), w ? 1 : 0, +op.toFixed(3), wr ? Math.round(wr.top) : null, wr ? Math.round(wr.bottom) : null, list ? Math.round(list.scrollTop) : null, Math.round(dt), lr ? Math.round(lr.bottom) : null]);
        const wi = lis.indexOf(w);
        lis.forEach((li, i) => {
          const key = li.id || li.textContent.slice(0, 30);
          const r = li.getBoundingClientRect();
          const isWarn = li === w;
          // What is painted above this toast: older toasts (z 2) are above the warning (z 1); the warning is above newer ones (z 0).
          const coverers = isWarn ? lis.slice(0, Math.max(0, wi)).map((x) => x.getBoundingClientRect()) : wi >= 0 && i > wi ? [wr] : [];
          let opq = 1; for (let e = li; e && e !== document.documentElement; e = e.parentElement) opq *= +getComputedStyle(e).opacity;
          if (opq < 0.98) return;
          if (!isWarn) {
            R.toastAll[key] = true;
            if (r.top >= visTop - 1 && r.bottom <= visBottom + 1 && !coverers.some((c) => inter(r, c))) R.toastWhole[key] = true;
          }
          const msg = li.querySelector('span[class*="message"]'); if (!msg) return;
          const rg = document.createRange(); rg.selectNodeContents(msg);
          const mt = msg.getBoundingClientRect().top;
          const act = li.querySelector('button')?.getBoundingClientRect();
          const set = isWarn ? R.warnSeen : (R.toastLines[key] ??= new Set());
          const all = isWarn ? R.warnAll : (R.toastAll2 ??= {}, (R.toastAll2[key] ??= new Set()));
          for (const q of rg.getClientRects()) {
            const k = Math.round((q.top - mt) / Math.max(1, q.height)); all.add(k);
            const inBox = q.top >= Math.max(visTop, r.top) - 1 && q.bottom <= Math.min(visBottom, r.bottom) + 1;
            const underAct = act && inter(q, act);
            if (inBox && !underAct && !coverers.some((c) => inter(q, c))) set.add(k);
          }
        });
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    const info = () => p.evaluate(() => { const list = document.querySelector('[aria-label="Notifications"] ol'); const w = document.getElementById('toast-kettle:save-failed'); const lr = list.getBoundingClientRect(); const wr = w ? w.getBoundingClientRect() : null; return { lr: [lr.left, lr.top, lr.right, lr.bottom], wr: wr && [wr.left, Math.max(wr.top, 0), wr.right, wr.bottom], wst: w ? [w.scrollTop, w.scrollHeight - w.clientHeight] : null, lst: [list.scrollTop, -(list.scrollHeight - list.clientHeight)], lis: [...list.querySelectorAll(':scope > li')].map((li) => { const r = li.getBoundingClientRect(); return { id: li.id, r: [r.left, r.top, r.right, r.bottom], st: li.scrollTop, sr: li.scrollHeight - li.clientHeight }; }) }; });
    const cdp = how === 'touch' ? await ctx.newCDPSession(p) : null;
    const scrollAt = async (x, y, dy) => {
      if (how === 'wheel') { await p.mouse.move(x, y); await p.mouse.wheel(0, dy); }
      else { // a finger drag: content follows the finger, so scrolling content down (dy > 0) drags the finger up
        const steps = Math.max(2, Math.round(Math.abs(dy) / 8)); const dir = dy > 0 ? -1 : 1;
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: Math.round(x), y: Math.round(y) }] });
        for (let i = 1; i <= steps; i++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: Math.round(x), y: Math.round(y + dir * i * 8) }] }); await sleep(16); }
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      }
      await sleep(how === 'wheel' ? 140 : 120);
      if (process.env.TRACE) { const s = await info(); console.log('  after', dy, 'at', Math.round(x), Math.round(y), 'warn st/max', s.wst, 'list st/min', s.lst.map(Math.round), 'warn box', s.wr && s.wr.map(Math.round)); }
    };
    // A: read the warning down to its end (scrolling inside it where it scrolls).
    for (let i = 0; i < 30; i++) {
      const s = await info(); if (!s.wr) break;
      const y0 = s.wr[1] + 0.35 * (s.wr[3] - s.wr[1]), x0 = (s.wr[0] + s.wr[2]) / 2;
      if (s.wst[0] >= s.wst[1] - 1) break;
      await scrollAt(x0, how === 'touch' ? Math.max(s.wr[1] + 12, y0) : y0, 40);
    }
    // B: scroll up to the top: the warning's own start first, then the list (older toasts slide down over the warning).
    for (let i = 0; i < 90; i++) {
      const s = await info(); if (!s.wr) break;
      if (s.wst[0] <= 0 && s.lst[0] <= s.lst[1] + 1) break;
      const x0 = (s.lr[0] + s.lr[2]) / 2, y0 = Math.max(0, s.lr[1]) + Math.min(24, (s.lr[3] - Math.max(0, s.lr[1])) / 3);
      // Up in 20 px steps (a touchpad, or a wheel with smooth scrolling): a toast exactly as tall as a 60 px room is
      // wholly in view at one list offset only.
      await scrollAt(x0, how === 'touch' ? Math.max(4, y0) : y0, -20);
    }
    // C: an older toast taller than its room scrolls its own message: read each such one where it now shows.
    for (const li of (await info()).lis) {
      if (li.id === 'toast-kettle:save-failed' || li.sr <= 0) continue;
      for (let i = 0; i < 12; i++) { const s = (await info()).lis.find((x) => x.id === li.id); if (!s || s.st >= s.sr - 1) break; await scrollAt((s.r[0] + s.r[2]) / 2, Math.max(4, s.r[1] + 10), 30); }
    }
    const lastInput = await p.evaluate(() => performance.now());
    await sleep(2200);
    await p.screenshot({ path: `${out}/realscroll-${w}x${h}-t${pct}-${theme}-${flow}-${how}-${tag}.png` });
    res = await p.evaluate((lastInput) => {
      const R = window.__rec; R.stop = true;
      const s = R.samples; const after = s.filter((x) => x[0] >= lastInput);
      const gone = s.filter((x) => !x[1] || x[2] < 0.98).length;
      const below = s.filter((x) => x[1] && x[4] > Math.min(x[6], x[7]) + 0.5).length;
      const sts = after.map((x) => x[5]);
      return { frames: s.length, framesAfterLastInput: after.length, msAfter: after.length ? after[after.length - 1][0] - after[0][0] : 0, warningGoneOrFaded: gone, warningBelowRoom: below, listScrollAfter: [Math.min(...sts), Math.max(...sts)], warnLines: [R.warnSeen.size, R.warnAll.size], toasts: Object.keys(R.toastAll).map((k) => [k.slice(0, 18), !!R.toastWhole[k], (R.toastLines[k]?.size ?? 0), (R.toastAll2?.[k]?.size ?? 0)]) };
    }, lastInput);
    res.quota = quota;
    const ok = quota === 'QuotaExceededError' && res.warningGoneOrFaded === 0 && res.warningBelowRoom === 0 && res.listScrollAfter[1] - res.listScrollAfter[0] <= 1 && res.msAfter >= 2000 && res.warnLines[0] >= res.warnLines[1] && res.toasts.every((t) => t[1] && t[2] >= t[3]);
    n++; if (!ok) fails++;
    console.log(`${tag} ${label}: ${ok ? 'OK' : 'FAIL'} ${JSON.stringify(res)}${errors.length ? ` errors ${errors.join('|')}` : ''}`);
  } catch (e) { n++; fails++; console.log(`${tag} ${label}: ERROR ${String(e.message).split('\n')[0]}`); }
  await ctx.close();
}
console.log(`failures: ${fails} of ${n}`);
await b.close();

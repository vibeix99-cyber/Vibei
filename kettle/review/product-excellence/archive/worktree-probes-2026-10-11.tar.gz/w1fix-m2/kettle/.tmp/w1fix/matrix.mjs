// r2 retest matrix for Today's status bar. node .tmp/w1fix/matrix.mjs <base>
import { chromium } from 'playwright';
const [,, base] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const measure = (p) => p.evaluate(() => {
  const el = document.querySelector('nav[aria-label="Your progress"]');
  const kids = [...el.children];
  const texts = [...el.querySelectorAll('*')].filter((n) => n.offsetWidth > 1 && [...n.childNodes].some((c) => c.nodeType === 3 && c.textContent.trim()));
  const right = Math.max(...[el, ...kids, ...texts].map((n) => n.getBoundingClientRect().right));
  const tabs = document.querySelector('nav[aria-label="Main"]');
  const lvl = el.querySelector('[data-kind="level"] span[aria-hidden]');
  return { mode: el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal', rows: new Set(kids.map((k) => Math.round(k.getBoundingClientRect().top))).size, right: Math.round(right), sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, iw: innerWidth, ih: innerHeight, tab: Math.round(tabs.getBoundingClientRect().bottom), lvlW: lvl ? Math.round(lvl.getBoundingClientRect().width) : null };
});
const ok = (r, w, h) => r.right <= w && r.sw <= r.cw && r.iw === w && r.tab <= h;
const big = (ctx, pct) => pct !== 100 && ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
let fails = 0;
console.log('## D1: resize / rotation, then measure (settle 1.5 s)\n');
for (const theme of ['light', 'dark']) for (const [fw, fh, mobile, pct] of [[414,896,true,100],[667,375,true,100],[844,390,true,100],[390,844,true,100],[1440,900,false,100],[800,900,false,100],[414,896,true,200]]) {
  const ctx = await b.newContext({ viewport: { width: fw, height: fh }, deviceScaleFactor: mobile ? 2 : 1, isMobile: mobile, hasTouch: mobile, colorScheme: theme });
  await big(ctx, pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(2000);
  await p.setViewportSize({ width: 375, height: 667 }); await p.waitForTimeout(1500);
  const r = await measure(p);
  await p.setViewportSize({ width: 414, height: 896 }); await p.waitForTimeout(1500);
  const back = await measure(p);
  const good = (mobile ? ok(r, 375, 667) : (r.right <= r.cw && r.sw <= r.cw)) && r.rows === (pct === 200 ? 2 : 1) && back.mode === (pct === 200 ? 'wrap' : 'normal');
  if (!good) fails++;
  console.log(`${theme} ${fw}x${fh}${mobile ? '' : ' (desktop window)'} ${pct}% → 375x667: ${r.mode}, rows ${r.rows}, right ${r.right}, scrollW ${r.sw}/clientW ${r.cw}, innerW ${r.iw}, tab bottom ${r.tab}; → 414x896: ${back.mode} ${good ? 'OK' : 'FAIL'}`);
  await ctx.close();
}
console.log('\n## D2: text 100/150/175/200 % × leaves (live data change), phones\n');
for (const theme of ['light', 'dark']) for (const [w, h] of [[375,667],[390,844],[360,740]]) for (const pct of [100, 150, 175, 200]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  await big(ctx, pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
  const cells = [];
  for (const leaves of [2296, 9999, 10000, 12345, 123456, 470000]) {
    await p.evaluate((n) => window.__kettle.progress.setState({ leaves: n }), leaves); await p.waitForTimeout(900);
    const r = await measure(p); const good = ok(r, w, h) && (pct !== 100 || r.rows === 1);
    if (!good) fails++;
    cells.push(`${leaves}:${r.mode}/${r.rows}r/R${r.right}/lvl${r.lvlW}${good ? '' : ' FAIL(sw ' + r.sw + ', iw ' + r.iw + ', tab ' + r.tab + ')'}`);
  }
  console.log(`${theme} ${w}x${h} ${pct}%: ${cells.join('  ')}`);
  await ctx.close();
}
console.log(`\nfailures: ${fails}`);
await b.close();

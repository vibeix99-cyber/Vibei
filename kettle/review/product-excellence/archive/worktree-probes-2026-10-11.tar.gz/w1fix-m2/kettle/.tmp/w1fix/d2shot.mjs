import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, out] = process.argv; mkdirSync(out, { recursive: true });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light', 'dark']) for (const [w, h] of [[375, 667], [390, 844]]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
  await p.evaluate(() => window.__kettle.progress.setState({ leaves: 12345 })); await p.waitForTimeout(1500);
  const r = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, iw: innerWidth, ih: innerHeight }));
  console.log(tag, theme, `${w}x${h}`, '200% 12,345 leaves', JSON.stringify(r));
  await p.screenshot({ path: `${out}/today-${w}x${h}-text200-12345-leaves-${theme}-${tag}.png` });
  await ctx.close();
}
await b.close();

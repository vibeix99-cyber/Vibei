// Today status bar: one row / tight / wrap per width and text size; sideways scroll; console errors.
import { chromium } from 'playwright';
const [,, base] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const cases = [[390,844,1,true],[375,667,1,true],[360,740,1,true],[320,568,1,true],[1440,900,1,false],[390,844,2,true],[375,667,2,true],[1440,900,2,false]];
for (const [w,h,scale,mobile] of cases) for (const theme of ['light','dark']) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor: mobile?2:1, isMobile:mobile, hasTouch:mobile, colorScheme: theme });
  if (scale === 2) await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
  const p = await ctx.newPage(); const errs = [];
  p.on('console', (m) => { if (m.type() === 'error' || /ResizeObserver/.test(m.text())) errs.push(m.text().slice(0, 80)); });
  p.on('pageerror', (e) => errs.push(e.message.slice(0, 80)));
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/`, { waitUntil: 'networkidle' });
  await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
  const r = await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); const kids=[...el.children]; return { mode: el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal', rows: new Set(kids.map(k=>Math.round(k.getBoundingClientRect().top))).size, right: Math.round(Math.max(...kids.map(k=>k.getBoundingClientRect().right))), cw: document.documentElement.clientWidth, pageW: document.documentElement.scrollWidth, greetingTop: Math.round(document.getElementById('home-greeting').getBoundingClientRect().top) }; });
  console.log(`${w}x${h} text${scale*100}% ${theme}`.padEnd(26), JSON.stringify(r), errs.length ? 'ERR ' + errs.join(' | ') : '');
  await ctx.close();
}
await b.close();

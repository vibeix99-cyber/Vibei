// Re-judge race6.mjs records (*.jsonl) with one more case of the warning's OWN timed end: its exit fade beginning in
// the last frames of the recording, so the recording stops before its element is removed (race6 only recognises a
// timed end by that removal). Such a run is re-judged as "own end" only if ALL hold: the warning was never removed or
// re-added after it first appeared; every frame below 0.98 opacity belongs to one run that starts after the last input,
// decreases monotonically and lasts to the last recorded frame; and in every judged frame its box is inside the room and
// clear of the docked start (so M1's rule had no reason to take it away: its zones are the room's bottom 170 px and the
// warning's own box, and the docked start's controls are below the room). Everything else is judged as race6 judges it.
// node .tmp/w1fix/rejudge6.mjs <race6 jsonl>...
import { readFileSync } from 'node:fs';
const WARN = 'toast-kettle:save-failed';
let n = 0, fail = 0, ownEndAtCut = 0;
const per = {};
for (const file of process.argv.slice(2)) for (const line of readFileSync(file, 'utf8').split('\n').filter(Boolean)) {
  const d = JSON.parse(line);
  const cfg = d.label.split(' ').slice(0, 2).join(' ');
  per[cfg] ??= { n: 0, fail: 0, cut: 0 };
  n++; per[cfg].n++;
  if (!d.bad.length) continue;
  const warnIn = d.ev.find((e) => e[2] === WARN && e[1] === '+')?.[0] ?? 0;
  const warnEvents = d.ev.filter((e) => e[2] === WARN && e[0] > warnIn);
  const judged = d.frames.filter((f) => f[0] >= warnIn + 1200);
  const low = judged.map((f, i) => [f, i]).filter(([f]) => f[2] < 0.98);
  const below = judged.filter((f) => f[4] != null && f[4] > Math.min(f[5] ?? 1e9, f[6] ?? 1e9) + 0.5);
  const first = low.length ? low[0][1] : -1;
  const tail = first >= 0 ? judged.slice(first) : [];
  const monotonic = tail.every((f, i) => i === 0 || f[2] <= tail[i - 1][2] + 0.001);
  const toEnd = first >= 0 && low.length === judged.length - first;
  const isCut = warnEvents.length === 0 && below.length === 0 && low.length > 0 && toEnd && monotonic;
  if (isCut) { ownEndAtCut++; per[cfg].cut++; console.log(`own end at the recording's cut: ${d.label} (fade ${tail.map((f) => f[2]).join(' → ')}, box ${tail[0][3]}–${tail[0][4]}, room ${tail[0][6]}, dock ${tail[0][5]})`); continue; }
  fail++; per[cfg].fail++;
  console.log(`FAIL ${d.label}: ${d.bad.join('; ')}`);
}
for (const [k, v] of Object.entries(per)) console.log(`${k}: ${v.n} runs, ${v.fail} failures (${v.cut} with the warning's own timed end beginning at the recording's cut)`);
console.log(`total: ${n} runs, ${fail} failures; ${ownEndAtCut} runs whose only flagged frames are the warning's own exit fade at the end of the recording`);

// R2-D3 retest: toast stacks at text sizes. node .tmp/w1fix/toaststack.mjs <base> <tag> [outDir] [filter]
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, out = '', filter = ''] = process.argv;
if (out) mkdirSync(out, { recursive: true });
const WARN = 'Kettle couldn’t save your latest changes: this browser’s storage is full. Save a backup to keep them.';
const STACKS = {
  alone: [[WARN, 'warning', true]],
  earlyEnd1: [['Kettle’s off. See you soon.', 'neutral'], [WARN, 'warning', true]],
  earlyEnd12: [['Cozy level 5!', 'success'], ['Saved 12 minutes of focus', 'success'], [WARN, 'warning', true]],
  three: [['Recipe done: Take a full tea break · +10 leaves', 'success'], ['New badge: Tea Time', 'success'], [WARN, 'warning', true]],
};
const CONFIGS = [];
for (const [w, h, mobile] of [[375, 667, true], [390, 844, true], [1440, 900, false]]) for (const pct of [100, 150, 200]) CONFIGS.push([w, h, mobile, pct]);
for (const [w, h] of [[667, 375], [844, 390]]) for (const pct of [100, 125, 150, 200]) CONFIGS.push([w, h, true, pct]);
CONFIGS.push([568, 320, true, 100], [320, 568, true, 100]);
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
let fails = 0;
for (const theme of ['light', 'dark']) for (const [w, h, mobile, pct] of CONFIGS) {
  if (filter && !`${w}x${h}@${pct}`.match(new RegExp(filter))) continue;
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: mobile ? 2 : 1, isMobile: mobile, hasTouch: mobile, colorScheme: theme });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1200);
  for (const [name, items] of Object.entries(STACKS)) {
    await p.evaluate(async () => (await import('/src/ui/Toast.tsx')).toast.dismiss());
    await p.waitForTimeout(500);
    await p.evaluate(async (items) => { const { toast } = await import('/src/ui/Toast.tsx'); for (const [m, tone, act] of items) toast(m, { tone, duration: 60000, ...(act ? { action: { label: 'Save backup', onClick() { window.__saved = (window.__saved || 0) + 1; } } } : {}) }); }, items);
    await p.waitForTimeout(1600);
    const r = await p.evaluate(async () => {
      const raf = () => new Promise((res) => requestAnimationFrame(() => res()));
      const list = document.querySelector('[aria-label="Notifications"] ol');
      const lis = [...list.querySelectorAll(':scope > li')];
      const lr = list.getBoundingClientRect(); const cs = getComputedStyle(list);
      const scroller = /(auto|scroll)/.test(cs.overflowY);
      const scrolls = (el) => /(auto|scroll)/.test(getComputedStyle(el).overflowY);
      const dock = document.querySelector('[data-toast-above]'); const dt = dock ? dock.getBoundingClientRect().top : innerHeight;
      // The box the stack is seen in: the list's scroll box (on screen), or the screen.
      const visTop = Math.max(0, scroller ? lr.top : 0); const visBottom = scroller ? Math.min(innerHeight, lr.bottom) : Math.max(...lis.map((li) => li.getBoundingClientRect().bottom));
      const innerScroll = lis.map((li) => scrolls(li) ? Math.round(li.scrollHeight - li.clientHeight) : 0);
      // Text outside its own box: only where the toast does not scroll its own content (a scrolling toast clips and scrolls it).
      const spill = lis.map((li) => { if (scrolls(li)) return 0; const r = li.getBoundingClientRect(); const kids = [...li.querySelectorAll('*')].filter((n) => n.getClientRects().length); const over = Math.max(0, ...kids.map((k) => k.getBoundingClientRect().bottom - r.bottom), ...kids.map((k) => r.top - k.getBoundingClientRect().top)); return Math.round(over); });
      const rects = lis.map((li) => { const r = li.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom)]; });
      const start = list.scrollTop;
      // As first shown: the newest toast (last) wholly in view; no toast reaching below the room (over the docked start).
      const nr = lis[lis.length - 1].getBoundingClientRect();
      const newestInView = nr.bottom <= visBottom + 1 && nr.bottom >= visTop && (nr.top >= visTop - 1 || nr.height > visBottom - visTop);
      const noneBelowRoom = lis.every((li) => li.getBoundingClientRect().bottom <= dt + 0.5);
      const warn = lis.find((li) => li.querySelector('button')) || null;
      const btn = warn ? warn.querySelector('button') : null;
      const hitAt = () => { const br = btn.getBoundingClientRect(); const x = br.left + br.width / 2, y = br.top + br.height / 2; return y >= visTop && y <= visBottom && btn.contains(document.elementFromPoint(x, y)); };
      const btnHitAsShown = btn ? hitAt() : null;
      // Every toast reachable: scrolling the list through its whole range brings each toast's top and bottom into view.
      const seenTop = lis.map(() => false), seenBottom = lis.map(() => false);
      const range = Math.ceil(list.scrollHeight);
      for (let y = -range; y <= range; y += 8) {
        list.scrollTop = y;
        lis.forEach((li, i) => { const q = li.getBoundingClientRect(); if (q.top >= visTop - 1 && q.top <= visBottom + 1) seenTop[i] = true; if (q.bottom <= visBottom + 1 && q.bottom >= visTop - 1) seenBottom[i] = true; });
      }
      const allReachable = seenTop.every(Boolean) && seenBottom.every(Boolean);
      // The whole warning readable: every line of its message passes through view (list and warning scrolled), not under its action.
      let warnRead = null;
      if (warn) {
        const msg = warn.querySelector('span:nth-of-type(2)'); const rg = document.createRange(); rg.selectNodeContents(msg);
        const key = (q) => Math.round(q.top - msg.getBoundingClientRect().top);
        const lines = new Set([...rg.getClientRects()].map(key)); const seen = new Set();
        for (let y = -range; y <= range; y += 10) for (let z = 0; z <= warn.scrollHeight; z += 10) {
          list.scrollTop = y; warn.scrollTop = z;
          const wr = warn.getBoundingClientRect(); const t = Math.max(visTop, wr.top), b = Math.min(visBottom, wr.bottom); const ar = btn.getBoundingClientRect();
          for (const q of rg.getClientRects()) { const covered = q.bottom > ar.top && q.top < ar.bottom && q.right > ar.left; if (q.top >= t - 1 && q.bottom <= b + 1 && !covered) seen.add(key(q)); }
          if (warn.scrollTop + warn.clientHeight >= warn.scrollHeight) break;
        }
        warn.scrollTop = 0;
        warnRead = [seen.size, lines.size];
      }
      list.scrollTop = start; await raf();
      const btnHitAfter = btn ? hitAt() : null;
      return { rects, newestInView, noneBelowRoom, allReachable, warnRead, spill, innerScroll, scroll: [Math.round(list.scrollHeight - list.clientHeight)], visible: [Math.round(visTop), Math.round(visBottom)], btnHit: btnHitAsShown, btnHitAfter, dockClear: visBottom <= dt + 0.5, scroller };
    });
    const ok = r.spill.every((x) => x === 0) && r.dockClear && r.newestInView && r.noneBelowRoom && r.allReachable && (r.warnRead == null || r.warnRead[0] >= r.warnRead[1]) && (r.btnHit == null || (r.btnHit && r.btnHitAfter));
    if (!ok) fails++;
    console.log(`${tag} ${theme} ${w}x${h} ${pct}% ${name}: ${ok ? 'OK' : 'FAIL'} ${JSON.stringify(r)}`);
    if (out && (pct !== 100 || name === 'three')) await p.screenshot({ path: `${out}/stack-${name}-${w}x${h}-t${pct}-${theme}-${tag}.png` });
  }
  await ctx.close();
}
console.log(`failures: ${fails}`);
await b.close();

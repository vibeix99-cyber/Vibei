// The last toast's own timed end: is it drawn over the docked start while it fades out (the region dropping back when
// the list empties)? Today, a toast with an action raised with a 1.5 s life (real timer), no pointer on it; every frame
// recorded until 1 s after it is gone. node .tmp/w1fix/lastexit.mjs <base> <tag>
import { chromium } from 'playwright';
const [,, base, tag] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
let fails = 0, n = 0;
for (const [w, h, pct] of [[844, 390, 200], [375, 667, 200], [667, 375, 200], [375, 667, 100], [390, 844, 100], [844, 390, 100]]) for (const theme of ['light', 'dark']) for (const action of [true, false]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.evaluate(() => document.fonts.ready); await sleep(1500);
  await p.evaluate(async () => (await import('/src/ui/Toast.tsx')).toast.dismiss()); await sleep(600);
  await p.evaluate(() => {
    const R = (window.__rec = { frames: [], t0: performance.now() });
    const f = () => { if (R.stop) return; const lis = [...document.querySelectorAll('[aria-label="Notifications"] li')]; const list = document.querySelector('[aria-label="Notifications"] ol'); const lr = list.getBoundingClientRect(); const ctrls = [...document.querySelectorAll('[data-toast-above] :is(button, a[href], [role="button"], input, textarea, select)')].map((c) => c.getBoundingClientRect()).filter((r) => r.width && r.height); let over = 0; for (const li of lis) { const r = li.getBoundingClientRect(); const op = +getComputedStyle(li).opacity; const d = { l: Math.max(r.left, lr.left), t: Math.max(r.top, lr.top), r: Math.min(r.right, lr.right), b: Math.min(r.bottom, lr.bottom) }; if (op > 0.02 && d.r > d.l && d.b > d.t && ctrls.some((c) => d.r > c.left + 0.5 && d.l < c.right - 0.5 && d.b > c.top + 0.5 && d.t < c.bottom - 0.5)) over++; } R.frames.push([Math.round(performance.now() - R.t0), lis.length, over]); requestAnimationFrame(f); };
    requestAnimationFrame(f);
  });
  await p.evaluate(async (action) => { const { toast } = await import('/src/ui/Toast.tsx'); toast(action ? 'Kettle couldn’t save your latest changes: this browser’s storage is full. Save a backup to keep them.' : 'Saved 12 minutes of focus', { tone: action ? 'warning' : 'success', duration: 1500, ...(action ? { action: { label: 'Save backup', onClick() {} } } : {}) }); }, action);
  await p.waitForFunction(() => document.querySelectorAll('[aria-label="Notifications"] li').length === 0 && window.__rec.frames.some((f) => f[1] > 0), null, { timeout: 10000 });
  await sleep(1000);
  const F = await p.evaluate(() => { window.__rec.stop = true; return window.__rec.frames; });
  const over = F.filter((f) => f[2]).length; n++; if (over) fails++;
  console.log(`${tag} ${w}x${h}@${pct} ${theme} ${action ? 'warning' : 'plain'}: ${over ? 'FAIL' : 'OK'} frames with a toast drawn over a docked control: ${over} of ${F.length}`);
  await ctx.close();
}
console.log(`${tag}: ${fails} of ${n}`);
await b.close();

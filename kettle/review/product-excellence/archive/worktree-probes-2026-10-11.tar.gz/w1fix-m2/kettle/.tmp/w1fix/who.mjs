import { chromium } from 'playwright';
const [,, base, W, H] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:+W,height:+H}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light#/`, { waitUntil: 'load' }); await p.waitForTimeout(3000);
console.log(JSON.stringify(await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); return [...el.querySelectorAll('*')].map(n => { const r = n.getBoundingClientRect(); return [n.tagName, String(n.className.baseVal ?? n.className).slice(0,25), Math.round(r.left), Math.round(r.right), n.offsetWidth ?? '-', getComputedStyle(n).position]; }).filter(x => x[3] > 370); })));
await b.close();

// r6 item (d): measure exactly why Tab misses "Save backup" at 375×667 / 100 %: after each Tab from "25 min" onward,
// sample every 50 ms for 1 s: the page scroll, Today's docked start (Composer .ctaDock, data-toast-above), the app's own
// toastLiftBottom() (imported), the region, the warning, and M1's hold-rule zones (flow.ts: zone 1 = [bottom − 170,
// bottom], bottom = innerHeight − lift or the region's bottom; zone 2 = the warning's box) against the controls inside
// data-toast-above that are horizontally under the toast area. node .tmp/w1fix/kbdwhy.mjs <base>
import { chromium } from 'playwright';
const [,, base] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const WARN = 'toast-kettle:save-failed';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport: { width: 375, height: 667 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, acceptDownloads: true });
await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
const p = await ctx.newPage();
const ready = () => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
await p.goto(`${base}/?debug&theme=light&nooktime=day#/`); await ready();
await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
await p.evaluate(() => document.fonts.ready);
await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } });
await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
await p.waitForFunction(() => location.hash === '#/focus'); await sleep(2500);
await p.evaluate(() => window.__kettle.timer.getState().end('user'));
await p.waitForFunction(() => location.hash === '#/' || location.hash === '');
await p.waitForSelector(`[id="${WARN}"]`, { timeout: 8000 }); await sleep(800);
const measure = () => p.evaluate(async (W) => {
  const { toastLiftBottom } = await import('/src/ui/Toast.tsx');
  const a = document.activeElement;
  const live = document.querySelector('[aria-label="Notifications"]'); const region = live.parentElement;
  const dock = document.querySelector('[data-toast-above]'); const dr = dock.getBoundingClientRect();
  const lift = toastLiftBottom();
  const bottom = lift != null ? innerHeight - lift : region.getBoundingClientRect().bottom;
  const w = document.getElementById(W); const wr = w?.getBoundingClientRect();
  const zones = [[Math.round(bottom - 170), Math.round(bottom)]]; if (wr) zones.push([Math.round(wr.top), Math.round(wr.bottom)]);
  const area = live.getBoundingClientRect();
  const ctrls = [...document.querySelectorAll('[data-toast-above] :is(button, a[href], [role="button"], input, textarea, select)')].map((c) => [c.textContent.trim().replace(/\s+/g, ' ').slice(0, 22), c.getBoundingClientRect()]).filter(([, r]) => r.width && r.height && !(r.right <= area.left || r.left >= area.right));
  const blocking = ctrls.filter(([, r]) => zones.some(([t, bt]) => r.bottom > t && r.top < bt)).map(([n, r]) => `${n} ${Math.round(r.top)}–${Math.round(r.bottom)}`);
  return { focus: a === document.body ? 'body' : (a.textContent || a.tagName).trim().replace(/\s+/g, ' ').slice(0, 26), scrollY: Math.round(scrollY), maxScroll: document.documentElement.scrollHeight - innerHeight, dock: [Math.round(dr.top), Math.round(dr.bottom)], dockCounted: dr.height > 0 && dr.top < innerHeight && dr.bottom > innerHeight * 0.6, lift, regionBottom: Math.round(region.getBoundingClientRect().bottom), warning: wr ? [Math.round(wr.top), Math.round(wr.bottom)] : null, zones, controls: ctrls.map(([n, r]) => `${n} ${Math.round(r.top)}–${Math.round(r.bottom)}`), blocking };
}, WARN);
const t0 = Date.now();
for (let i = 1; i <= 14; i++) {
  await p.keyboard.press('Tab');
  const samples = [];
  for (let k = 0; k < (i >= 11 ? 12 : 1); k++) { samples.push({ ms: Date.now() - t0, ...(await measure()) }); await sleep(i >= 11 ? 50 : 300); }
  const first = samples[0], last = samples[samples.length - 1];
  console.log(`Tab ${i} → ${first.focus} | scrollY ${first.scrollY}/${first.maxScroll}`);
  if (i >= 11) for (const s of samples) console.log(`   +${s.ms} ms scrollY ${s.scrollY} dock ${JSON.stringify(s.dock)} counted by toastLiftBottom ${s.dockCounted} lift ${s.lift} region bottom ${s.regionBottom} warning ${JSON.stringify(s.warning)} zones ${JSON.stringify(s.zones)} blocking ${JSON.stringify(s.blocking)}`);
  if (i >= 11) console.log(`   controls in data-toast-above under the toast area: ${JSON.stringify(last.controls)}`);
}
await b.close();

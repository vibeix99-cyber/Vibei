import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, out] = process.argv; mkdirSync(out, { recursive: true });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const theme of ['light', 'dark']) for (const [fw, fh] of [[414, 896], [667, 375]]) {
  const ctx = await b.newContext({ viewport: { width: fw, height: fh }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(2000);
  await p.setViewportSize({ width: 375, height: 667 }); await p.waitForTimeout(2000);
  const r = await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); const tabs = document.querySelector('nav[aria-label="Main"]'); return { mode: el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal', sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, iw: innerWidth, ih: innerHeight, tabBottom: Math.round(tabs.getBoundingClientRect().bottom) }; });
  console.log(tag, theme, `${fw}x${fh} -> 375x667`, JSON.stringify(r));
  await p.screenshot({ path: `${out}/resize-${fw}x${fh}-to-375x667-${theme}-${tag}.png` });
  await ctx.close();
}
await b.close();

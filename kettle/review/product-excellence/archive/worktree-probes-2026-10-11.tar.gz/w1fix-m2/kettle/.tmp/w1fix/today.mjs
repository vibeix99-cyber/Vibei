import { chromium } from 'playwright';
const b = await chromium.launch();
for (const port of [5202, 5232]) {
const ctx = await b.newContext({ viewport: { width: 375, height: 667 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const p = await ctx.newPage();
await p.goto(`http://127.0.0.1:${port}/?debug&seed=veteran&theme=light#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(2000);
console.log(port, JSON.stringify(await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); return { leaves: window.__kettle.progress.getState().leaves, mode: el.hasAttribute('data-wrap') ? 'wrap' : el.hasAttribute('data-tight') ? 'tight' : 'normal', right: Math.round(Math.max(...[...el.children].map((k) => k.getBoundingClientRect().right))), sw: document.documentElement.scrollWidth }; })));
await ctx.close(); }
await b.close();

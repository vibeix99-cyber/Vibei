import { chromium } from 'playwright';
const [,, base, W, H] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport:{width:+W,height:+H}, deviceScaleFactor:2, isMobile:true, hasTouch:true });
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, { waitUntil: 'networkidle' });
await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(2000);
console.log(JSON.stringify(await p.evaluate(() => { const el = document.querySelector('nav[aria-label="Your progress"]'); const was = el.hasAttribute('data-wrap'); el.removeAttribute('data-wrap'); const kids=[...el.children].map(c => { const r=c.getBoundingClientRect(); return [Math.round(r.left*10)/10, Math.round(r.right*10)/10, c.offsetWidth, c.textContent.trim().slice(0,12)]; }); const r=el.getBoundingClientRect(); const out={was, bar:[r.left, r.right, el.offsetWidth, el.scrollWidth], kids, cw: document.documentElement.clientWidth, sw: document.documentElement.scrollWidth, gap: getComputedStyle(el).columnGap, margin: getComputedStyle(el).margin}; if (was) el.setAttribute('data-wrap',''); return out; })));
await b.close();

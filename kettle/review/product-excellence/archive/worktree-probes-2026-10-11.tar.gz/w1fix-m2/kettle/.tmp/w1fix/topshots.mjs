import { chromium } from 'playwright';
const [,, base] = process.argv;
const out = 'review/product-excellence/contracts/I04/integration-fix/reflow';
import { mkdirSync } from 'node:fs'; mkdirSync(out, { recursive: true });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
for (const [w,h,scale] of [[360,740,1],[320,568,1],[390,844,2],[375,667,2],[320,568,2]]) {
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:2, isMobile:true, hasTouch:true, colorScheme:'light' });
  if (scale === 2) await ctx.addInitScript(() => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{font-size:200%!important}'; document.head.appendChild(s); }));
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, { waitUntil: 'networkidle' });
  await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
  const f = `${out}/today-${w}x${h}-text${scale*100}-light.png`;
  await p.screenshot({ path: f });
  console.log(f);
  await ctx.close();
}
await b.close();

// A long warning toast with an action on Today, at a text size; measures it and screenshots.
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
const [,, base, tag, outDir = ''] = process.argv;
if (outDir) mkdirSync(outDir, { recursive: true });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const MSG = 'Kettle couldn’t save your latest changes: this browser’s storage is full. Save a backup to keep them.';
const ONLY = process.env.ONLY ? process.env.ONLY.split(',') : null;
for (const theme of ['light', 'dark']) for (const [w, h, pct, mobile] of [[390,844,200,true],[375,667,200,true],[1440,900,200,false],[390,844,100,true],[375,667,100,true],[1440,900,100,false],[320,568,100,true],[390,844,150,true],[375,667,150,true]]) {
  if (ONLY && !ONLY.includes(`${w}x${h}@${pct}`)) continue;
  const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor: mobile?2:1, isMobile:mobile, hasTouch:mobile, colorScheme: theme });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme==='light'?'&nooktime=day':''}#/`, { waitUntil: 'load' });
  await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
  await p.evaluate(async (m) => (await import('/src/ui/Toast.tsx')).toast(m, { tone: 'warning', duration: 60000, action: { label: 'Save backup', onClick() { window.__saved = 1; } } }), MSG);
  await p.waitForTimeout(1800);
  const r = await p.evaluate(() => {
    const t = document.querySelector('[aria-label="Notifications"] li'); const tr = t.getBoundingClientRect();
    const btn = t.querySelector('button'); const br = btn.getBoundingClientRect();
    const hit = document.elementFromPoint(br.left + br.width / 2, br.top + br.height / 2);
    const dock = document.querySelector('[data-toast-above]'); const dr = dock ? dock.getBoundingClientRect() : null;
    const sc = [t, ...(function* () { let n = t.parentElement; while (n) { yield n; n = n.parentElement; } })()].find((n) => n.scrollHeight > n.clientHeight + 1 && /(auto|scroll)/.test(getComputedStyle(n).overflowY));
    const msg = t.querySelector('span:nth-of-type(2)') || t;
    const list = t.parentElement; const lr = list.getBoundingClientRect(); return { list: [Math.round(lr.top), Math.round(lr.bottom), list.scrollHeight, list.clientHeight], toast: [Math.round(tr.left), Math.round(tr.top), Math.round(tr.right), Math.round(tr.bottom)], h: Math.round(tr.height), btn: [Math.round(br.left), Math.round(br.top), Math.round(br.width), Math.round(br.height)], btnHit: btn.contains(hit), actionBelow: br.top >= msg.getBoundingClientRect().bottom - 1, dockTop: dr ? Math.round(dr.top) : null, clearOfDock: dr ? tr.bottom <= dr.top : null, scroller: sc ? (sc === t ? 'toast' : sc.className.toString().slice(0, 20)) : null, vh: innerHeight };
  });
  const onScreen = r.toast[1] >= 0 && r.toast[3] <= r.vh && r.toast[0] >= 0 && r.toast[2] <= w;
  console.log(`${tag} ${theme} ${w}x${h} ${pct}%`, onScreen ? 'ON SCREEN' : 'OFF SCREEN', JSON.stringify(r));
  if (outDir) await p.screenshot({ path: `${outDir}/toast-long-${w}x${h}-text${pct}-${theme}-${tag}.png` });
  await ctx.close();
}
await b.close();

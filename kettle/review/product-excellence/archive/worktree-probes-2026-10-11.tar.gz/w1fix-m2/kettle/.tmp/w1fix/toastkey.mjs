import { chromium } from 'playwright';
const [,, base, pct = '100', mobile = '1'] = process.argv;
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist'] });
const ctx = await b.newContext(mobile === '1' ? { viewport:{width:375,height:667}, deviceScaleFactor:2, isMobile:true, hasTouch:true } : { viewport:{width:1440,height:900} });
if (pct !== '100') await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
const p = await ctx.newPage();
await p.goto(`${base}/?debug&seed=veteran&theme=light&nooktime=day#/`, { waitUntil: 'load' }); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(1500);
await p.evaluate(async () => (await import('/src/ui/Toast.tsx')).toast('Kettle couldn’t save your latest changes: this browser’s storage is full. Save a backup to keep them.', { tone: 'warning', duration: 60000, action: { label: 'Save backup', onClick() { window.__saved = (window.__saved || 0) + 1; } } }));
await p.waitForTimeout(1200);
for (const key of ['Enter', 'Space']) {
  await p.getByRole('button', { name: 'Save backup' }).focus().catch(() => {});
  await p.keyboard.press(key); await p.waitForTimeout(400);
  console.log(base, pct, mobile, key, 'saved', await p.evaluate(() => window.__saved || 0), 'hash', await p.evaluate(() => location.hash), 'active', await p.evaluate(() => document.activeElement && document.activeElement.textContent.slice(0,20)));
  if (await p.evaluate(() => window.__saved)) break;
}
await b.close();

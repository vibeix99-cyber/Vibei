// r6 edge: the warning arrives while a stack of older toasts (no action: the bottom-up list) is scrolled. Is the
// warning's opening shown first (its top in view, own scroll 0), and is its box inside the room in every frame?
// node .tmp/w1fix/arrive.mjs <base> <tag>
import { chromium } from 'playwright';
const [,, base, tag] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const WARN = 'Kettle couldn’t save your latest changes: this browser’s storage is full. Save a backup to keep them.';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
let fails = 0, n = 0;
for (const [w, h, pct] of [[667, 375, 200], [375, 667, 200], [844, 390, 200], [568, 320, 100]]) for (const theme of ['light', 'dark']) for (const how of ['wheel', 'touch']) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: theme });
  if (pct !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), pct);
  const p = await ctx.newPage();
  await p.goto(`${base}/?debug&seed=veteran&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`, { waitUntil: 'load' });
  await p.evaluate(() => document.fonts.ready); await sleep(1200);
  await p.evaluate(async () => (await import('/src/ui/Toast.tsx')).toast.dismiss()); await sleep(400);
  // Three older toasts without an action (long-lived), then scroll the list to its far end (the oldest).
  await p.evaluate(async () => { const { toast } = await import('/src/ui/Toast.tsx'); for (const m of ['Recipe done: Take a full tea break · +10 leaves', 'New badge: Tea Time', 'Saved 25 minutes of focus']) toast(m, { tone: 'success', duration: 60000 }); });
  await sleep(1500);
  const st = () => p.evaluate(() => { const l = document.querySelector('[aria-label="Notifications"] ol'); const lr = l.getBoundingClientRect(); const x = (lr.left + lr.right) / 2; const on = (y) => !!document.elementFromPoint(x, y)?.closest('[aria-label="Notifications"] li'); let high = Math.max(0, lr.top) + 12; while (high < lr.bottom && !on(high)) high += 3; return { x, high, lst: l.scrollTop, range: l.scrollHeight - l.clientHeight }; });
  const cdp = how === 'touch' ? await ctx.newCDPSession(p) : null;
  let s = await st();
  const range = s.range;
  for (let i = 0, still = 0; i < 40 && still < 2; i++) {
    const a = await st();
    if (!cdp) { await p.mouse.move(Math.round(a.x), Math.round(a.high)); await p.mouse.wheel(0, -20); }
    else { await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: Math.round(a.x), y: Math.round(a.high) }] }); for (let k = 1; k <= 3; k++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: Math.round(a.x), y: Math.round(a.high) + k * 8 }] }); await sleep(16); } await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); }
    await sleep(150); s = await st(); still = Math.abs(s.lst - a.lst) < 0.5 ? still + 1 : 0;
  }
  const scrolledTo = s.lst;
  // Record every frame, then the warning arrives.
  await p.evaluate(() => {
    const R = (window.__rec = { frames: [], t0: performance.now() });
    const f = () => { if (R.stop) return; const w = [...document.querySelectorAll('[aria-label="Notifications"] li')].find((li) => li.querySelector('button')); const l = document.querySelector('[aria-label="Notifications"] ol'); const room = l.parentElement.parentElement.getBoundingClientRect(); const d = document.querySelector('[data-toast-above]')?.getBoundingClientRect(); const r = w?.getBoundingClientRect(); R.frames.push([Math.round(performance.now() - R.t0), r ? Math.round(r.top) : null, r ? Math.round(r.bottom) : null, Math.round(room.top), Math.round(room.bottom), d ? Math.round(d.top) : null, Math.round(l.scrollTop), w ? w.scrollTop : null]); requestAnimationFrame(f); };
    requestAnimationFrame(f);
  });
  await p.evaluate(async (WARN) => { const { toast } = await import('/src/ui/Toast.tsx'); toast(WARN, { tone: 'warning', duration: 60000, action: { label: 'Save backup', onClick() {} } }); }, WARN);
  await sleep(2000);
  const R = await p.evaluate(() => { window.__rec.stop = true; return window.__rec.frames; });
  const withW = R.filter((f) => f[1] != null);
  const below = withW.filter((f) => f[2] > Math.min(f[4], f[5] ?? 1e9) + 0.5);
  const last = withW[withW.length - 1];
  // opening first: the warning's top inside the room's visible part (>= 0 and >= room top - 20) and own scroll 0
  const openingShown = last && last[1] >= Math.max(0, last[3] - 20) - 0.5 && last[7] === 0;
  const ok = withW.length > 0 && !below.length && openingShown;
  n++; if (!ok) fails++;
  console.log(`${tag} ${w}x${h}@${pct} ${theme} ${how}: ${ok ? 'OK' : 'FAIL'} | older list scrolled to ${Math.round(scrolledTo)} of ${-Math.round(range)}; after the warning arrived: box ${last && last[1]}–${last && last[2]}, room ${last && last[3]}–${last && last[4]}, list ${last && last[6]}, own scroll ${last && last[7]}; frames below the room: ${below.length}/${withW.length}`);
  await ctx.close();
}
console.log(`${tag}: ${fails} failures in ${n}`);
await b.close();

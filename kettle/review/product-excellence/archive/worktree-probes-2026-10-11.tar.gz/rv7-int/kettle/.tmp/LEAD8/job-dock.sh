#!/bin/bash
# LEAD8: dockcheck.mjs (own probe) — disclosures and new risks. R8 9ff0d04 :5306, control b39202f :5301, INT 0d58c5e :5303
cd /home/user/wt/rv7-int/kettle
OUT=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round8-review/LEAD/runs/dockcheck
P=.tmp/LEAD8/dockcheck.mjs
echo "start $(date -u +%T) sha $(sha256sum $P | cut -c1-12) load $(cut -d' ' -f1-3 /proc/loadavg)"
node $P http://localhost:5306 9ff0d04 $OUT "375x667@200:light,667x375@100:light,844x390@100:light,667x375@200:light,1440x900@200:light" over
echo "r8 over done $(date -u +%T)"
node $P http://localhost:5303 0d58c5e $OUT "375x667@200:light,667x375@100:light,667x375@200:light" over
echo "int over done $(date -u +%T)"
node $P http://localhost:5301 b39202f $OUT "375x667@200:light,667x375@100:light,844x390@100:light" over
echo "ctl over done $(date -u +%T)"
node $P http://localhost:5306 9ff0d04 $OUT "667x375@200:light,844x390@200:dark" sheet
node $P http://localhost:5301 b39202f $OUT "667x375@200:light" sheet
echo "sheet done $(date -u +%T)"
node $P http://localhost:5306 9ff0d04 $OUT "667x375@200:light,844x390@200:dark,1440x900@200:light" summary
node $P http://localhost:5301 b39202f $OUT "667x375@200:light,844x390@200:dark" summary
echo "summary done $(date -u +%T)"
node $P http://localhost:5306 9ff0d04 $OUT "667x375@100:light,844x390@200:light" focus
node $P http://localhost:5301 b39202f $OUT "667x375@100:light,844x390@200:light" focus
echo "end $(date -u +%T) load $(cut -d' ' -f1-3 /proc/loadavg)"

#!/bin/bash
# LEAD8: accept-nav.mjs (M8's accept.mjs b65020ab + navigation instrumentation) — who reloads the page in 844x390 @200 wheel runs
cd /home/user/wt/rv7-int/kettle
OUT=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round8-review/LEAD/runs/navdiag
P=.tmp/LEAD8/accept-nav.mjs
echo "start $(date -u +%T) sha $(sha256sum $P | cut -c1-12) load $(cut -d' ' -f1-3 /proc/loadavg)"
DEBUG=pw:browser node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:dark" wheel 2>>$OUT/browser-stderr-1.log
DEBUG=pw:browser node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:light" wheel 2>>$OUT/browser-stderr-2.log
DEBUG=pw:browser node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:dark" wheel 2>>$OUT/browser-stderr-3.log
echo "r8 done $(date -u +%T)"
DEBUG=pw:browser node $P http://localhost:5301 b39202f $OUT "844x390@200:dark" wheel 2>>$OUT/browser-stderr-4.log
echo "end $(date -u +%T) load $(cut -d' ' -f1-3 /proc/loadavg)"
# disclosure 5: the constructed two-action-toast case at 375x667 @200 (update prompt + synthetic Undo toast + Cozy) at the panel's end,
# then a REAL touch drag on the stack and a real tap on Undo if it comes on top. R8, b39202f, INT.
D=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round8-review/LEAD/runs/dockcheck
SYNTH_UNDO=1 node .tmp/LEAD8/dockcheck2.mjs http://localhost:5306 9ff0d04 $D "375x667@200:light" over
SYNTH_UNDO=1 node .tmp/LEAD8/dockcheck2.mjs http://localhost:5301 b39202f $D "375x667@200:light" over
SYNTH_UNDO=1 node .tmp/LEAD8/dockcheck2.mjs http://localhost:5303 0d58c5e $D "375x667@200:light" over
echo "synth done $(date -u +%T)"
# sheet comparisons: the Ambience sheet opened over 3 toasts during the break (control and INT for the R8 rows)
node .tmp/LEAD8/dockcheck.mjs http://localhost:5301 b39202f $D "844x390@200:dark" sheet
node .tmp/LEAD8/dockcheck.mjs http://localhost:5303 0d58c5e $D "667x375@200:light,844x390@200:dark" sheet
echo "sheet-ctl done $(date -u +%T)"

# 1440 @200 summary: R8 showed a toast rect over a "Done" control (undocked path) — control and INT
node .tmp/LEAD8/dockcheck.mjs http://localhost:5301 b39202f $D "1440x900@200:light" summary
node .tmp/LEAD8/dockcheck.mjs http://localhost:5303 0d58c5e $D "1440x900@200:light" summary
echo "summary1440 done $(date -u +%T)"

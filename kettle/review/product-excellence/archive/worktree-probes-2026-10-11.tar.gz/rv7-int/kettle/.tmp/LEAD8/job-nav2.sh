#!/bin/bash
# LEAD8: accept-nav2.mjs (accept-nav + JS-liveness checks after the error) on R8 844x390 @200 wheel, 2 in parallel x 2
cd /home/user/wt/rv7-int/kettle
OUT=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round8-review/LEAD/runs/navdiag2
P=.tmp/LEAD8/accept-nav2.mjs
echo "start $(date -u +%T) sha $(sha256sum $P | cut -c1-12) load $(cut -d' ' -f1-3 /proc/loadavg)"
( node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:dark" wheel; node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:dark" wheel ) > $OUT/a.txt 2>&1 &
( node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:light" wheel; node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:dark" wheel ) > $OUT/b.txt 2>&1 &
wait
echo "end $(date -u +%T) load $(cut -d' ' -f1-3 /proc/loadavg)"

// LEAD2 r7 probe: what the screen-reader live regions actually say in the storage-full End-early flow, from page load.
// An init script (runs on every load) records, from DOMContentLoaded on: every text change inside any live region
// ([aria-live] not off, role=status, role=alert) with its text and the location hash; every add/remove of the warning
// presenter (R7 banner/note [data-save-warning]; INT toast li#toast-kettle:save-failed); every toast added.
// Flows (storage really full, filled with localStorage filler keys = setup):
//   dbg  : as Lane A's natural-a2 setup: seed newbie + reload, leaves one below a level-up, fill, startFocus (debug),
//          ff 12 min, end('user') (debug).
//   real : onboarded empty profile, fill, REAL tap on "Put the kettle on", ff 12 min (debug: time only), REAL tap on
//          End session, REAL tap on the sheet's End session.
// No scrollIntoView / scrollTo / scrollBy / scrollTop writes.
//   node saidlog.mjs <base> <rev> <out> "375x667@200:light" <flow dbg|real> <reps>
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, cfgArg, flow = 'dbg', repsArg = '5'] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cfgs = cfgArg.split(',').map((c) => { const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); return { W: +m[1], H: +m[2], text: +m[3], theme: m[4] }; });
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const INIT = () => {
  const L = (window.__L2 = { t0: performance.now(), log: [] });
  const t = () => Math.round(performance.now() - L.t0);
  const liveOf = (n) => (n?.nodeType === 1 ? n : n?.parentElement)?.closest?.('[aria-live]:not([aria-live="off"]), [role="status"], [role="alert"]');
  const start = () => {
    const seen = new Map();
    new MutationObserver((ms) => {
      const touched = new Set();
      for (const m of ms) {
        const lv = liveOf(m.target);
        if (lv) touched.add(lv);
        for (const n of m.addedNodes) {
          const l2 = liveOf(n); if (l2) touched.add(l2);
          if (n.nodeType !== 1) continue;
          if (n.matches?.('[data-save-warning]') || n.querySelector?.('[data-save-warning]')) L.log.push([t(), location.hash, '+W', n.tagName, (n.textContent || '').slice(0, 40)]);
          if (n.id === 'toast-kettle:save-failed') L.log.push([t(), location.hash, '+W', 'toast', (n.textContent || '').slice(0, 40)]);
          if (n.tagName === 'LI' && n.closest?.('[aria-label="Notifications"]')) L.log.push([t(), location.hash, '+toast', n.id, (n.textContent || '').slice(0, 70)]);
        }
        for (const n of m.removedNodes) {
          if (n.nodeType !== 1) continue;
          if (n.matches?.('[data-save-warning]') || n.querySelector?.('[data-save-warning]') || n.id === 'toast-kettle:save-failed') L.log.push([t(), location.hash, '-W', n.tagName || n.id]);
        }
      }
      for (const lv of touched) {
        const txt = (lv.textContent || '').trim();
        const key = lv.id || lv.getAttribute('aria-label') || lv.className;
        if (txt && seen.get(lv) !== txt) L.log.push([t(), location.hash, 'SAY', key, txt.slice(0, 200)]);
        seen.set(lv, txt);
      }
    }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  };
  if (document.documentElement) start(); else addEventListener('DOMContentLoaded', start);
};
for (const { W, H, text, theme } of cfgs) {
  const phone = W < 900;
  for (let rep = 1; rep <= Number(repsArg); rep++) {
    const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: phone ? 2 : 1, isMobile: phone, hasTouch: phone, colorScheme: theme });
    await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
    if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
    await ctx.addInitScript(INIT);
    const page = await ctx.newPage();
    const errors = []; page.on('pageerror', (e) => errors.push(e.message));
    const row = { rev, base, W, H, text, theme, flow, rep, utc: new Date().toISOString() };
    const tap = async (loc) => { const b = await loc.boundingBox(); const x = b.x + b.width / 2, y = b.y + b.height / 2; if (phone) await page.touchscreen.tap(x, y); else await page.mouse.click(x, y); return [Math.round(x), Math.round(y)]; };
    try {
      const ready = () => page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60_000 });
      await page.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`);
      await ready();
      if (flow === 'dbg') {
        await page.evaluate(() => window.__kettle.seed('newbie'));
        await page.reload(); await ready();
        await page.evaluate(() => document.fonts.ready);
        await page.evaluate(async () => { const { leavesForLevel, levelFromLeaves } = await import('/src/progress/levels.ts'); const L = levelFromLeaves(window.__kettle.progress.getState().leaves).level; window.__kettle.progress.setState({ leaves: leavesForLevel(L + 1) - 1 }); });
      } else { await page.evaluate(() => document.fonts.ready); await sleep(800); }
      row.fillAt = await page.evaluate(() => Math.round(performance.now() - window.__L2.t0));
      row.quota = await page.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; } });
      if (flow === 'dbg') await page.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
      else row.startTap = await tap(page.getByRole('button', { name: /^Put the kettle on/ }));
      row.startAt = await page.evaluate(() => Math.round(performance.now() - window.__L2.t0));
      await page.waitForFunction(() => location.hash === '#/focus');
      await sleep(2500);
      await page.evaluate(() => window.__kettle.ff(12 * 60_000 + 5_000));
      await sleep(800);
      row.endAt = await page.evaluate(() => Math.round(performance.now() - window.__L2.t0));
      if (flow === 'dbg') await page.evaluate(() => window.__kettle.timer.getState().end('user'));
      else {
        row.endTap = await tap(page.getByRole('button', { name: 'End session' }).first());
        const dlg = page.getByRole('dialog', { name: /Leave the kettle early/ });
        await dlg.waitFor({ state: 'visible' }); await sleep(600);
        row.sheetText = (await dlg.innerText()).replace(/\s+/g, ' ').slice(0, 200);
        row.sheetTap = await tap(dlg.getByRole('button', { name: 'End session' }));
      }
      await page.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 20_000 });
      await sleep(4500);
      await page.screenshot({ path: `${out}/${rev}-${W}x${H}-t${text}-${theme}-${flow}-r${rep}.png` });
      const L = await page.evaluate(() => window.__L2.log);
      row.log = L;
      row.saysWarning = L.filter((e) => e[2] === 'SAY' && /storage is full|couldn’t save|can’t save/.test(e[4]));
      row.warnAdds = L.filter((e) => e[2] === '+W');
      row.banner = await page.evaluate(() => { const b = document.querySelector('section[data-save-warning]'); if (!b) return null; const r = b.getBoundingClientRect(); return { top: Math.round(r.top), bottom: Math.round(r.bottom), H: innerHeight, scrollY: Math.round(scrollY) }; });
    } catch (e) { row.error = String(e.message).split('\n')[0]; }
    row.errors = errors.slice(0, 3);
    appendFileSync(`${out}/saidlog-${rev}.jsonl`, JSON.stringify(row) + '\n');
    const brief = { ...row }; delete brief.log;
    console.log(JSON.stringify(brief));
    await ctx.close();
  }
}
await browser.close();

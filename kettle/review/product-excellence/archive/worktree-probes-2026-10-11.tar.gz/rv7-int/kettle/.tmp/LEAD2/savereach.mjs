// LEAD2 r7 probe: can "Save backup" in the storage-full warning be reached at a landscape phone size at large text, by
// REAL keyboard (Tab from the top of Today) and by REAL touch (CDP drags of 24 px on the scrolling content)?
// Works on both designs: R7 banner (section[data-save-warning] button "Save backup") and INT toast
// (li#toast-kettle:save-failed, action "Save backup").
// Setup (debug API / storage, labelled): onboarded empty profile, a 3-min brew (debug ff) ended so Today has content,
// End toasts left to expire on their real timers, localStorage filled to QuotaExceededError, then a real tap on a tag
// is filled before End (setup), so End's own save fails and the warning is on Today when it opens.
// Reached = Save backup's whole box inside the viewport AND elementFromPoint at its centre is Save backup (nothing on
// top: not the docked start, not a toast).
// No scrollIntoView / scrollTo / scrollBy / scrollTop writes; focus scrolling is the browser's own.
//   node savereach.mjs <base> <rev> <out> "667x375@200:light,..." <how key|touch>
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, cfgArg, how = 'key'] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cfgs = cfgArg.split(',').map((c) => { const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); return { W: +m[1], H: +m[2], text: +m[3], theme: m[4] }; });
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const SB = () => {
  const ban = document.querySelector('section[data-save-warning]');
  const host = ban ?? document.getElementById('toast-kettle:save-failed');
  if (!host) return { present: false };
  const b = [...host.querySelectorAll('button')].find((x) => /Save backup/.test(x.textContent));
  if (!b) return { present: true, button: false, kind: ban ? 'banner' : 'toast' };
  const r = b.getBoundingClientRect();
  const whole = r.top >= 0 && r.bottom <= innerHeight && r.left >= 0 && r.right <= innerWidth && r.height > 0;
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  const h = cy >= 0 && cy < innerHeight ? document.elementFromPoint(cx, cy) : null;
  const hitOk = !!h && b.contains(h);
  const on = h && !hitOk ? (h.closest('button')?.textContent || h.tagName).slice(0, 30) : null;
  return { present: true, button: true, kind: ban ? 'banner' : 'toast', top: Math.round(r.top), bottom: Math.round(r.bottom), whole, hitOk, on, focused: document.activeElement === b, scrollY: Math.round(scrollY) };
};
for (const { W, H, text, theme } of cfgs) {
  const phone = W < 900;
  const tag = `${rev}-${W}x${H}-t${text}-${theme}-${how}`;
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: phone ? 2 : 1, isMobile: phone, hasTouch: phone, colorScheme: theme });
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message));
  const cdp = phone ? await ctx.newCDPSession(page) : null;
  const row = { rev, base, W, H, text, theme, how, utc: new Date().toISOString(), steps: [] };
  try {
    const ready = () => page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60_000 });
    await page.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`); await ready();
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await page.waitForFunction(() => location.hash === '#/focus'); await sleep(1200);
    await page.evaluate(() => window.__kettle.ff(3 * 60_000)); await sleep(300);
    // Storage really full BEFORE End (setup), so End's own save is the first to fail and the warning is on Today.
    row.quota = await page.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; } });
    await page.evaluate(() => window.__kettle.timer.getState().end('user'));
    await page.waitForFunction(() => location.hash === '#/' || location.hash === '');
    await page.waitForFunction(() => !!(document.querySelector('section[data-save-warning]') || document.getElementById('toast-kettle:save-failed')), null, { timeout: 8000 }).catch(() => {});
    // Ordinary End toasts expire on their real timers (the INT warning toast, if any, is kept by the probe's wait only).
    await page.waitForFunction(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].every((li) => li.id === 'toast-kettle:save-failed'), null, { timeout: 15_000 }).catch(() => {});
    await sleep(500);
    row.start = await page.evaluate(SB);
    if (!row.start.present) throw new Error('no warning shown after storage filled');
    if (how === 'key') {
      // From the top of the page: focus the skip link's target area by a real click on the greeting? Use Tab from body.
      await page.evaluate(() => { document.activeElement?.blur?.(); });
      for (let i = 1; i <= 60; i++) {
        await page.keyboard.press('Tab'); await sleep(260);
        const s = await page.evaluate(SB);
        const fe = await page.evaluate(() => (document.activeElement?.getAttribute('aria-label') || document.activeElement?.textContent || document.activeElement?.tagName || '').replace(/\s+/g, ' ').slice(0, 28));
        row.steps.push([i, fe, s.top, s.bottom, s.whole ? 1 : 0, s.hitOk ? 1 : 0, s.on]);
        if (s.focused) { row.reachedAt = i; row.atFocus = s; break; }
      }
    } else {
      // Real touch drags (24 px) on the content column, down until Save backup is whole + hit, or nothing moves.
      for (let i = 1; i <= 120; i++) {
        const s = await page.evaluate(SB);
        row.steps.push([i, s.top, s.bottom, s.whole ? 1 : 0, s.hitOk ? 1 : 0, s.on, s.scrollY]);
        if (s.whole && s.hitOk) { row.reachedAt = i; row.atReach = s; break; }
        const dir = s.top > H / 2 || s.bottom > H ? 1 : -1;
        const aim = await page.evaluate(() => { const c = document.querySelector('section[data-save-warning]') ?? document.querySelector('main'); const r = c.getBoundingClientRect(); return { x: Math.round(r.left + r.width / 2) }; });
        const y0 = Math.round(H * 0.45), span = 24 * dir, n = 6;
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: aim.x, y: y0 }] });
        for (let k = 1; k <= n; k++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: aim.x, y: Math.round(y0 - (span * k) / n) }] }); await sleep(20); }
        await sleep(120);
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await sleep(380);
      }
    }
    await page.screenshot({ path: `${out}/${tag}.png` });
    row.end = await page.evaluate(SB);
  } catch (e) { row.error = String(e.message).split('\n')[0]; }
  row.errors = errors.slice(0, 3);
  appendFileSync(`${out}/savereach-${rev}.jsonl`, JSON.stringify(row) + '\n');
  console.log(JSON.stringify({ ...row, steps: row.steps.length }));
  await ctx.close();
}
await browser.close();

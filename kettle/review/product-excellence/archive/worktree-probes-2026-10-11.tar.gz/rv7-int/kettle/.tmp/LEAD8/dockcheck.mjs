// LEAD8 (round-8 lead Checker) probe: the round-8 toast dock / fold, its disclosures and the new risks of its diff.
// Scenarios (each in a fresh context, fresh profile; debug API for setup only; toasts through the app's own toast(),
// labelled setup; scrolls and taps by REAL input only: mouse wheel, CDP touch drags/taps, mouse clicks):
//   over   : Break's over with a carried task (Tea time by a REAL tap). Panel top: raise the update prompt
//            (PwaUpdatePrompt's shape: id pwa-update, icon sparkle, duration Infinity, action Update) -> n1, + "Cozy level 5!"
//            -> n2, + 'Marked "Chapter 3 notes" done · Undo' -> n3. Extras dismissed (setup). REAL wheel to the panel's end
//            -> n1; extras raised again -> n2, n3; then a REAL touch drag (phones) / wheel (desktop) on the toast stack
//            -> n3+drag; REAL tap/click on Undo (activation by counter). Extras dismissed; REAL wheel back to top -> n1.
//   summary: the brew's summary (after finish, before Tea time). Raise update + Cozy + Undo; sample; REAL wheel on the
//            summary to its end; sample.
//   focus  : a brew running. n1..n3 (ordinary + Undo); sample (what the toasts cover).
//   sheet  : Tea break running. n3 raised; REAL tap on Ambience; per-frame for 1.6 s: every dialog button's centre
//            hit-tests to itself and no painted toast overlaps it; docked state per frame. Escape.
// Every sample: docked?, region rect, list clip, per toast: box, own (scrollHeight), visible px, folded, icon shown,
// message clamped, action on top at its centre, top-bar words under it; page text / controls under the visible toasts;
// live-region mutation counts (li additions, characterData, other childList) since the first toast.
//   node dockcheck.mjs <base> <rev> <out> "667x375@100:light,..." <scenario over|summary|focus|sheet>
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, cfgArg, scen = 'over'] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cfgs = cfgArg.split(',').map((c) => { const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); return { W: +m[1], H: +m[2], text: +m[3], theme: m[4] }; });
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });

const INSTALL = () => {
  const w = window;
  w.__lr = { li: 0, text: 0, other: 0 };
  new MutationObserver((ms) => {
    for (const m of ms) {
      const live = document.querySelector('[aria-label="Notifications"]');
      if (!live || !live.contains(m.target)) continue;
      if (m.type === 'characterData') w.__lr.text++;
      else if (m.type === 'childList') for (const n of m.addedNodes) { if (n.nodeType === 1 && n.tagName === 'LI') w.__lr.li++; else w.__lr.other++; }
    }
  }).observe(document.body, { subtree: true, childList: true, characterData: true });
  w.__upd = 0; w.__undo = 0;
};
const SAMPLE = () => {
  const live = document.querySelector('[aria-label="Notifications"]');
  const region = live?.parentElement;
  const ol = live?.querySelector('ol');
  const clip = ol && getComputedStyle(ol).overflowY !== 'visible' ? ol.getBoundingClientRect() : null;
  const rr = region?.getBoundingClientRect();
  const hdr = document.querySelector('[data-focus-view] header');
  const leafText = (root) => [...root.querySelectorAll('*')].filter((e) => e.children.length === 0 && (e.textContent || '').trim() && !e.closest('[aria-label="Notifications"]')).map((e) => ({ t: (e.textContent || '').trim().slice(0, 18), q: e.getBoundingClientRect() })).filter((x) => x.q.width > 0 && x.q.height > 0 && x.q.bottom > 0 && x.q.top < innerHeight);
  const words = hdr ? leafText(hdr) : [];
  const toasts = [...(ol?.children ?? [])].map((li) => {
    const q = li.getBoundingClientRect();
    const t = Math.max(q.top, 0, clip ? clip.top : 0), b = Math.min(q.bottom, innerHeight, clip ? clip.bottom : innerHeight);
    const l = Math.max(q.left, 0), r = Math.min(q.right, innerWidth);
    const act = li.querySelector('button');
    let actOnTop = null;
    if (act) { const a = act.getBoundingClientRect(); const cx = a.left + a.width / 2, cy = a.top + a.height / 2; const h = cy >= 0 && cy < innerHeight ? document.elementFromPoint(cx, cy) : null; actOnTop = !!h && act.contains(h); }
    const spans = li.querySelectorAll(':scope > span');
    const icon = spans[0], msg = spans[1];
    let op = 1; for (let e = li; e && e !== document.documentElement; e = e.parentElement) op *= +getComputedStyle(e).opacity;
    const vis = Math.max(0, Math.round(b - t));
    return { txt: (li.textContent || '').slice(0, 22), box: Math.round(q.height), own: li.scrollHeight, vis, rect: [Math.round(l), Math.round(t), Math.round(r), Math.round(b)], folded: li.hasAttribute('data-folded'), iconShown: icon ? getComputedStyle(icon).display !== 'none' : null, msgClamped: msg ? msg.scrollHeight > msg.clientHeight + 1 : null, actOnTop, op: +op.toFixed(2), overBar: vis > 0 ? words.filter((x) => r > x.q.left + 1 && l < x.q.right - 1 && t < x.q.bottom - 1 && b > x.q.top + 1).map((x) => x.t) : [] };
  });
  const vis = toasts.filter((x) => x.vis > 0 && x.op > 0.05).map((x) => x.rect);
  const hits = (q) => vis.some(([l, t, r, b]) => q.right > l + 1 && q.left < r - 1 && q.bottom > t + 1 && q.top < b - 1);
  const underText = [...new Set(leafText(document.body).filter((x) => hits(x.q)).map((x) => x.t))].slice(0, 12);
  const underCtl = [...document.querySelectorAll('button, a[href], input, select, textarea, [role="button"]')].filter((c) => !c.closest('[aria-label="Notifications"]') && !c.closest('[aria-hidden="true"],[inert]')).filter((c) => { const q = c.getBoundingClientRect(); return q.width > 0 && q.height > 0 && hits(q); }).map((c) => (c.getAttribute('aria-label') || c.textContent || '').trim().slice(0, 18));
  const m = document.querySelector('[data-focus-view] main');
  const st = document.querySelector('[data-toast-dock]')?.getBoundingClientRect();
  return { docked: !!region?.hasAttribute('data-docked'), region: rr ? [rr.left, rr.top, rr.right, rr.bottom].map(Math.round) : null, clip: clip ? [Math.round(clip.top), Math.round(clip.bottom)] : null, stage: st ? [st.left, st.top, st.right, st.bottom].map(Math.round) : null, panel: m ? `${Math.round(m.scrollTop)}/${m.scrollHeight - m.clientHeight}` : null, toasts, underText, underCtl, lr: { ...window.__lr }, upd: window.__upd, undo: window.__undo };
};
const UPDATE = async () => { const { toast } = await import('/src/ui/Toast.tsx'); toast('A fresh brew of Kettle is ready.', { id: 'pwa-update', icon: 'sparkle', duration: Infinity, action: { label: 'Update', onClick: () => window.__upd++ } }); };
const COZY = async () => { const { toast } = await import('/src/ui/Toast.tsx'); toast('Cozy level 5!', { id: 'cozy', tone: 'success', duration: 9000 }); };
const UNDO = async () => { const { toast } = await import('/src/ui/Toast.tsx'); toast('Marked “Chapter 3 notes” done', { id: 'undo', tone: 'success', duration: 9000, action: { label: 'Undo', onClick: () => window.__undo++ } }); };
const DROP = async () => { const { toast } = await import('/src/ui/Toast.tsx'); toast.dismiss('cozy'); toast.dismiss('undo'); };
const DROPALL = async () => (await import('/src/ui/Toast.tsx')).toast.dismiss();

for (const { W, H, text, theme } of cfgs) {
  const phone = W < 900;
  const tag = `${rev}-${W}x${H}-t${text}-${theme}-${scen}`;
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: phone ? 2 : 1, isMobile: phone, hasTouch: phone, colorScheme: theme });
  await ctx.addInitScript(() => { window.__werr = []; addEventListener('error', (e) => { try { window.__werr.push(String(e.message || e.error || e.type).slice(0, 80)); } catch {} }, true); });
  await ctx.addInitScript((pct) => {
    try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {}
    if (pct !== 100) addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); });
  }, text);
  const page = await ctx.newPage();
  const cdp = phone ? await ctx.newCDPSession(page) : null;
  const errors = []; page.on('pageerror', (e) => errors.push(e.message));
  let navs = 0; page.on('framenavigated', (f) => { if (f === page.mainFrame()) navs++; });
  const row = { rev, base, W, H, text, theme, scen, utc: new Date().toISOString(), samples: [] };
  const S = async (label, shot) => { const s = await page.evaluate(SAMPLE); row.samples.push([label, s]); if (shot) await page.screenshot({ path: `${out}/${tag}-${label.replace(/[^a-z0-9]+/gi, '_')}.jpg`, type: 'jpeg', quality: 80 }); return s; };
  const wheelPanel = async (dir) => { for (let i = 0; i < 16; i++) { const aim = await page.evaluate(() => { const r = document.querySelector('[data-focus-view] main').getBoundingClientRect(); return { x: Math.round(r.right - 24), y: Math.round(Math.min(innerHeight, r.bottom) - 16) }; }); const before = await page.evaluate(() => document.querySelector('[data-focus-view] main').scrollTop); await page.mouse.move(aim.x, aim.y); await page.mouse.wheel(0, 100 * dir); await sleep(220); const after = await page.evaluate(() => document.querySelector('[data-focus-view] main').scrollTop); if (Math.abs(after - before) < 1) break; } };
  const touchDrag = async (x, y0, y1) => { const steps = 8; await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y: y0 }] }); for (let i = 1; i <= steps; i++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: Math.round(y0 + ((y1 - y0) * i) / steps) }] }); await sleep(16); } await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); };
  const realTapAt = async (x, y) => { if (cdp) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: Math.round(x), y: Math.round(y) }] }); await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); } else await page.mouse.click(x, y); };
  try {
    await page.goto(`${base}/?debug&seed=newbie&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`);
    await page.waitForFunction(() => !!window.__kettle, null, { timeout: 60_000 });
    await page.evaluate(() => document.fonts.ready); await sleep(900);
    await page.evaluate(INSTALL);
    await page.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await sleep(1600);
    if (scen === 'focus') {
      await page.mouse.move(5, 5); await sleep(200);
      await page.evaluate(UPDATE); await sleep(900); await S('focus n1');
      await page.evaluate(COZY); await sleep(900); await S('focus n2');
      await page.evaluate(UNDO); await sleep(900); await S('focus n3', true);
    } else {
      await page.evaluate(() => window.__kettle.nearEnd()); await sleep(400); await page.evaluate(() => window.__kettle.finish());
      const tea = page.getByRole('button', { name: /Tea time|Long tea break/ });
      await tea.waitFor({ state: 'visible', timeout: 60_000 }); await sleep(3800);
      if (scen === 'summary') {
        await page.evaluate(DROPALL); await sleep(700);
        await page.evaluate(UPDATE); await page.evaluate(COZY); await page.evaluate(UNDO); await sleep(1000);
        await S('summary n3 top', true);
        // REAL wheel on the summary card (the panel scrolls at large text) to its end
        for (let i = 0; i < 16; i++) { const b = await tea.boundingBox(); const before = await page.evaluate(() => document.querySelector('[data-focus-view] main').scrollTop); await page.mouse.move(Math.round(b.x + b.width / 2), Math.round(b.y - 30)); await page.mouse.wheel(0, 100); await sleep(220); const after = await page.evaluate(() => document.querySelector('[data-focus-view] main').scrollTop); if (Math.abs(after - before) < 1) break; }
        await sleep(500); await S('summary n3 end', true);
      } else {
        const b = await tea.boundingBox();
        await realTapAt(b.x + b.width / 2, b.y + b.height / 2);
        await page.getByRole('button', { name: 'Pause break' }).waitFor({ state: 'attached', timeout: 20_000 });
        await sleep(3800);
        await page.evaluate(DROPALL); await sleep(700);
        if (scen === 'sheet') {
          await page.evaluate(UPDATE); await page.evaluate(COZY); await page.evaluate(UNDO); await sleep(1000);
          await S('break n3', true);
          const amb = page.getByRole('button', { name: /^Ambience:/ });
          const ab = await amb.boundingBox();
          await page.evaluate(() => {
            const R = (window.__sf = { frames: [], stop: false, t0: performance.now() });
            const f = () => {
              if (R.stop) return;
              const d = document.querySelector('[role="dialog"]');
              const ol = document.querySelector('[aria-label="Notifications"] ol');
              const clip = ol && getComputedStyle(ol).overflowY !== 'visible' ? ol.getBoundingClientRect() : null;
              const tb = [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => { const q = li.getBoundingClientRect(); let op = 1; for (let e = li; e && e !== document.documentElement; e = e.parentElement) op *= +getComputedStyle(e).opacity; return { l: q.left, t: Math.max(q.top, clip ? clip.top : -1e9), r: q.right, b: Math.min(q.bottom, clip ? clip.bottom : 1e9), op }; }).filter((x) => x.b > x.t && x.op > 0.05);
              let cov = 0, n = 0; const who = [];
              if (d) for (const btn of d.querySelectorAll('button')) { const q = btn.getBoundingClientRect(); if (q.width <= 0 || q.bottom <= 0 || q.top >= innerHeight) continue; n++; const h = document.elementFromPoint(q.left + q.width / 2, Math.min(innerHeight - 1, Math.max(0, q.top + q.height / 2))); const under = tb.some((o) => o.r > q.left + 1 && o.l < q.right - 1 && o.b > q.top + 1 && o.t < q.bottom - 1); if (!(h && btn.contains(h)) || under) { cov++; who.push((btn.getAttribute('aria-label') || btn.textContent || '').trim().slice(0, 14) + (under ? '[T]' : '[hit]')); } }
              R.frames.push({ t: Math.round(performance.now() - R.t0), dialog: !!d, docked: !!document.querySelector('[aria-label="Notifications"]')?.parentElement?.hasAttribute('data-docked'), n, cov, who: who.slice(0, 4) });
              requestAnimationFrame(f);
            };
            requestAnimationFrame(f);
          });
          await realTapAt(ab.x + ab.width / 2, ab.y + ab.height / 2);
          await sleep(1600);
          const fr = await page.evaluate(() => { window.__sf.stop = true; return window.__sf.frames; });
          row.sheet = { frames: fr.length, dialogFrames: fr.filter((f) => f.dialog).length, covFrames: fr.filter((f) => f.cov > 0).length, dockedFrames: fr.filter((f) => f.docked).length, dockedWithDialog: fr.filter((f) => f.docked && f.dialog).length, firstDialogT: fr.find((f) => f.dialog)?.t ?? null, lastDockedWithDialogT: fr.filter((f) => f.docked && f.dialog).map((f) => f.t).pop() ?? null, covWho: [...new Set(fr.flatMap((f) => f.who))] };
          await S('sheet open', true);
          await page.keyboard.press('Escape'); await sleep(800);
          await S('sheet closed');
        } else {
          await page.evaluate(() => window.__kettle.finish());
          await page.getByRole('button', { name: /Put the kettle on/ }).waitFor({ state: 'attached' });
          await sleep(3800); await page.evaluate(DROPALL); await sleep(700);
          await page.evaluate(UPDATE); await sleep(900); await S('top n1', true);
          await page.evaluate(COZY); await sleep(900); await S('top n2', true);
          await page.evaluate(UNDO); await sleep(900); await S('top n3', true);
          await page.evaluate(DROP); await sleep(700);
          await wheelPanel(1); await sleep(800); await S('end n1', true);
          // n2: a REAL tap on "Mark it done" (the app's own toast with Undo); where it cannot be hit (INT: below the edge),
          // the Undo toast is raised through toast() instead (labelled in the row).
          const md = await page.evaluate(() => { const b = [...document.querySelectorAll('[data-focus-view] main button')].find((x) => /^Mark it done/.test((x.textContent || '').replace(/\s+/g, ' ').trim())); if (!b) return null; const q = b.getBoundingClientRect(); const m = document.querySelector('[data-focus-view] main').getBoundingClientRect(); const t = Math.max(q.top, m.top, 0), bo = Math.min(q.bottom, m.bottom, innerHeight); if (bo - t < 12) return { off: true }; const x = q.left + q.width / 2, y = (t + bo) / 2; const h = document.elementFromPoint(x, y); return { x, y, hit: !!h && b.contains(h) }; });
          if (md && md.hit) { await realTapAt(md.x, md.y); row.markDone = 'real tap'; } else { await page.evaluate(UNDO); row.markDone = `toast() (Mark it done ${md ? (md.off ? 'off screen' : 'not hit-testable') : 'missing'})`; }
          await sleep(900); await S('end n2', true);
          await page.evaluate(COZY); await sleep(900); const e3 = await S('end n3', true);
          // the stack itself scrolled by REAL input, aimed at the visible part of the lowest visible toast (not an action)
          const vis = e3.toasts.filter((x) => x.vis > 20);
          if (vis.length) {
            const lo = vis.reduce((a, b2) => (b2.rect[3] > a.rect[3] ? b2 : a));
            const x = Math.round((lo.rect[0] + lo.rect[2]) / 2) - 40, y0 = lo.rect[3] - 8, y1 = Math.max(lo.rect[1] - 60, 4);
            if (cdp) await touchDrag(x, y0, y1); else { await page.mouse.move(x, y0); await page.mouse.wheel(0, 120); }
            await sleep(700);
          }
          const d3 = await S('end n3 +stack drag', true);
          const ul = page.locator('[aria-label="Notifications"] li', { has: page.locator('button', { hasText: /^Undo$/ }) });
          if (await ul.count()) {
            const onTop = await ul.first().evaluate((li) => { const a = li.querySelector('button').getBoundingClientRect(); const h = document.elementFromPoint(a.left + a.width / 2, a.top + a.height / 2); return !!h && li.querySelector('button').contains(h); });
            const before = await page.evaluate(() => ({ undo: window.__undo, md: [...document.querySelectorAll('[data-focus-view] main button')].filter((x) => /^Mark it done/.test((x.textContent || '').trim())).length, txt: [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.textContent.slice(0, 16)) }));
            const ub = await ul.first().locator('button').boundingBox();
            if (ub && onTop) { await realTapAt(ub.x + ub.width / 2, ub.y + ub.height / 2); await sleep(700); }
            const after = await page.evaluate(() => ({ undo: window.__undo, md: [...document.querySelectorAll('[data-focus-view] main button')].filter((x) => /^Mark it done/.test((x.textContent || '').trim())).length, txt: [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.textContent.slice(0, 16)) }));
            row.undoTap = { onTop, tapped: !!(ub && onTop), before, after };
          }
          await page.evaluate(DROP); await sleep(700);
          await wheelPanel(-1); await sleep(800); await S('back top n1', true);
          // Update by REAL input at the end of the run
          const ubx = await page.locator('[aria-label="Notifications"] li button', { hasText: 'Update' }).boundingBox();
          const s2 = row.samples[row.samples.length - 1][1];
          const ut = s2.toasts.find((x) => /fresh brew/.test(x.txt));
          if (ubx && ut?.actOnTop) { await realTapAt(ubx.x + ubx.width / 2, ubx.y + ubx.height / 2); await sleep(500); }
          row.updateTap = { onTop: ut?.actOnTop ?? null, activated: await page.evaluate(() => window.__upd) };
        }
      }
    }
  } catch (e) { row.error = String(e.message).split('\n')[0]; }
  row.errors = errors.slice(0, 3); row.navs = navs;
  try { row.werr = await page.evaluate(() => { const c = {}; for (const m of window.__werr || []) c[m] = (c[m] || 0) + 1; return c; }); } catch (e) { row.werr = 'n/a: ' + String(e.message).slice(0, 60); }
  appendFileSync(`${out}/dockcheck-${rev}.jsonl`, JSON.stringify(row) + '\n');
  const brief = { tag, error: row.error, navs, werr: row.werr, undoTap: row.undoTap, updateTap: row.updateTap, sheet: row.sheet, samples: row.samples.map(([l, s]) => `${l}: ${s.docked ? 'DOCK' : 'room'} ${s.panel} clip${JSON.stringify(s.clip)} | ` + s.toasts.map((x) => `${x.txt.slice(0, 12)} ${x.box}/${x.own}/${x.vis}${x.folded ? ' F' : ''}${x.iconShown === false ? ' noicon' : ''}${x.actOnTop === false ? ' ACT-OFF' : x.actOnTop ? ' act' : ''}${x.overBar.length ? ' BAR:' + x.overBar.join('/') : ''}`).join('; ') + ` | under: ${s.underText.join('/')} ctl:${s.underCtl.join('/')} | lr ${JSON.stringify(s.lr)}`) };
  console.log(JSON.stringify(brief, null, 1));
  await ctx.close();
}
await browser.close();

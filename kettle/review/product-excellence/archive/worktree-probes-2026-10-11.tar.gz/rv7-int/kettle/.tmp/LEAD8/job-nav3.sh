#!/bin/bash
# LEAD8: accept-nav2.mjs under load (3 browsers at once) on R8 844x390 @200 wheel, 3 parallel x 2
cd /home/user/wt/rv7-int/kettle
OUT=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round8-review/LEAD/runs/navdiag3
P=.tmp/LEAD8/accept-nav2.mjs
echo "start $(date -u +%T) sha $(sha256sum $P | cut -c1-12) load $(cut -d' ' -f1-3 /proc/loadavg)"
for k in a b c; do ( node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:dark" wheel; node $P http://localhost:5306 9ff0d04 $OUT "844x390@200:light" wheel ) > $OUT/$k.txt 2>&1 & done
wait
echo "end $(date -u +%T) load $(cut -d' ' -f1-3 /proc/loadavg)"

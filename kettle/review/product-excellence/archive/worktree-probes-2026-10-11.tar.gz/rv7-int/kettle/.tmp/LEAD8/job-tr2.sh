#!/bin/bash
# LEAD8: toastroom2 (lead's r7 probe, unedited, sha 7123da04) on control b39202f :5301, R8 9ff0d04 :5306, INT 0d58c5e :5303
cd /home/user/wt/rv7-int/kettle
OUT=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round8-review/LEAD/runs/toastroom2
P=.tmp/LEAD8/toastroom2.mjs
echo "start $(date -u +%T) load $(cut -d' ' -f1-3 /proc/loadavg)"
node $P http://localhost:5301 b39202f $OUT "667x375@200:light,844x390@200:dark" update
echo "ctl done $(date -u +%T)"
node $P http://localhost:5306 9ff0d04 $OUT "667x375@200:light,667x375@200:dark,844x390@200:light,844x390@200:dark" update
echo "r8 update done $(date -u +%T)"
node $P http://localhost:5306 9ff0d04 $OUT "667x375@200:light,844x390@200:dark" arrive
echo "r8 arrive done $(date -u +%T)"
node $P http://localhost:5303 0d58c5e $OUT "667x375@200:light,844x390@200:dark" update
echo "end $(date -u +%T) load $(cut -d' ' -f1-3 /proc/loadavg)"

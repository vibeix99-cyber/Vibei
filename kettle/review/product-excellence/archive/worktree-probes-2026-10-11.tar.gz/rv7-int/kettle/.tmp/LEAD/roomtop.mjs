// LEAD r7 probe: where the toasts' room is on every screen (region inline style, region box, list box, the toast's
// box), one toast raised through the app's own toast() (real timers), measured 900 ms later. Screens: Today, Stats,
// Nook, Settings (navigate by real tap on the tab bar / rail), the brew (running), the summary, the tea break.
// Setup by the debug API (startFocus, nearEnd/finish); Tea time by a real tap.  node roomtop.mjs <base> <rev> <out> "375x667@100:light,..."
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, cfgArg] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cfgs = cfgArg.split(',').map((c) => { const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); return { W: +m[1], H: +m[2], text: +m[3], theme: m[4] }; });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const MEAS = () => {
  const live = document.querySelector('[aria-label="Notifications"]'); const region = live?.parentElement; const ol = live?.querySelector('ol'); const li = ol?.querySelector('li');
  const R = (e) => { if (!e) return null; const r = e.getBoundingClientRect(); return [Math.round(r.top), Math.round(r.bottom), Math.round(r.left), Math.round(r.right)]; };
  return { style: region?.getAttribute('style') || '', region: R(region), list: R(ol), toast: R(li), n: ol?.children.length ?? 0 };
};
const RAISE = async () => { const { toast } = await import('/src/ui/Toast.tsx'); toast('Recipe done: Take 2 full tea breaks · +15 leaves', { tone: 'success', duration: 6000 }); };
const DISMISS = async () => (await import('/src/ui/Toast.tsx')).toast.dismiss();
for (const { W, H, text, theme } of cfgs) {
  const phone = W < 900;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: phone ? 2 : 1, isMobile: phone, hasTouch: phone, colorScheme: theme });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage();
  const tap = async (loc) => { const bb = await loc.boundingBox(); const x = bb.x + bb.width / 2, y = bb.y + bb.height / 2; if (phone) await p.touchscreen.tap(x, y); else await p.mouse.click(x, y); };
  const row = { rev, W, H, text, theme, screens: {} };
  const at = async (name) => { await p.evaluate(DISMISS); await sleep(700); await p.evaluate(RAISE); await sleep(900); row.screens[name] = await p.evaluate(MEAS); };
  try {
    await p.goto(`${base}/?debug&seed=newbie&theme=${theme}#/`);
    await p.waitForFunction(() => !!window.__kettle, null, { timeout: 60_000 }); await p.evaluate(() => document.fonts.ready); await sleep(1200);
    await at('today');
    for (const n of ['Stats', 'Nook', 'Settings', 'Today']) {
      const l = p.getByRole('link', { name: n, exact: true }).or(p.getByRole('button', { name: n, exact: true })).first();
      await tap(l); await sleep(1300); if (n !== 'Today') await at(n.toLowerCase());
    }
    await p.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await p.waitForFunction(() => location.hash === '#/focus'); await sleep(1800);
    await at('brew');
    await p.evaluate(() => window.__kettle.nearEnd()); await p.waitForFunction(() => location.hash === '#/done', null, { timeout: 30_000 }); await sleep(2600);
    await at('summary');
    await tap(p.getByRole('button', { name: /Tea time|Long tea break/ }));
    await p.getByRole('button', { name: 'Pause break' }).waitFor({ state: 'attached', timeout: 20_000 }); await sleep(1500);
    await at('break');
  } catch (e) { row.error = String(e.message).split('\n')[0]; }
  appendFileSync(`${out}/roomtop-${rev}.jsonl`, JSON.stringify(row) + '\n');
  console.log(JSON.stringify(row));
  await ctx.close();
}
await b.close();

// LEAD2 r7 probe: at desktop 1440×900, after End early (debug end('user') after a 3-min brew from Today, as
// integrity.spec.ts:1090 does), sample every animation frame for 3 s from End: each toast's box, Mark done's box and
// whether elementFromPoint at Mark done's centre is Mark done or a toast. Same steps on R7 and INT (no storage fill).
// No input after End (measurement only).   node liftlag.mjs <base> <rev> <out> <reps>
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, repsArg = '4'] = process.argv;
mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
for (let rep = 1; rep <= Number(repsArg); rep++) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  await ctx.addInitScript(() => { try { if (localStorage.getItem('kettle:settings')) return; localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const page = await ctx.newPage();
  const row = { rev, base, rep, utc: new Date().toISOString() };
  try {
    row.load = (await import('node:fs')).readFileSync('/proc/loadavg', 'utf8').trim();
    await page.goto(`${base}/?debug#/`);
    await page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 30_000 });
    await page.getByRole('textbox', { name: /What are you brewing/ }).fill('Chapter 3 notes');
    await page.getByRole('button', { name: /^Put the kettle on · / }).click();
    await page.waitForFunction(() => location.hash === '#/focus');
    await page.evaluate(() => window.__kettle.ff(3 * 60_000));
    await page.evaluate(() => {
      const R = (window.__ll = { t0: performance.now(), f: [] });
      const tick = () => {
        const t = Math.round(performance.now() - R.t0);
        if (t > 3000) return;
        const md = document.querySelector('button[aria-label^="Mark “"]');
        const mr = md?.getBoundingClientRect();
        let hit = null;
        if (mr && mr.width > 0) { const h = document.elementFromPoint(mr.left + mr.width / 2, mr.top + mr.height / 2); hit = !h ? 'none' : md.contains(h) ? 'md' : h.closest('[aria-label="Notifications"] li') ? 'toast' : (h.tagName + '.' + (h.className || '')).slice(0, 30); }
        const ts = [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => { const q = li.getBoundingClientRect(); return [Math.round(q.top), Math.round(q.bottom)]; });
        R.f.push([t, location.hash, mr ? Math.round(mr.top + mr.height / 2) : null, hit, ts]);
        requestAnimationFrame(tick);
      };
      window.__kettle.timer.getState().end('user');
      requestAnimationFrame(tick);
    });
    await page.waitForTimeout(3300);
    const f = await page.evaluate(() => window.__ll.f);
    const toastHit = f.filter((x) => x[3] === 'toast');
    row.frames = f.length;
    row.firstMdFrame = f.find((x) => x[2] != null)?.[0] ?? null;
    row.toastOverMdFrames = toastHit.length;
    row.toastOverMdWindow = toastHit.length ? [toastHit[0][0], toastHit[toastHit.length - 1][0]] : null;
    row.sample = f.filter((_, i) => i % 6 === 0).slice(0, 30);
  } catch (e) { row.error = String(e.message).split('\n')[0]; }
  appendFileSync(`${out}/liftlag-${rev}.jsonl`, JSON.stringify(row) + '\n');
  const brief = { ...row }; delete brief.sample; console.log(JSON.stringify(brief));
  await ctx.close();
}
await browser.close();

// LEAD r7 probe: M1's storage-full behaviour through the banner, end to end, with real input for every user action
// (CDP touch taps on phones, mouse clicks on desktop, keyboard Tab); debug API for setup only (quota fill, freeing
// space = the person clearing other data, nearEnd clock jump). Real timers otherwise. Checks:
//  A Today, storage fine: no banner, announcer empty.
//  B Start a brew by a real tap; fill storage; real tap Pause (its save fails) → during the brew nothing presents the
//    warning (no banner/note/warning toast), every brew control hit-testable; real tap Resume.
//  C The brew reaches its end on the real clock after nearEnd → summary: the one-line note, no "saved" claim in the
//    note; Tea time / Skip break hit-testable; real tap Save backup → the downloaded file contains the unsaved brew.
//  D Real tap Skip break → Today: banner in flow (static, inside main), not a live region; announcer said exactly once.
//  E Real tap on the Settings tab → banner after "Reset everything"; real tap back to Today.
//  F Keyboard: from the top of Today, Tab until Save backup (count stops); DOM order check.
//  G Room again (filler removed): banner STAYS until the failed keys are saved again; then a real action that saves
//    (start a brew by real tap, End it via its sheet by real taps) → banner gone within 2.5 s of the saves.
//  H Reload: the brew finished while storage was full is in history (persisted after recovery); no banner.
//   node m1flow.mjs <base> <rev> <out> "390x844@100:light"
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync, readFileSync } from 'node:fs';
const [,, base, rev, out, cfgArg] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cfgs = cfgArg.split(',').map((c) => { const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); return { W: +m[1], H: +m[2], text: +m[3], theme: m[4] }; });
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
for (const { W, H, text, theme } of cfgs) {
  const phone = W < 900;
  const tag = `${rev}-${W}x${H}-t${text}-${theme}`;
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: phone ? 2 : 1, isMobile: phone, hasTouch: phone, colorScheme: theme, acceptDownloads: true });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage();
  const errors = []; p.on('pageerror', (e) => errors.push(e.message));
  const R = { tag, rev, base, steps: {} };
  const step = (k, v) => { R.steps[k] = v; console.log(tag, k, JSON.stringify(v)); };
  const tapEl = async (loc) => { const bb = await loc.boundingBox(); if (!bb) throw new Error('no box'); const x = bb.x + bb.width / 2, y = bb.y + bb.height / 2; const hit = await p.evaluate(([x, y]) => { const h = document.elementFromPoint(x, y); return h ? (h.closest('button,a,[role=button]')?.textContent || h.tagName).trim().slice(0, 40) : null; }, [x, y]); if (phone) await p.touchscreen.tap(x, y); else await p.mouse.click(x, y); return hit; };
  const state = () => p.evaluate(() => {
    const ban = document.querySelector('section[data-save-warning]'); const note = document.querySelector('p[data-save-warning]');
    const said = document.getElementById('kettle-save-warning-said');
    const warnToast = [...document.querySelectorAll('[aria-label="Notifications"] li')].filter((li) => /storage is full|couldn.t save/i.test(li.textContent)).length;
    const br = ban?.getBoundingClientRect();
    return { route: location.hash, banner: !!ban, bannerPos: ban ? getComputedStyle(ban).position : null, bannerInMain: !!ban?.closest('main'), bannerLive: ban ? (ban.closest('[aria-live]')?.getAttribute('aria-live') ?? 'none') : null, bannerTop: br ? Math.round(br.top) : null, note: note ? note.textContent : null, saidText: said?.textContent ?? null, saidLive: said?.getAttribute('aria-live'), warnToast, failing: window.__kettle ? null : null };
  });
  try {
    await p.exposeFunction('__said', () => {});
    await p.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`);
    await p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
    await p.evaluate(() => document.fonts.ready); await sleep(800);
    await p.evaluate(() => { const el = document.getElementById('kettle-save-warning-said'); window.__saidLog = []; if (el) new MutationObserver(() => el.textContent && window.__saidLog.push([Math.round(performance.now()), el.textContent.slice(0, 50)])).observe(el, { childList: true, characterData: true, subtree: true }); });
    step('A', await state());
    // B
    await p.getByRole('textbox', { name: /What are you brewing/ }).fill('Storage full brew');
    await sleep(400);
    step('B.startTapHit', await tapEl(p.getByRole('button', { name: /^Put the kettle on/ })));
    await p.waitForFunction(() => location.hash === '#/focus', null, { timeout: 15_000 }); await sleep(1500);
    step('B.quota', await p.evaluate(() => { let c = 'x'.repeat(1 << 20), k = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${k++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; } }));
    step('B.pauseTapHit', await tapEl(p.getByRole('button', { name: 'Pause', exact: true })));
    await sleep(900);
    const brew = await state();
    const hits = await p.evaluate(() => ['Add 5 minutes', 'Resume', 'End session'].map((n) => { const el = [...document.querySelectorAll('button')].find((b) => b.getAttribute('aria-label') === n || b.textContent.trim() === n); if (!el) return [n, 'missing']; const r = el.getBoundingClientRect(); const h = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return [n, h && el.contains(h) ? 'ok' : 'COVERED']; }));
    step('B.duringBrew', { ...brew, hits, failingWritesSoFar: await p.evaluate(() => window.__saidLog.length) });
    step('B.resumeTapHit', await tapEl(p.getByRole('button', { name: 'Resume', exact: true })));
    await sleep(600);
    // C
    await p.evaluate(() => window.__kettle.nearEnd());
    await p.waitForFunction(() => location.hash === '#/done', null, { timeout: 30_000 }); await sleep(2500);
    const sum = await state();
    const sumHits = await p.evaluate(() => [/^Tea time/, /^Skip break$/].map((re) => { const el = [...document.querySelectorAll('button')].find((b) => re.test((b.getAttribute('aria-label') || b.textContent).trim())); if (!el) return [String(re), 'missing']; const r = el.getBoundingClientRect(); const h = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return [String(re), h && el.contains(h) ? 'ok' : 'COVERED']; }));
    const sumText = await p.evaluate(() => document.querySelector('[data-focus-view]')?.innerText.replace(/\s+/g, ' ').slice(0, 600));
    step('C.summary', { ...sum, sumHits, savedClaims: (sumText.match(/\bsaved\b[^.]*/gi) || []) });
    await p.screenshot({ path: `${out}/${tag}-C-summary.png` });
    const [dl] = await Promise.all([p.waitForEvent('download', { timeout: 15_000 }), tapEl(p.locator('p[data-save-warning] button'))]);
    const file = JSON.parse(readFileSync(await dl.path(), 'utf8'));
    step('C.backup', { name: dl.suggestedFilename(), sessions: file.progress?.sessions?.length, hasBrew: !!file.progress?.sessions?.some((s) => s.intention === 'Storage full brew') });
    await sleep(1200);
    step('C.afterBackup', await state());
    // D
    step('D.skipTapHit', await tapEl(p.getByRole('button', { name: /^Skip break$/ })));
    await p.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 15_000 }); await sleep(1500);
    step('D.today', { ...(await state()), saidLog: await p.evaluate(() => window.__saidLog) });
    await p.screenshot({ path: `${out}/${tag}-D-today.png` });
    // E
    step('E.settingsTapHit', await tapEl(p.getByRole('link', { name: 'Settings' }).or(p.getByRole('button', { name: 'Settings' })).first()));
    await p.waitForFunction(() => location.hash === '#/settings', null, { timeout: 15_000 }); await sleep(1200);
    step('E.settings', { ...(await state()), afterReset: await p.evaluate(() => { const b = document.querySelector('section[data-save-warning]'); const r = [...document.querySelectorAll('button')].find((x) => /Reset everything/.test(x.textContent ?? '')); return !!(b && r && (r.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING)); }) });
    step('E.todayTapHit', await tapEl(p.getByRole('link', { name: 'Today' }).or(p.getByRole('button', { name: 'Today' })).first()));
    await p.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 15_000 }); await sleep(1500);
    step('E.backToday', { ...(await state()), saidLog: await p.evaluate(() => window.__saidLog) });
    // F keyboard: from the document start
    await p.evaluate(() => { document.activeElement?.blur(); });
    await p.keyboard.press('Tab'); // first stop
    const order = [];
    let reachedAt = null;
    for (let i = 1; i <= 60; i++) {
      const a = await p.evaluate(() => { const a = document.activeElement; return { t: (a?.getAttribute('aria-label') || a?.textContent || a?.tagName || '').replace(/\s+/g, ' ').trim().slice(0, 30), inBanner: !!a?.closest('section[data-save-warning]'), vis: (() => { const r = a?.getBoundingClientRect(); return r ? r.top >= 0 && r.bottom <= innerHeight : false; })() }; });
      order.push(a.t);
      if (a.inBanner && /Save backup/.test(a.t)) { reachedAt = { i, visibleWhenFocused: a.vis }; break; }
      await p.keyboard.press('Tab');
    }
    step('F.tab', { reachedAt, order: order.slice(0, 20) });
    // G0 still full: a brew started by a real tap and ended early through the End sheet (real taps): what the End sheet
    // and the End toast say while saving fails.
    step('G0.startTapHit', await tapEl(p.getByRole('button', { name: /^Put the kettle on/ })));
    await p.waitForFunction(() => location.hash === '#/focus', null, { timeout: 15_000 }); await sleep(1500);
    await p.evaluate(() => window.__kettle.ff(3 * 60_000)); await sleep(600);
    step('G0.endTapHit', await tapEl(p.getByRole('button', { name: 'End session' })));
    await sleep(900);
    step('G0.endSheet', await p.evaluate(() => document.querySelector('[role="dialog"]')?.innerText.replace(/\s+/g, ' ').slice(0, 300)));
    await p.evaluate(() => { window.__toastLog = []; new MutationObserver((ms) => { for (const m of ms) for (const x of m.addedNodes) if (x.tagName === 'LI') window.__toastLog.push(x.textContent.trim().slice(0, 80)); }).observe(document.body, { childList: true, subtree: true }); });
    step('G0.endConfirmHit', await tapEl(p.getByRole('dialog').getByRole('button', { name: 'End session' })));
    await p.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 15_000 }); await sleep(1500);
    step('G0.afterEnd', { toasts: await p.evaluate(() => window.__toastLog), ...(await state()) });
    await sleep(3500);
    // G recovery
    await p.evaluate(() => { for (const k of Object.keys(localStorage)) if (k.startsWith('filler') || k === 'probe') localStorage.removeItem(k); });
    await sleep(3000);
    step('G.roomOnly', await state());
    step('G.start2TapHit', await tapEl(p.getByRole('button', { name: /^Put the kettle on/ })));
    await p.waitForFunction(() => location.hash === '#/focus', null, { timeout: 15_000 }); await sleep(1500);
    await p.evaluate(() => window.__kettle.ff(2 * 60_000)); await sleep(600);
    step('G.endTapHit', await tapEl(p.getByRole('button', { name: 'End session' })));
    await sleep(800);
    const endSheetText = await p.evaluate(() => document.querySelector('[role="dialog"]')?.innerText.replace(/\s+/g, ' ').slice(0, 300));
    step('G.endSheet', endSheetText);
    step('G.endConfirmHit', await tapEl(p.getByRole('dialog').getByRole('button', { name: 'End session' })));
    await p.waitForFunction(() => location.hash === '#/' || location.hash === '', null, { timeout: 15_000 });
    const tEnd = Date.now(); let gone = null;
    for (let i = 0; i < 40; i++) { const s = await state(); if (!s.banner) { gone = Date.now() - tEnd; break; } await sleep(150); }
    step('G.afterSaves', { bannerGoneMs: gone, toasts: await p.evaluate(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => li.textContent.trim().slice(0, 60))) });
    // H reload
    await p.reload(); await p.waitForFunction(() => !!window.__kettle, null, { timeout: 60_000 }); await sleep(1500);
    step('H.reload', { ...(await state()), sessions: await p.evaluate(() => window.__kettle.progress.getState().sessions.map((s) => [s.intention, s.phase, Math.round((s.focusMs ?? s.ms ?? 0) / 60000)])) });
  } catch (e) { R.error = String(e.message).split('\n')[0]; console.log(tag, 'ERROR', R.error); }
  R.errors = errors;
  appendFileSync(`${out}/m1flow-${rev}.jsonl`, JSON.stringify(R) + '\n');
  await ctx.close();
}
await b.close();

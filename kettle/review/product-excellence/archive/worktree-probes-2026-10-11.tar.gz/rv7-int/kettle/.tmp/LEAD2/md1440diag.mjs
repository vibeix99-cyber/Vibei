// LEAD2 r7 diagnostic for integrity.spec.ts:1090 at desktop 1440×900 ("Crossed off" never appears): replays the test's
// own steps (open, fill the intention, real click on Put the kettle on, ff 3 min, end('user'), Mark done visible,
// scrollIntoViewIfNeeded, timer.setState({}), fill storage [R7 only, as newbieWithFullStorage]) and, right before the
// same coordinate click on Mark done's centre, records what is at that point (elementFromPoint), every toast and its
// box, and which element receives the pointerdown/click. Then whether "Crossed off. Nice work." appears.
//   node md1440diag.mjs <base> <rev> <out> <reps> <fill 1|0>
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, repsArg = '4', fillArg = '1'] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
for (let rep = 1; rep <= Number(repsArg); rep++) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, acceptDownloads: true });
  // Same prime as the spec (onboarded, scene off, motion reduce, no auto-start).
  await ctx.addInitScript(() => { try { if (localStorage.getItem('kettle:settings')) return; localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const page = await ctx.newPage();
  const row = { rev, base, rep, utc: new Date().toISOString(), load: '' };
  try {
    row.load = (await import('node:fs')).readFileSync('/proc/loadavg', 'utf8').trim();
    await page.goto(`${base}/?debug#/`);
    await page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 30_000 });
    await page.getByRole('textbox', { name: /What are you brewing/ }).fill('Chapter 3 notes');
    await page.getByRole('button', { name: /^Put the kettle on · / }).click();
    await page.waitForFunction(() => location.hash === '#/focus');
    await page.evaluate(() => window.__kettle.ff(3 * 60_000));
    const tEnd = Date.now();
    await page.evaluate(() => window.__kettle.timer.getState().end('user'));
    await page.waitForFunction(() => location.hash === '#/');
    const md = page.getByRole('button', { name: /^Mark “Chapter 3 notes” done/ });
    await md.waitFor({ state: 'visible' });
    await md.scrollIntoViewIfNeeded();
    await page.evaluate(() => window.__kettle.timer.setState({}));
    if (fillArg === '1') await page.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 8) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } });
    const box = await md.boundingBox();
    const [x, y] = [box.x + box.width / 2, box.y + box.height / 2];
    row.click = [x, y];
    row.msAfterEnd = Date.now() - tEnd;
    row.before = await page.evaluate(([x, y]) => {
      const h = document.elementFromPoint(x, y);
      const toasts = [...document.querySelectorAll('[aria-label="Notifications"] li')].map((li) => { const r = li.getBoundingClientRect(); return [li.textContent.slice(0, 40), Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom)]; });
      window.__ev = [];
      for (const t of ['pointerdown', 'click']) addEventListener(t, (e) => window.__ev.push([t, (e.target.closest?.('button,li') || e.target).textContent?.slice(0, 30) || e.target.tagName]), { capture: true });
      return { hit: h ? (h.closest('button,li')?.textContent || h.tagName).slice(0, 40) : null, hitIsMarkDone: !!h?.closest('button[aria-label^="Mark “"]'), toasts };
    }, [x, y]);
    await page.mouse.click(x, y);
    row.crossed = await page.getByText('Crossed off. Nice work.').waitFor({ state: 'visible', timeout: 6000 }).then(() => true, () => false);
    row.events = await page.evaluate(() => window.__ev);
  } catch (e) { row.error = String(e.message).split('\n')[0]; }
  appendFileSync(`${out}/md1440diag-${rev}.jsonl`, JSON.stringify(row) + '\n');
  console.log(JSON.stringify(row));
  await ctx.close();
}
await browser.close();

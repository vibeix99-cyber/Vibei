// LEAD2 r7 probe: on Today at a landscape phone size with large text, REAL Tab from the top through the first N focus
// stops; for each focused element: its box after the browser's own focus scrolling, whether it is inside the viewport,
// and whether elementFromPoint at its centre is the element (not obscured, e.g. by the docked start "Put the kettle on").
// Setup: onboarded profile, a 3-min brew ended (so Today has content). mode=full: storage filled before End (the
// warning is on Today); mode=plain: no fill. No scroll writes; focus scrolling is the browser's.
//   node focusobscure.mjs <base> <rev> <out> "667x375@200:light" <full|plain> [N=30]
import { chromium } from 'playwright';
import { mkdirSync, appendFileSync } from 'node:fs';
const [,, base, rev, out, cfgArg, mode = 'plain', nArg = '30'] = process.argv;
mkdirSync(out, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cfgs = cfgArg.split(',').map((c) => { const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); return { W: +m[1], H: +m[2], text: +m[3], theme: m[4] }; });
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
for (const { W, H, text, theme } of cfgs) {
  const phone = W < 900;
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: phone ? 2 : 1, isMobile: phone, hasTouch: phone, colorScheme: theme });
  await ctx.addInitScript((pct) => {
    try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {}
    if (pct !== 100) addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); });
  }, text);
  const page = await ctx.newPage();
  const row = { rev, base, W, H, text, theme, mode, utc: new Date().toISOString(), stops: [] };
  try {
    await page.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`);
    await page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60_000 });
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => window.__kettle.timer.getState().startFocus({ intention: 'Chapter 3 notes', tag: 'study' }));
    await page.waitForFunction(() => location.hash === '#/focus'); await sleep(1200);
    await page.evaluate(() => window.__kettle.ff(3 * 60_000)); await sleep(300);
    if (mode === 'full') row.quota = await page.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${i++}`, c); } catch { c = c.slice(0, c.length / 2); } } try { localStorage.setItem('probe', 'x'.repeat(64)); return 'no error'; } catch (e) { return e.name; } });
    await page.evaluate(() => window.__kettle.timer.getState().end('user'));
    await page.waitForFunction(() => location.hash === '#/' || location.hash === '');
    await page.waitForFunction(() => document.querySelectorAll('[aria-label="Notifications"] li').length === 0, null, { timeout: 15_000 }).catch(() => {});
    await sleep(500);
    row.banner = await page.evaluate(() => !!document.querySelector('section[data-save-warning]'));
    await page.evaluate(() => document.activeElement?.blur?.());
    for (let i = 1; i <= Number(nArg); i++) {
      await page.keyboard.press('Tab'); await sleep(240);
      const s = await page.evaluate(() => {
        const el = document.activeElement;
        if (!el || el === document.body) return { name: 'BODY' };
        const r = el.getBoundingClientRect();
        const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        const inView = r.top >= 0 && r.bottom <= innerHeight && r.left >= 0 && r.right <= innerWidth;
        const h = cy >= 0 && cy < innerHeight && cx >= 0 && cx < innerWidth ? document.elementFromPoint(cx, cy) : null;
        const ok = !!h && (el === h || el.contains(h));
        const on = !ok && h ? (h.closest('button,a,[role=button]')?.textContent || h.tagName).replace(/\s+/g, ' ').slice(0, 26) : null;
        const name = (el.getAttribute('aria-label') || el.textContent || el.getAttribute('placeholder') || el.tagName).replace(/\s+/g, ' ').slice(0, 26);
        return { name, top: Math.round(r.top), bottom: Math.round(r.bottom), inView, ok, on, inBanner: !!el.closest('section[data-save-warning]') };
      });
      row.stops.push(s);
      if (/Put the kettle on/.test(s.name)) break;
    }
    row.obscured = row.stops.filter((s) => s.name !== 'BODY' && !s.ok).map((s) => [s.name, s.top, s.bottom, s.on]);
  } catch (e) { row.error = String(e.message).split('\n')[0]; }
  appendFileSync(`${out}/focusobscure-${rev}.jsonl`, JSON.stringify(row) + '\n');
  console.log(JSON.stringify({ rev, W, H, text, mode, banner: row.banner, stops: row.stops.length, obscured: row.obscured, error: row.error }));
  await ctx.close();
}
await browser.close();

#!/bin/bash
# 100 % brew captures (focus start/mid/paused, first brew), INT and final, with the repo's capture tool.
SL=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review/tools/slots.py
EV=/home/user/wt/r7a/kettle/review/product-excellence/contracts/I04/integration-fix/r7/M7a/captures/brew100
cd /home/user/wt/r7a/kettle
for rv in "INT 5303" "FINAL 5206"; do set -- $rv; R=$1; P=$2
  for v in "390 844 2" "375 667 2" "1440 900 1"; do set -- $v
    for th in light dark; do
      python3 -I $SL run --lane M7a --n 1 -- node review/product-excellence/tools/capture.mjs --base http://127.0.0.1:$P --out $EV/$R-$1x$2-$th --w $1 --h $2 --dpr $3 --theme $th --only 02,03,04,13 >> $EV/log.txt 2>&1
    done
    python3 -I $SL run --lane M7a --n 1 -- node review/product-excellence/tools/capture.mjs --base http://127.0.0.1:$P --out $EV/$R-$1x$2-light-rm --w $1 --h $2 --dpr $3 --theme light --rm --only 02,03,04,13 >> $EV/log.txt 2>&1
  done
done
echo "BREW DONE $(date -u +%FT%TZ)" >> $EV/log.txt

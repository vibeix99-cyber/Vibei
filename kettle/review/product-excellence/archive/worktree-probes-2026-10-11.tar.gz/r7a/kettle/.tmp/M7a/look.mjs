// quick look: Today / Settings / summary with storage full
import { chromium } from 'playwright';
const [,, base, out, cfgArg] = process.argv;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
for (const c of cfgArg.split(',')) {
  const m = c.match(/^(\d+)x(\d+)@(\d+):(light|dark)$/); const W = +m[1], H = +m[2], text = +m[3], theme = m[4];
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: W >= 900 ? 1 : 2, isMobile: W < 900, hasTouch: W < 900, colorScheme: theme });
  if (text !== 100) await ctx.addInitScript((pct) => addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = `html{font-size:${pct}%!important}`; document.head.appendChild(s); }), text);
  await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => console.log('pageerror', e.message));
  const ready = () => p.waitForFunction(() => { const t = window.__kettle?.timerInfo?.(); return !!(t && t.leader && t.leaderForMs > 400 && !t.settling); }, null, { timeout: 60_000 });
  await p.goto(`${base}/?debug&theme=${theme}${theme === 'light' ? '&nooktime=day' : ''}#/`); await ready();
  await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
  await p.evaluate(() => document.fonts.ready);
  await p.evaluate(() => { let c = 'x'.repeat(1 << 20), k = 0; while (c.length >= 1) { try { localStorage.setItem(`filler${k++}`, c); } catch { c = c.slice(0, c.length / 2); } } });
  await p.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25, intention: 'Chapter 3 notes', tag: 'study' }));
  await p.waitForFunction(() => location.hash === '#/focus'); await sleep(1200);
  const tag = `${W}x${H}-t${text}-${theme}`;
  await p.screenshot({ path: `${out}/focus-${tag}.png` });
  await p.evaluate(() => { const k = window.__kettle; const s = k.timer.getState(); k.ff(s.endsAt - k.clock.now() - 50); });
  await p.waitForFunction(() => location.hash === '#/done', null, { timeout: 15000 }); await sleep(1500);
  await p.screenshot({ path: `${out}/done-${tag}.png` });
  await p.getByRole('button', { name: 'Skip break' }).click();
  await p.waitForFunction(() => location.hash === '#/'); await sleep(1500);
  await p.screenshot({ path: `${out}/today-${tag}.png` });
  await p.evaluate(() => window.__kettle.navigate('/settings')); await sleep(800);
  await p.evaluate(() => document.querySelector('[data-save-warning]')?.scrollIntoView({ block: 'center' })); await sleep(300);
  await p.screenshot({ path: `${out}/settings-${tag}.png` });
  console.log(tag, await p.evaluate(() => document.querySelectorAll('[data-save-warning]').length), await p.evaluate(() => document.getElementById('kettle-save-warning-said')?.textContent));
  await ctx.close();
}
await b.close();

#!/bin/bash
SL=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review/tools/slots.py
EV=/home/user/wt/r7a/kettle/review/product-excellence/contracts/I04/integration-fix/r7/M7a
cd /home/user/wt/r7a/kettle/.tmp/M7a/probes
step() { python3 -I $SL run --lane M7a --n 1 -- ./one.sh "$@"; }
AP="375x667@200:light,375x667@200:dark,844x390@200:light,667x375@150:dark,375x667@150:light,390x844@100:light,375x667@100:light,1440x900@100:light"
step lead-ap actionpair-b.mjs M7a 5206 -- '{BASE}' '{LABEL}' '{OUT}' "$AP"
step lead-pp pwapair-b.mjs M7a 5206 -- '{BASE}' '{LABEL}' '{OUT}' "375x667@200:light,667x375@150:dark"
for c in "375x667 light" "844x390 light" "375x667 dark"; do set -- $c
  step r5d1-$1-$2 natural-b.mjs M7a 5206 -- '{BASE}' '{LABEL}' '{OUT}' $1 $2 200 600,900,1200,1500,1800 2
done
mkdir -p $EV/m7b-on-final
python3 -I $SL run --lane M7a --n 1 -- node toastcheck.mjs http://127.0.0.1:5206 FINAL $EV/m7b-on-final/toast-check 375x667 light > $EV/m7b-on-final/toastcheck.log 2>&1
for c in 375x667 844x390 390x844; do
  python3 -I $SL run --lane M7a --n 1 -- node reach.mjs http://127.0.0.1:5206 FINAL $EV/m7b-on-final/reach $c light,dark 200 >> $EV/m7b-on-final/reach.log 2>&1
done
echo "ALL P3 DONE $(date -u +%FT%TZ)"

#!/bin/bash
SL=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review/tools/slots.py
EV=/home/user/wt/r7a/kettle/review/product-excellence/contracts/I04/integration-fix/r7/M7a
cd /home/user/wt/r7a/kettle/.tmp/M7a
run() { python3 -I $SL run --lane M7a --n 1 -- "$@"; }
run node capture-r7.mjs http://127.0.0.1:5303 INT $EV/captures/BEFORE-INT "1440x900@100:dark,844x390@100:dark" >> $EV/captures/capture-INT.txt 2>&1
for th in light dark; do
  run node capture-r7.mjs http://127.0.0.1:5303 INT $EV/captures/BEFORE-INT "390x844@200:$th,375x667@200:$th,1440x900@200:$th,844x390@200:$th" >> $EV/captures/capture-INT.txt 2>&1
done
echo "INT CAPTURES DONE $(date -u +%FT%TZ)"

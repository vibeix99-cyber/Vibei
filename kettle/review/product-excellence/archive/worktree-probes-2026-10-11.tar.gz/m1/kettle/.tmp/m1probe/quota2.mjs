import { chromium } from '@playwright/test';
const base = 'http://127.0.0.1:5201';
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext();
await ctx.addInitScript(() => { try { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); } catch {} });
const page = await ctx.newPage();
page.on('console', (m) => console.log('[console]', m.type(), m.text().slice(0, 300)));
page.on('pageerror', (e) => console.log('[pageerror]', e.message));
const ready = () => page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return i && i.leader && i.leaderForMs > 400 && !i.settling; }, null, { timeout: 30000 });
await page.goto(`${base}/?debug#/`); await ready();
await page.evaluate(() => window.__kettle.seed('newbie'));
await page.reload(); await ready();
await page.evaluate(() => window.__kettle.navigate('/settings'));
await page.waitForTimeout(1000);
await page.evaluate(() => {
  let chunk = 'x'.repeat(1024 * 1024); let i = 0;
  while (chunk.length >= 8) { try { localStorage.setItem(`filler${i++}`, chunk); } catch { chunk = chunk.slice(0, chunk.length / 2); } }
});
await page.evaluate(() => { window.__log = []; const k = window.__kettle; window.addEventListener('hashchange', () => window.__log.push({ t: Date.now(), hash: location.hash, stack: new Error().stack.split('\n').slice(1, 4).join(' | ') })); k.timer.subscribe((s, p) => { if (p.status !== s.status) window.__log.push({ t: Date.now(), from: p.status, to: s.status }); }); k.progress.subscribe((s, p) => window.__log.push({ t: Date.now(), prog: s.sessions.length, prev: p.sessions.length, rep: s.lastReport?.id ?? null, prevRep: p.lastReport?.id ?? null, epoch: s.epoch, pepoch: p.epoch, stack: new Error().stack.split('\n').slice(2, 9).map((l) => l.trim().replace(/http:\/\/127.0.0.1:5201/g, '')).join(' | ') })); });
await page.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25, intention: 'Storage full' }));
await page.waitForTimeout(1500);
console.log('hash after start', await page.evaluate(() => location.hash));
await page.evaluate(() => { const k = window.__kettle; const s = k.timer.getState(); k.ff(s.endsAt - k.clock.now() - 50); });
await page.waitForTimeout(5000);
console.log(JSON.stringify(await page.evaluate(() => ({ log: window.__log, hash: location.hash, timer: window.__kettle.timer.getState().status, rep: window.__kettle.progress.getState().lastReport?.id, n: window.__kettle.progress.getState().sessions.length })), null, 1));
await browser.close();

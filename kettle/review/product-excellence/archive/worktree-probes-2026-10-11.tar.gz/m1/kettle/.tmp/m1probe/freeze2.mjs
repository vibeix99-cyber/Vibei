import { chromium } from '@playwright/test';
const base = 'http://127.0.0.1:5201';
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext();
await ctx.addInitScript(() => { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); });
const page = await ctx.newPage();
await page.goto(`${base}/?debug#/`);
await page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return i && i.leader && i.leaderForMs > 400 && !i.settling; }, null, { timeout: 30000 });
await page.evaluate(() => { window.__log = []; for (const ev of ['freeze', 'resume', 'visibilitychange']) document.addEventListener(ev, () => window.__log.push({ t: Date.now(), ev, vis: document.visibilityState })); });
const cdp = await ctx.newCDPSession(page);
// Try 1: minimize the window
try {
  const { windowId } = await cdp.send('Browser.getWindowForTarget');
  await cdp.send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } });
  await page.waitForTimeout(500);
  console.log('after minimize vis', await page.evaluate(() => document.visibilityState));
} catch (e) { console.log('minimize failed', e.message); }
// Try 2: focus emulation off + another page on top
try {
  await cdp.send('Emulation.setFocusEmulationEnabled', { enabled: false });
  const other = await ctx.newPage();
  await other.goto('about:blank');
  await other.bringToFront();
  await page.waitForTimeout(500);
  console.log('after other page vis', await page.evaluate(() => document.visibilityState));
} catch (e) { console.log('try2 failed', e.message); }
try {
  const r = await cdp.send('Page.setWebLifecycleState', { state: 'frozen' });
  console.log('freeze result', r);
} catch (e) { console.log('freeze error', e.message); }
await new Promise((r) => setTimeout(r, 2000));
await cdp.send('Page.setWebLifecycleState', { state: 'active' }).catch((e) => console.log('active err', e.message));
await page.waitForTimeout(500);
console.log(JSON.stringify(await page.evaluate(() => window.__log)));
await browser.close();

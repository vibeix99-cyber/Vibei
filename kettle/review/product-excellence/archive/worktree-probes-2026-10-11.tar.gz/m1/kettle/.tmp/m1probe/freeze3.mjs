import { chromium } from '@playwright/test';
const base = 'http://127.0.0.1:5201';
const browser = await chromium.launch({ headless: false, args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext();
await ctx.addInitScript(() => { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); });
const page = await ctx.newPage();
await page.goto(`${base}/?debug#/`);
await page.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return i && i.leader && i.leaderForMs > 400 && !i.settling; }, null, { timeout: 30000 });
await page.evaluate(() => { window.__log = []; for (const ev of ['freeze', 'resume', 'visibilitychange']) document.addEventListener(ev, () => window.__log.push({ t: Date.now(), ev, vis: document.visibilityState })); const k = window.__kettle; k.timer.subscribe((s, p) => { if (p.status !== s.status) window.__log.push({ t: Date.now(), from: p.status, to: s.status, le: s.lastEnded }); }); });
console.log('vis0', await page.evaluate(() => document.visibilityState));
const cdp = await ctx.newCDPSession(page);
const { targetInfo } = await cdp.send('Target.getTargetInfo');
// A second tab in the same window, in front: the brew's tab is now a background tab.
const bcdp = await browser.newBrowserCDPSession();
const { targetId } = await bcdp.send('Target.createTarget', { url: 'about:blank', newWindow: false, background: false, browserContextId: targetInfo.browserContextId });
await new Promise((r) => setTimeout(r, 1000));
console.log('vis after other tab', await page.evaluate(() => document.visibilityState));
await page.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25 }));
await page.evaluate(() => { const k = window.__kettle; const s = k.timer.getState(); k.ff(s.endsAt - k.clock.now() - 1500); });
const t0 = Date.now();
try { console.log('freeze', await cdp.send('Page.setWebLifecycleState', { state: 'frozen' })); } catch (e) { console.log('freeze err', e.message); }
await new Promise((r) => setTimeout(r, 13000));
await cdp.send('Page.setWebLifecycleState', { state: 'active' });
console.log('t0', t0, 'active', Date.now());
await bcdp.send('Target.activateTarget', { targetId: targetInfo.targetId });
await new Promise((r) => setTimeout(r, 3000));
console.log(JSON.stringify(await page.evaluate(() => ({ log: window.__log, hash: location.hash, vis: document.visibilityState })), null, 1));
await browser.close();

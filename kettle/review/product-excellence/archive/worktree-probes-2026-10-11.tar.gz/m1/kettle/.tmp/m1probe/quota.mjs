import { chromium } from '@playwright/test';
const base = process.argv[2] ?? 'http://127.0.0.1:5201';
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on('requestfailed', (r) => console.log('[reqfail]', r.url()));
page.on('response', (r) => { if (r.status() >= 400) console.log('[resp]', r.status(), r.url()); });
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') console.log('[console]', m.type(), m.text().slice(0, 200)); });
await page.goto(`${base}/?debug&seed=newbie&onboarded=1&motion=reduce#/`);
await page.waitForFunction(() => !!window.__kettle?.timerInfo, null, { timeout: 30000 });
await page.evaluate(() => window.__kettle.settings.getState().set({ scene: 'off', autoStartBreaks: false, autoStartFocus: false }));
const before = await page.evaluate(() => ({ n: window.__kettle.progress.getState().sessions.length, leaves: window.__kettle.progress.getState().leaves, raw: localStorage.getItem('kettle:progress').length }));
console.log('before', before);
// Fill the real quota with a filler key.
const filled = await page.evaluate(() => {
  let chunk = 'x'.repeat(1024 * 1024); let i = 0; let total = 0;
  while (chunk.length >= 16) {
    try { localStorage.setItem('filler' + i, chunk); i++; total += chunk.length; } catch (e) { chunk = chunk.slice(0, chunk.length / 2); }
  }
  return { keys: i, total, err: (() => { try { localStorage.setItem('probe', 'x'.repeat(5000)); return 'no error'; } catch (e) { return e.name; } })() };
});
console.log('filled', filled);
await page.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25, intention: 'Quota test' }));
await page.waitForTimeout(1500);
await page.evaluate(() => window.__kettle.finish());
await page.waitForTimeout(3000);
const after = await page.evaluate(() => ({ hash: location.hash, n: window.__kettle.progress.getState().sessions.length, leaves: window.__kettle.progress.getState().leaves, storedN: JSON.parse(localStorage.getItem('kettle:progress')).state.sessions.length, timer: localStorage.getItem('kettle:timer') }));
console.log('after complete', after);
const toasts = await page.evaluate(() => [...document.querySelectorAll('[aria-label="Notifications"] li')].map((l) => l.textContent));
console.log('toasts', toasts);
const body = await page.evaluate(() => document.body.innerText.slice(0, 400));
console.log('body', body.replace(/\n+/g, ' | '));
await page.reload();
await page.waitForFunction(() => !!window.__kettle?.timerInfo, null, { timeout: 30000 });
await page.waitForTimeout(1500);
const reloaded = await page.evaluate(() => ({ hash: location.hash, n: window.__kettle.progress.getState().sessions.length, leaves: window.__kettle.progress.getState().leaves, timer: window.__kettle.timer.getState().status }));
console.log('after reload', reloaded);
await browser.close();

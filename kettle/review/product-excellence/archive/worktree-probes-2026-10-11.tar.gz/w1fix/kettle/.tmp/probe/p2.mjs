import { chromium } from 'playwright';
const [W, H] = process.argv.slice(2).map(Number);
const out = process.argv[4];
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
await ctx.addInitScript(() => { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); });
const p = await ctx.newPage();
const ready = () => p.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60000 });
await p.goto('http://127.0.0.1:5201/?debug#/'); await ready();
await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
await p.evaluate(() => window.__kettle.timer.setState({}));
await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 8) { try { localStorage.setItem('filler' + i++, c); } catch { c = c.slice(0, c.length / 2); } } });
const info = async (tag) => {
  const r = await p.evaluate(() => {
    const li = document.querySelector('[aria-label="Notifications"] li');
    const reg = document.querySelector('[aria-label="Notifications"]')?.parentElement;
    const box = (el) => el ? (({ top, bottom, left, right }) => ({ top: Math.round(top), bottom: Math.round(bottom) }))(el.getBoundingClientRect()) : null;
    return { hash: location.hash, toast: box(li), region: box(reg), regionStyle: reg?.getAttribute('style'), controls: box(document.querySelector('[data-toast-above]')), readout: box(document.querySelector('main [role="timer"]')?.parentElement), toastX: (()=>{const l=document.querySelector('[aria-label="Notifications"] li'); if(!l) return null; const r=l.getBoundingClientRect(); return [Math.round(r.left),Math.round(r.right)]})(), readX: (()=>{const l=document.querySelector('main [role="timer"]')?.parentElement; if(!l) return null; const r=l.getBoundingClientRect(); return [Math.round(r.left),Math.round(r.right)]})() };
  });
  console.log(tag, JSON.stringify(r));
};
await p.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25, intention: 'Storage full' }));
for (let i = 0; i < 6; i++) { await p.waitForTimeout(300); await info('start' + i); }
await p.screenshot({ path: `${out}-start.png` });
// to the end, summary, skip
await p.evaluate(() => { const k = window.__kettle; const s = k.timer.getState(); k.ff(s.endsAt - k.clock.now() - 50); });
await p.waitForFunction(() => location.hash === '#/done', null, { timeout: 20000 });
await p.waitForTimeout(1500); await info('done');
await p.getByRole('button', { name: 'Skip break' }).click();
await p.waitForTimeout(1500); await info('home');
await p.screenshot({ path: `${out}-home.png` });
await p.getByRole('button', { name: /^Put the kettle on/ }).click();
for (let i = 0; i < 12; i++) { await p.waitForTimeout(i < 4 ? 50 : 250); await info("next" + i); }
await p.screenshot({ path: `${out}-next.png` });
await b.close();

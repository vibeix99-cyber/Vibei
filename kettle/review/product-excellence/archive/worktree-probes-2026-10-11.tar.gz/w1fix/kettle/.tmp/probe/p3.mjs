import { chromium } from 'playwright';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
await ctx.addInitScript(() => { if (!localStorage.getItem('kettle:settings')) localStorage.setItem('kettle:settings', JSON.stringify({ state: { onboarded: true, scene: 'off', motion: 'reduce', autoStartBreaks: false, autoStartFocus: false, muted: true }, version: 1 })); });
const p = await ctx.newPage();
const ready = () => p.waitForFunction(() => { const i = window.__kettle?.timerInfo?.(); return !!(i && i.leader && i.leaderForMs > 400 && !i.settling); }, null, { timeout: 60000 });
await p.goto('http://127.0.0.1:5201/?debug#/'); await ready();
await p.evaluate(() => window.__kettle.seed('newbie')); await p.reload(); await ready();
await p.evaluate(() => window.__kettle.timer.setState({}));
await p.evaluate(() => { let c = 'x'.repeat(1 << 20), i = 0; while (c.length >= 8) { try { localStorage.setItem('filler' + i++, c); } catch { c = c.slice(0, c.length / 2); } } });
await p.evaluate(() => window.__kettle.timer.getState().startFocus({ minutes: 25, intention: 'Storage full' }));
for (let i = 0; i < 12; i++) {
  await p.waitForTimeout(400);
  const r = await p.evaluate(() => {
    const live = document.querySelector('[aria-label="Notifications"]'); const region = live.parentElement;
    const area = live.getBoundingClientRect(); const bottom = region.getBoundingClientRect().bottom; const top = Math.min(region.getBoundingClientRect().top, bottom - 170);
    const hits = [];
    for (const el of document.querySelectorAll('button, a[href], [role="button"], input, textarea, select')) { if (live.contains(el)) continue; const r = el.getBoundingClientRect(); if (!r.width || !r.height) continue; if (r.right > area.left && r.left < area.right && r.bottom > top && r.top < bottom) hits.push((el.getAttribute('aria-label') || el.textContent || el.tagName).slice(0, 30) + `@${Math.round(r.left)},${Math.round(r.top)}`); }
    return { n: live.querySelectorAll('li').length, area: [Math.round(area.left), Math.round(area.right), Math.round(top), Math.round(bottom)], hits };
  });
  console.log(JSON.stringify(r));
}
await b.close();

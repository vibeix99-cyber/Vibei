#!/bin/bash
# one slot job: the two remaining check-1 R7 clips (wheel), 844x390 light and 375x667 dark (re-ordered behind the R7 LEAD-D1 keyboard run)
cd /home/user/wt/rv7-r7/kettle/.tmp/A
./one.sh r5d1-wheel-r7clip-844L natural-a2.mjs 5301 GESTURE=wheel VIDEO=1 -- {BASE} R7clip {OUT} 844x390 light 200 1200 1
./one.sh r5d1-wheel-r7clip-375D natural-a2.mjs 5301 GESTURE=wheel VIDEO=1 -- {BASE} R7clip {OUT} 375x667 dark 200 1200 1

#!/bin/bash
# Lane D: the one failing chromium test re-run alone, once, --workers=1 (through the slot gate, --n 1).
R=/home/user/Vibei/kettle/review/product-excellence/contracts/I04/integration-fix/round7-review
S=/tmp/claude-0/-home-user-Vibei/af90140e-0279-5682-99d5-a47623d3eed0/scratchpad/r7/D
cd /home/user/wt/rv7-r7/kettle
date -u +"start %T"
PLAYWRIGHT_JSON_OUTPUT_NAME=$S/pw-rerun.json KETTLE_PORT=5301 KETTLE_PWA_PORT=5311 python3 -I $R/tools/slots.py run --lane D --n 1 -- npx playwright test --project=chromium --workers=1 --output $S/pw-out-rerun --reporter=list,json tests/integrity.spec.ts:1090
echo "exit $?"; date -u +"end %T"
